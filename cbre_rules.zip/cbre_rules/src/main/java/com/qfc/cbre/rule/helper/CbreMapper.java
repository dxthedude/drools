package com.qfc.cbre.rule.helper;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qfc.cbre.qcam.vo.CbreLeadReq;
import com.qfc.cbre.qcam.vo.FiPortalResponse;
import com.qfc.cbre.rule.vo.CreditBreRequest;
import com.qfc.mst.common.util.MstConstants;
import com.qfc.mst.finone.vo.Fin1LeaSchemeM;
import com.qfc.mst.finone.vo.Fin1LosSchMaster;
import com.qfc.mst.master.cv.vo.MstRbpSubCodeRiskCatLtvCv;
import com.qfc.mst.master.cv.vo.MstRbpSubCodeSupCatLtvCv;
import com.qfc.mst.master.vo.MstLov;
import com.qfc.mst.master.vo.MstMakeModel;
import com.qfc.mst.master.vo.MstRbpSubCodeRiskCatLtv;
import com.qfc.mst.master.vo.MstRbpSubCodeSupCatLtv;
import com.qfc.mst.master.vo.MstSupplierDetail;
import com.qfc.mst.masters.cache.MasterCache;
import com.qfc.mst.masters.cache.MasterCacheFinnone;
import com.qfc.mst.masters.cache.MasterCacheMap;
import com.qfc.mst.masters.cv.cache.MasterCacheMapCv;

@Component
public class CbreMapper {

	@Autowired
	MasterCache masterCache;

	private static final Logger logger = LoggerFactory.getLogger(CbreMapper.class);

	public CreditBreRequest mapLeadDetailsToCbreRequest(CreditBreRequest req, CbreLeadReq leadReq) {
		// print(req, leadReq);
		try {
			req = commonFiledsMapping(req, leadReq);
			req = ApplicantFiledsMapping(req, leadReq);

			if (leadReq.getCoAppLeadDetails() != null)
				req = CoApplicantFiledsMapping(req, leadReq);
			if (leadReq.getGrntrLeadDetails() != null)
				req = GuarantorFiledsMapping(req, leadReq);
			if (leadReq.getLeadDetails().getFiPortalResponses() != null
					&& leadReq.getLeadDetails().getFiPortalResponses().size() > 0) {
				req = mapFiportalResponse(req, leadReq);
			}

			// printData(req);
		} catch (Exception e) {
			System.out.println("EXCEPTION OCCURED DURING MAPPING >>>>>>>>>>>> ");
			e.printStackTrace();
		}
		return req;
	}

	private CreditBreRequest mapFiportalResponse(CreditBreRequest req, CbreLeadReq leadReq) {

		for (FiPortalResponse resp : leadReq.getLeadDetails().getFiPortalResponses()) {
			if (resp != null && StringUtils.stripToNull(resp.getUid()) != null) {
				if (resp.getUid().contains("C")) {

					coAppPortalMapping(req, resp);

				} else if (resp.getUid().contains("G")) {

					guarPortalMapping(req, resp);

				} else {

					appPortalMapping(req, resp);
				}
			}
		}

		return req;
	}

	private void appPortalMapping(CreditBreRequest req, FiPortalResponse resp) {
		Integer workingSince = calculateMonths(resp.getWorking_since_mth(), resp.getWorking_since_year());
		Integer residenceSince = calculateMonths(resp.getStaying_since_mth(), resp.getStaying_since_year());
		req.getCbreRequest_A().setWorkingSinceFI_A(workingSince);
		req.getCbreRequest_A().setResidingSince_A(residenceSince);

		if (resp.getFi_type().contains("Office")) {
			req.getCbreRequest_A().setFIOff_A(resp.getFi_status());
		} else if (resp.getFi_type().contains("Residence")) {
			req.getCbreRequest_A().setFIPres_A(resp.getFi_status());
		} else if (resp.getFi_type().contains("Permanent")) {
			req.getCbreRequest_A().setFIPerm_A(resp.getFi_status());
		}
	}

	private void guarPortalMapping(CreditBreRequest req, FiPortalResponse resp) {
		Integer workingSince = calculateMonths(resp.getWorking_since_mth(), resp.getWorking_since_year());
		Integer residenceSince = calculateMonths(resp.getStaying_since_mth(), resp.getStaying_since_year());
		req.getCbreRequest_G().setWorkingSinceFI_G(workingSince);
		req.getCbreRequest_G().setResidingSince_G(residenceSince);

		if (resp.getFi_type().contains("Office")) {
			// req.getCbreRequest_G().setFIOff_G(resp.getFi_status());
		} else if (resp.getFi_type().contains("Residence")) {
			req.getCbreRequest_G().setFIPres_G(resp.getFi_status());
		} else if (resp.getFi_type().contains("Permanent")) {
			// req.getCbreRequest_G().setF(resp.getFi_status());
		}
	}

	private void coAppPortalMapping(CreditBreRequest req, FiPortalResponse resp) {
		Integer workingSince = calculateMonths(resp.getWorking_since_mth(), resp.getWorking_since_year());
		Integer residenceSince = calculateMonths(resp.getStaying_since_mth(), resp.getStaying_since_year());
		req.getCbreRequest_C().setWorkingSinceFI_C(workingSince);
		req.getCbreRequest_C().setResidingSince_C(residenceSince);

		if (resp.getFi_type().contains("Office")) {
			req.getCbreRequest_C().setFIOff_C(resp.getFi_status());
		} else if (resp.getFi_type().contains("Residence")) {
			req.getCbreRequest_C().setFIPres_C(resp.getFi_status());
		} else if (resp.getFi_type().contains("Permanent")) {
			req.getCbreRequest_C().setFIPerm_C(resp.getFi_status());
		}
	}

	private Integer calculateMonths(Integer mth, Integer year) {
		StringBuffer m = new StringBuffer();
		StringBuffer d = new StringBuffer();
		Calendar cal = Calendar.getInstance();
		Integer day = cal.get(Calendar.DAY_OF_MONTH);
		System.out.println("day :: " + day + " month :: " + mth);
		if (day.toString().length() == 1) {
			d.append("0").append(day);
		} else {
			d.append(day.toString());
		}
		if (mth.toString().length() == 1) {
			m.append("0").append(mth);
		} else {
			m.append(mth.toString());
		}

		LocalDate now = LocalDate.now();
		LocalDate from = LocalDate.parse(year + "-" + m.toString() + "-" + d.toString());
		Long months = ChronoUnit.MONTHS.between(from, now);
		return months.intValue();
	}

	private void printData(CreditBreRequest req) {
		System.out.println("CreditBRE input DATA :: \n\n" + req.toString());
	}

	private CreditBreRequest GuarantorFiledsMapping(CreditBreRequest req, CbreLeadReq leadReq) {
		if (leadReq.getGrntrLeadDetails() != null) {

			req.getCbreRequest_G().setLeadId(
					leadReq.getLeadDetails().getLeadId() != null ? leadReq.getLeadDetails().getLeadId() : null);
			req.getCbreRequest_G()
					.setUid_G(leadReq.getLeadDetails().getUid() != null ? leadReq.getLeadDetails().getUid() : null);

			req.getCbreRequest_G()
					.setDedupeStatus_G(leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a() != null
							? leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a().toUpperCase()
							: null);
			req.getCbreRequest_G()
					.setDedupeStatusAF_G(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l().toUpperCase()
							: null);
			req.getCbreRequest_G()
					.setDedupeStatusCF_G(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l().toUpperCase()
							: null);
			req.getCbreRequest_G()
					.setDedupeTenure_G(leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l().toUpperCase()
							: null);
			req.getCbreRequest_G()
					.setDobIncorp_G(leadReq.getGrntrLeadDetails().getDobIncorp() != null
							? leadReq.getGrntrLeadDetails().getDobIncorp()
							: null);

			// req.getCbreRequest_G().setFiNegReaResi_G(fiNegReaResi_G);
			// req.getCbreRequest_G().setFiNegReaPerm_G(fiNegReaPerm_G);
			// req.getCbreRequest_G().setFiNegReaOffice_G(fiNegReaOffice_G);
			// req.getCbreRequest_G().setPri
			req.getCbreRequest_G()
					.setPrimaryEmpType_G(leadReq.getGrntrLeadDetails().getSubEmpTypeId() != null
							? MasterCacheMap.getSubEmpByIcasId(leadReq.getGrntrLeadDetails().getSubEmpTypeId())
									.getSubEmpType().toUpperCase()
							: null);

			req.getCbreRequest_G()
					.setPropertyStatus_G(leadReq.getGrntrLeadDetails().getPropertyStatusId() != null
							? MasterCache.getLovByIcasId(leadReq.getGrntrLeadDetails().getPropertyStatusId().toString(),
									MstConstants.LOV_TYPES.PROPERTY_STATUS).getDisplayName().toUpperCase()
							: null);
			req.getCbreRequest_G()
					.setResidenceStatus_G(
							leadReq.getGrntrLeadDetails().getResStatusId() != null
									? MasterCache
											.getLovByIcasId(leadReq.getGrntrLeadDetails().getResStatusId().toString(),
													MstConstants.LOV_TYPES.RESIDENCE_STATUS)
											.getDisplayName().toUpperCase()
									: null);

			req.getCbreRequest_G()
					.setResidingSince_G(leadReq.getGrntrLeadDetails().getResSinceStr() != null
							? leadReq.getGrntrLeadDetails().getResSinceInNoMths()
							: null);

			Integer residingSinceYrG = null;
			Integer residingSinceMthG = null;
			if (leadReq.getGrntrLeadDetails().getResSinceInNoYear() != null
					&& leadReq.getGrntrLeadDetails().getResSinceInNoMths() != null) {
				residingSinceYrG = Integer.valueOf(leadReq.getGrntrLeadDetails().getResSinceInNoYear());
				residingSinceMthG = Integer.valueOf(leadReq.getGrntrLeadDetails().getResSinceInNoMths());
			}
			req.getCbreRequest_G()
					.setResidingSince_G(leadReq.getGrntrLeadDetails().getResSinceInNoYear() != null
							&& leadReq.getGrntrLeadDetails().getResSinceInNoMths() != null
									? (residingSinceYrG * 12 + residingSinceMthG)
									: null);

			req.getCbreRequest_G()
					.setWorkingSince_G(leadReq.getGrntrLeadDetails().getWorkingSinceInNoYear() != null
							&& leadReq.getGrntrLeadDetails().getWorkingSinceInNoMths() != null
									? (leadReq.getGrntrLeadDetails().getWorkingSinceInNoYear() * 12
											+ leadReq.getGrntrLeadDetails().getWorkingSinceInNoMths())
									: null);
			// req.getCbreRequest_G().setWorkingSinceFI_G(workingSinceFI_A);
			if (leadReq.getGrntrLeadDetails().getBureauCalcResponse() != null) {
				req.getCbreRequest_G().setBureauScore_G(
						leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBureau_score() != null
								? Integer.valueOf(
										leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBureau_score())
								: null);
				req.getCbreRequest_G()
						.setBureauType_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBureau() != null
								? leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBureau().toUpperCase()
								: null);
				req.getCbreRequest_G()
						.setMaxClosureDateLT3_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatelessthen_3year_cc() != null
										? (leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatelessthen_3year_cc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_G()
						.setMaxClosureDateLT3_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatelessthen3year_ncc() != null
										? (leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatelessthen3year_ncc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_G()
						.setMaxClosureDateGT3_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatemorethen_3year_cc() != null
										? (leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatemorethen_3year_cc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_G()
						.setMaxClosureDateGT3_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatemorethen3year_ncc() != null
										? (leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatemorethen3year_ncc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_G()
						.setOverdueNonCCAccQualMaxAmt_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverduenonccaccounts_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverduenonccaccounts_amount().doubleValue()
										: null);
				req.getCbreRequest_G()
						.setOverdueNonCCAccQualMaxDPD_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverdueddpnonccaccount_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverdueddpnonccaccount_amount().doubleValue()
										: null);
				req.getCbreRequest_G()
						.setOverdueCCAccQualMaxAmt_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverdueccaccounts_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverdueccaccounts_amount().doubleValue()
										: null);

				req.getCbreRequest_G()
						.setWrittenOffCCAccQualMaxAmt_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffccaccounts_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffccaccounts_amount().doubleValue()
										: null);
				req.getCbreRequest_G()
						.setWrittenOffNonCCAccQualMaxAmt_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffnonccaccount_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffnonccaccount_amount().doubleValue()
										: null);
				req.getCbreRequest_G()
						.setWrittenOffNonCCAccQualMaxDPD_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffddpnonccaccount_amount() != null
										? leadReq.getGrntrLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffddpnonccaccount_amount().doubleValue()
										: null);
				req.getCbreRequest_G().setWO_OD_Settled_Status_G(
						leadReq.getGrntrLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus() != null
								? leadReq.getGrntrLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus()
										.toString().toUpperCase()
								: null);

				req.getCbreRequest_G()
						.setBSBand_G(leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBand_code() != null
								? leadReq.getGrntrLeadDetails().getBureauCalcResponse().getBand_code().toUpperCase()
								: null);
			}

			req.getCbreRequest_G()
					.setNoOfBouncing_G(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing() != null
							? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing())
							: null);

			// req.getCbreRequest_G().setProneArea_G(proneArea_G);
			req.getCbreRequest_G()
					.setFraudMatchFlag_G(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflagg() != null
							? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflagg())
							: null);

			req.getCbreRequest_G()
					.setAge_G(leadReq.getGrntrLeadDetails().getAgeInMonth() != null
							? leadReq.getGrntrLeadDetails().getAgeInMonth() / 12
							: null);
			// req.getCbreRequest_G().setPinCodeMatchedOff_G(pinCodeMatchedOff_G);
			// req.getCbreRequest_G().setPinCodeMatchedRes_G(pinCodeMatchedRes_G);

			req.getCbreRequest_G()
					.setHRPProfile_G(leadReq.getGrntrLeadDetails().getApplProfile() != null
							? (leadReq.getGrntrLeadDetails().getApplProfile().startsWith("HRP") ? "YES" : "NO")
							: null);
			req.getCbreRequest_G()
					.setProfile_G(leadReq.getGrntrLeadDetails().getApplProfile() != null
							? leadReq.getGrntrLeadDetails().getApplProfile()
							: null);
			// req.getCbreRequest_G().setNA_G(nA_G);
			// req.getCbreRequest_G().setNP_G(nP_G);
			// req.getCbreRequest_G().setPA_G(pA_G);
			// req.getCbreRequest_G().setFM_G(fM_G);
			// req.getCbreRequest_G().setFi_Status_G("");
			// req.getCbreRequest_C().setFi_Type_C();
			// req.getCbreRequest_C().setFIPres_C(fIPres_C);
			// req.getCbreRequest_G().setTPC_G(tPC_G);
			// req.getCbreRequest_G().setTVR_Status_G(tVR_Status_G);
			req.getCbreRequest_G().setNA_NegativeArea_G(leadReq.getGrntrLeadDetails().isNegArea() ? "YES" : "NO");
		}
		return req;
	}

	private CreditBreRequest CoApplicantFiledsMapping(CreditBreRequest req, CbreLeadReq leadReq) {
		if (leadReq.getCoAppLeadDetails() != null) {
			if (leadReq.getCoAppLeadDetails().getLandHoldingType() != null) {
				req.getCbreRequest_C().setLandHoldingType_C(
						leadReq.getCoAppLeadDetails().getLandHoldingType().toString().toUpperCase());
				if (leadReq.getCoAppLeadDetails().getLandHoldingType().equalsIgnoreCase("Owned")) {
					req.getCbreRequest_C().setLandHoldingOwn_C("YES");
				}
				if (leadReq.getCoAppLeadDetails().getLandHoldingType().equalsIgnoreCase("Leased")) {
					req.getCbreRequest_C().setLandHoldingLea_C("YES");
				}
			}

			req.getCbreRequest_C()
					.setCropsPerYear_C(leadReq.getCoAppLeadDetails().getCropsPerYear() != null
							? leadReq.getCoAppLeadDetails().getCropsPerYear()
							: null);

			req.getCbreRequest_C().setPresentAddrAsOffAddr_C(
					leadReq.getCoAppLeadDetails().getRco() != null ? leadReq.getCoAppLeadDetails().getRco() : null);
			req.getCbreRequest_C().setLeadId(
					leadReq.getLeadDetails().getLeadId() != null ? leadReq.getLeadDetails().getLeadId() : null);
			req.getCbreRequest_C().setUid_C(
					leadReq.getLeadDetails().getUid() != null ? leadReq.getLeadDetails().getUid().toUpperCase() : null);
			// req.getCbreRequest_C().setGender_C(leadReq.getAppLeadDetails().getGender_A());
			// req.getCbreRequest_C().setLandlineNo_C(leadReq.getCoAppLeadDetails().getOffAddressLandLine()!=null
			// ? leadReq.getCoAppLeadDetails().getOffAddressLandLine() : null);
			req.getCbreRequest_C()
					.setBusinessLandlineNo_C(leadReq.getCoAppLeadDetails().getOffAddressLandLine() != null
							? leadReq.getCoAppLeadDetails().getOffAddressLandLine()
							: null);
			req.getCbreRequest_C()
					.setConstitutionC(
							leadReq.getLeadDetails().getConstitutionId() != null
									? MasterCache
											.getLovByIcasId(leadReq.getLeadDetails().getConstitutionId().toString(),
													MstConstants.LOV_TYPES.CONSTITUTION)
											.getDisplayName().toUpperCase()
									: null);
			req.getCbreRequest_C()
					.setDedupeAFCount_C(leadReq.getLeadDetails().getDedupeResponse().getDedupe_af_count_l() != null
							? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getDedupe_af_count_l())
							: null);
			req.getCbreRequest_C()
					.setDedupeStatus_C(leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a() != null
							? leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a().toUpperCase()
							: null);
			req.getCbreRequest_C()
					.setDedupeStatusAF_C(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l().toUpperCase()
							: null);
			req.getCbreRequest_C()
					.setDedupeStatusCF_C(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l().toUpperCase()
							: null);
			req.getCbreRequest_C()
					.setDedupeTenure_C(leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l() != null
							? leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l().toUpperCase()
							: null);
			req.getCbreRequest_C()
					.setDobIncorp_C(leadReq.getCoAppLeadDetails().getDobDate() != null
							? leadReq.getCoAppLeadDetails().getDobDate()
							: null);
			// req.getCbreRequest_C().setFiNegReaResi_C(fiNegReaResi_C);
			// req.getCbreRequest_C().setFiNegReaPerm_C(fiNegReaPerm_A);
			// req.getCbreRequest_C().setFiNegReaOffice_C(fiNegReaOffice_A);
			req.getCbreRequest_C().setIncomeProof_C(leadReq.getCoAppLeadDetails().getIncomeProof_C());
			req.getCbreRequest_C()
					.setMobileConnection_C(leadReq.getCoAppLeadDetails().getMobileNo() != null
							? leadReq.getCoAppLeadDetails().getMobileNo().toString().toUpperCase()
							: null);
			req.getCbreRequest_C().setPresentCity_C(leadReq.getCoAppLeadDetails().getPresCityId() != null
					? MasterCacheMap.getCityByIcasId(leadReq.getCoAppLeadDetails().getPresCityId().toString())
							.getCityName().toUpperCase()
					: null);
			System.out.println("Coapp Pres City === " + req.getCbreRequest_C().getPresentCity_C());
			req.getCbreRequest_C()
					.setPrimaryEmployment_C(leadReq.getCoAppLeadDetails().getEmpTypeId() != null
							? MasterCacheMap.getPrimaryEmpByIcasId(leadReq.getCoAppLeadDetails().getEmpTypeId())
									.getEmpType().toUpperCase()
							: null);
			req.getCbreRequest_C()
					.setPrimaryEmpType_C(leadReq.getCoAppLeadDetails().getSubEmpTypeId() != null
							? MasterCacheMap.getSubEmpByIcasId(leadReq.getCoAppLeadDetails().getSubEmpTypeId())
									.getSubEmpType().toUpperCase()
							: null);

			req.getCbreRequest_C()
					.setPropertyStatus_C(leadReq.getCoAppLeadDetails().getPropertyStatusId() != null
							? MasterCache.getLovByIcasId(leadReq.getCoAppLeadDetails().getPropertyStatusId().toString(),
									MstConstants.LOV_TYPES.PROPERTY_STATUS).getDisplayName().toUpperCase()
							: null);

			req.getCbreRequest_C()
					.setResidenceStatus_C(
							leadReq.getCoAppLeadDetails().getResStatusId() != null
									? MasterCache
											.getLovByIcasId(leadReq.getCoAppLeadDetails().getResStatusId().toString(),
													MstConstants.LOV_TYPES.RESIDENCE_STATUS)
											.getDisplayName().toUpperCase()
									: null);

			Integer residingSinceYrC = null;
			Integer residingSinceMthC = null;
			if (leadReq.getCoAppLeadDetails().getResSinceInNoYear() != null
					&& leadReq.getCoAppLeadDetails().getResSinceInNoMths() != null) {
				residingSinceYrC = Integer.valueOf(leadReq.getCoAppLeadDetails().getResSinceInNoYear());
				residingSinceMthC = Integer.valueOf(leadReq.getCoAppLeadDetails().getResSinceInNoMths());
			}
			req.getCbreRequest_C()
					.setResidingSince_C(leadReq.getCoAppLeadDetails().getResSinceInNoYear() != null
							&& leadReq.getCoAppLeadDetails().getResSinceInNoMths() != null
									? (residingSinceYrC * 12 + residingSinceMthC)
									: null);

			req.getCbreRequest_C()
					.setTotalIncome_C(leadReq.getCoAppLeadDetails().getNetIncome() != null
							? leadReq.getCoAppLeadDetails().getNetIncome().intValue() * 12
							: 0);
			req.getCbreRequest_C()
					.setMonthlyIncome_C(leadReq.getCoAppLeadDetails().getNetIncome() != null
							? leadReq.getCoAppLeadDetails().getNetIncome().intValue()
							: 0);
			Integer workingSinceYr = null;
			Integer wokingSinceMth = null;
			if (leadReq.getCoAppLeadDetails().getWorkingSinceInNoYear() != null
					&& leadReq.getCoAppLeadDetails().getWorkingSinceInNoMths() != null) {
				workingSinceYr = Integer.valueOf(leadReq.getCoAppLeadDetails().getWorkingSinceInNoYear());
				wokingSinceMth = Integer.valueOf(leadReq.getCoAppLeadDetails().getWorkingSinceInNoMths());
			}
			req.getCbreRequest_C()
					.setWorkingSince_C(leadReq.getCoAppLeadDetails().getWorkingSinceInNoYear() != null
							&& leadReq.getCoAppLeadDetails().getWorkingSinceInNoMths() != null
									? (workingSinceYr * 12 + wokingSinceMth)
									: null);

			// req.getCbreRequest_C().setWorkingSinceFI_C(workingSinceFI_A);
			if (leadReq.getCoAppLeadDetails().getBureauCalcResponse() != null) {
				req.getCbreRequest_C().setBureauScore_C(
						leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBureau_score() != null
								? Integer.valueOf(
										leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBureau_score())
								: null);
				req.getCbreRequest_C()
						.setBureauType_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBureau() != null
								? leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBureau().toUpperCase()
								: null);

				req.getCbreRequest_C()
						.setMaxClosureDateLT3_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatelessthen_3year_cc() != null
										? (leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatelessthen_3year_cc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_C()
						.setMaxClosureDateLT3_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatelessthen3year_ncc() != null
										? (leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatelessthen3year_ncc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_C()
						.setMaxClosureDateGT3_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatemorethen_3year_cc() != null
										? (leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatemorethen_3year_cc() > 0 ? "TRUE" : "FALSE")
										: null);
				req.getCbreRequest_C()
						.setMaxClosureDateGT3_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_anyclosuredatemorethen3year_ncc() != null
										? (leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_anyclosuredatemorethen3year_ncc() > 0 ? "TRUE" : "FALSE")
										: null);

				req.getCbreRequest_C()
						.setOverdueNonCCAccQualMaxAmt_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverduenonccaccounts_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverduenonccaccounts_amount().doubleValue()
										: null);
				req.getCbreRequest_C()
						.setOverdueNonCCAccQualMaxDPD_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverdueddpnonccaccount_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverdueddpnonccaccount_amount().doubleValue()
										: null);
				req.getCbreRequest_C()
						.setOverdueCCAccQualMaxAmt_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxoverdueccaccounts_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxoverdueccaccounts_amount().doubleValue()
										: null);

				req.getCbreRequest_C()
						.setWrittenOffCCAccQualMaxAmt_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffccaccounts_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffccaccounts_amount().doubleValue()
										: null);
				req.getCbreRequest_C()
						.setWrittenOffNonCCAccQualMaxDPD_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffddpnonccaccount_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffddpnonccaccount_amount().doubleValue()
										: null);
				req.getCbreRequest_C()
						.setWrittenOffNonCCAccQualMaxAmt_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse()
								.getIcas_maxwrittenoffnonccaccount_amount() != null
										? leadReq.getCoAppLeadDetails().getBureauCalcResponse()
												.getIcas_maxwrittenoffnonccaccount_amount().doubleValue()
										: null);

				req.getCbreRequest_C()
						.setBSBand_C(leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBand_code() != null
								? leadReq.getCoAppLeadDetails().getBureauCalcResponse().getBand_code().toUpperCase()
								: null);
				req.getCbreRequest_C().setWO_OD_Settled_Status_C(
						leadReq.getCoAppLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus() != null
								? leadReq.getCoAppLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus()
										.toString().toUpperCase()
								: null);
			}

			req.getCbreRequest_C()
					.setCropsPerYear_C(leadReq.getCoAppLeadDetails().getNoOfCropsPerYear() != null
							? leadReq.getCoAppLeadDetails().getNoOfCropsPerYear().toString()
							: null);
			req.getCbreRequest_C()
					.setLandHoldingOwn_C(leadReq.getCoAppLeadDetails().getLandHoldingOwn() != null
							? leadReq.getCoAppLeadDetails().getLandHoldingOwn()
							: null);
			req.getCbreRequest_C()
					.setLandHoldingLea_C(leadReq.getCoAppLeadDetails().getLandHoldingLea() != null
							? leadReq.getCoAppLeadDetails().getLandHoldingLea()
							: null);
			req.getCbreRequest_C()
					.setNoOfBouncing_C(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing() != null
							? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing())
							: null);

			req.getCbreRequest_C().setPresentAddrAsPermAddr_C(
					leadReq.getCoAppLeadDetails().getRcp() != null ? leadReq.getCoAppLeadDetails().getRcp() : null);

			// req.getCbreRequest_C().setProneArea_C(proneArea_A);
			req.getCbreRequest_C()
					.setFraudMatchFlag_C(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflagc() != null
							? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflagc())
							: null);

			req.getCbreRequest_C()
					.setAge_C(leadReq.getCoAppLeadDetails().getAgeInMonth() != null
							? leadReq.getCoAppLeadDetails().getAgeInMonth() / 12
							: null);
			// req.getCbreRequest_C().setPinCodeMatchedOff_C(pinCodeMatchedOff_C);
			// req.getCbreRequest_C().setPinCodeMatchedPer_C(pinCodeMatchedPer_C);
			// req.getCbreRequest_C().setPinCodeMatchedRes_C(pinCodeMatchedRes_C);

			// req.getCbreRequest_C().setFIPres_C(fIPres_C);
			// req.getCbreRequest_C().setFIPerm_C(fIPerm_C);
			// req.getCbreRequest_C().setFIOff_C(fIOff_C);

			// req.getCbreRequest_C().setFI_Office_C();
			// req.getCbreRequest_C().setFi_Status_C();
			// req.getCbreRequest_C().setFi_Type_C();
			// req.getCbreRequest_C().setFI_Residence_C();

			req.getCbreRequest_C()
					.setHRPProfile_C(leadReq.getCoAppLeadDetails().getApplProfile() != null
							? (leadReq.getCoAppLeadDetails().getApplProfile().startsWith("HRP") ? "YES" : "NO")
							: null);
			req.getCbreRequest_C()
					.setProfile_C(leadReq.getCoAppLeadDetails().getApplProfile() != null
							? leadReq.getCoAppLeadDetails().getApplProfile()
							: null);
			// req.getCbreRequest_C().setTVR_Status_C(tVR_Status_A);
			// req.getCbreRequest_C().setTPC_C(tPC_C);
			// req.getCbreRequest_C().setFM_C(fM_C);
			// req.getCbreRequest_C().setNA_present_C(nA_present_C);
			// req.getCbreRequest_C().setNP_present_C(nP_present_C);
			// req.getCbreRequest_C().setPA_present_C(pA_present_C);
			req.getCbreRequest_C().setNA_NegativeArea_C(leadReq.getCoAppLeadDetails().isNegArea() ? "YES" : "NO");
		}
		return req;
	}

	private CreditBreRequest ApplicantFiledsMapping(CreditBreRequest req, CbreLeadReq leadReq) {

		System.out.println("leadReq :: " + leadReq);
		System.out.println("leadReq.getLeadDetails() :: " + leadReq.getLeadDetails());
		System.out.println("leadReq.getLeadDetails().getLeadId() :: " + leadReq.getLeadDetails().getLeadId());

		if (leadReq.getAppLeadDetails().getLandHoldingType() != null) {
			req.getCbreRequest_A()
					.setLandHoldingType_A(leadReq.getAppLeadDetails().getLandHoldingType().toString().toUpperCase());
			if (leadReq.getAppLeadDetails().getLandHoldingType().equalsIgnoreCase("Owned")) {
				req.getCbreRequest_A().setLandHoldingOwn_A("YES");
			}
			if (leadReq.getAppLeadDetails().getLandHoldingType().equalsIgnoreCase("Leased")) {
				req.getCbreRequest_A().setLandHoldingLea_A("YES");
			}
		}

		req.getCbreRequest_A()
				.setCropsPerYear_A(leadReq.getAppLeadDetails().getNoOfCropsPerYear() != null
						? leadReq.getAppLeadDetails().getNoOfCropsPerYear().toString()
						: null);
		req.getCbreRequest_A()
				.setLeadId(leadReq.getLeadDetails().getLeadId() != null ? leadReq.getLeadDetails().getLeadId() : null);
		req.getCbreRequest_A()
				.setUid_A(leadReq.getLeadDetails().getUid() != null ? leadReq.getLeadDetails().getUid() : null);
		req.getCbreRequest_A()
				.setGender_A(leadReq.getAppLeadDetails().getGender_A() != null
						? leadReq.getAppLeadDetails().getGender_A().toUpperCase()
						: null);
		req.getCbreRequest_A().setPresentAddrAsPermAddr_A(
				leadReq.getAppLeadDetails().getRcp() != null ? leadReq.getAppLeadDetails().getRcp() : null);
		req.getCbreRequest_A().setPresentAddrAsOffAddr_A(
				leadReq.getAppLeadDetails().getRco() != null ? leadReq.getAppLeadDetails().getRco() : null);
		req.getCbreRequest_A()
				.setLandlineNo_A(leadReq.getAppLeadDetails().getLandlineNo() != null
						? leadReq.getAppLeadDetails().getLandlineNo()
						: null);
		req.getCbreRequest_A()
				.setBusinessLandlineNo(leadReq.getAppLeadDetails().getOffAddressLandLine() != null
						? leadReq.getAppLeadDetails().getOffAddressLandLine()
						: null);

		req.getCbreRequest_A()
				.setPresentState_A(leadReq.getAppLeadDetails().getPresStateId() != null ? MasterCacheMap
						.getStateByIcasId(leadReq.getAppLeadDetails().getPresStateId().toString()).getStateName()
						: null);
		req.getCbreRequest_A()
				.setConstitution_A(
						leadReq.getLeadDetails()
								.getConstitutionId() != null
										? MasterCache
												.getLovByIcasId(leadReq.getLeadDetails().getConstitutionId().toString(),
														MstConstants.LOV_TYPES.CONSTITUTION)
												.getDisplayName().toUpperCase()
										: null);
		req.getCbreRequest_A()
				.setDedupeAFCount_A(leadReq.getLeadDetails().getDedupeResponse().getDedupe_af_count_l() != null
						? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getDedupe_af_count_l())
						: null);
		req.getCbreRequest_A()
				.setDedupeStatus_A(leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a() != null
						? leadReq.getLeadDetails().getDedupeResponse().getL_dedupe_status_a().toUpperCase()
						: null);
		req.getCbreRequest_A()
				.setDedupeStatusAF_A(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l() != null
						? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_af_a_l().toUpperCase()
						: null);
		req.getCbreRequest_A()
				.setDedupeStatusCF_A(leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l() != null
						? leadReq.getLeadDetails().getDedupeResponse().getDedupe_status_cf_a_l().toUpperCase()
						: null);
		req.getCbreRequest_A()
				.setDedupeTenure_A(leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l() != null
						? leadReq.getLeadDetails().getDedupeResponse().getTenure_a_l().toUpperCase()
						: null);
		req.getCbreRequest_A().setDobIncorp_A(
				leadReq.getAppLeadDetails().getDobDate() != null ? leadReq.getAppLeadDetails().getDobDate() : null);
		// req.getCbreRequest_A().setFiNegReaResi_A(fiNegReaResi_A);
		// req.getCbreRequest_A().setFiNegReaPerm_A(fiNegReaPerm_A);
		// req.getCbreRequest_A().setFiNegReaOffice_A(fiNegReaOffice_A);
		req.getCbreRequest_A().setIncomeProof_A(leadReq.getAppLeadDetails().getIncomeProof_A());
		req.getCbreRequest_A()
				.setMobileConnection_A(leadReq.getAppLeadDetails().getMobileNo() != null
						? leadReq.getAppLeadDetails().getMobileNo().toString().toUpperCase()
						: null);
		req.getCbreRequest_A()
				.setPresentCity_A(leadReq.getAppLeadDetails().getPresCityId() != null
						? MasterCacheMap.getCityByIcasId(leadReq.getAppLeadDetails().getPresCityId().toString())
								.getCityName().toUpperCase()
						: null);
		System.out.println("App Pres City === " + req.getCbreRequest_A().getPresentCity_A());
		req.getCbreRequest_A()
				.setPrimaryEmployment_A(
						leadReq.getAppLeadDetails().getEmpTypeId() != null
								? MasterCacheMap.getPrimaryEmpByIcasId(leadReq.getAppLeadDetails().getEmpTypeId())
										.getEmpType().toUpperCase()
								: null);
		req.getCbreRequest_A()
				.setPrimaryEmpType_A(leadReq.getAppLeadDetails().getSubEmpTypeId() != null
						? MasterCacheMap.getSubEmpByIcasId(leadReq.getAppLeadDetails().getSubEmpTypeId())
								.getSubEmpType().toUpperCase()
						: null);

		req.getCbreRequest_A()
				.setPropertyStatus_A(
						leadReq.getAppLeadDetails().getPropertyStatusId() != null
								? MasterCache
										.getLovByIcasId(leadReq.getAppLeadDetails().getPropertyStatusId().toString(),
												MstConstants.LOV_TYPES.PROPERTY_STATUS)
										.getDisplayName().toUpperCase()
								: null);

		req.getCbreRequest_A()
				.setResidenceStatus_A(
						leadReq.getAppLeadDetails()
								.getResStatusId() != null
										? MasterCache
												.getLovByIcasId(leadReq.getAppLeadDetails().getResStatusId().toString(),
														MstConstants.LOV_TYPES.RESIDENCE_STATUS)
												.getDisplayName().toUpperCase()
										: null);
		System.out.println(" RESIDING SINCE ====== " + leadReq.getAppLeadDetails().getResSinceInNoMths());
		System.out.println("CROPS PER YEAR ========== " + leadReq.getAppLeadDetails().getCropsPerYear());
		req.getCbreRequest_A()
				.setResidingSince_A(leadReq.getAppLeadDetails().getResSinceInNoMths() != null
						? leadReq.getAppLeadDetails().getResSinceInNoMths()
						: null);
		// req.getCbreRequest_A().setResidingSinceFI_A(leadReq.getAppLeadDetails().getRes);
		req.getCbreRequest_A()
				.setTotalIncome_A(leadReq.getAppLeadDetails().getNetIncome() != null
						? leadReq.getAppLeadDetails().getNetIncome().intValue() * 12
						: 0);
		req.getCbreRequest_A()
				.setMonthlyIncome_A(leadReq.getAppLeadDetails().getNetIncome() != null
						? leadReq.getAppLeadDetails().getNetIncome().intValue()
						: 0);

		req.getCbreRequest_A()
				.setWorkingSince_A(leadReq.getAppLeadDetails().getWorkingSinceInNoYear() != null
						&& leadReq.getAppLeadDetails().getWorkingSinceInNoMths() != null
								? (leadReq.getAppLeadDetails().getWorkingSinceInNoYear() * 12
										+ leadReq.getAppLeadDetails().getWorkingSinceInNoMths())
								: null);

		Integer residingSinceYrA = null;
		Integer residingSinceMthA = null;
		if (leadReq.getAppLeadDetails().getResSinceInNoYear() != null
				&& leadReq.getAppLeadDetails().getResSinceInNoMths() != null) {
			residingSinceYrA = Integer.valueOf(leadReq.getAppLeadDetails().getResSinceInNoYear());
			residingSinceMthA = Integer.valueOf(leadReq.getAppLeadDetails().getResSinceInNoMths());
		}
		req.getCbreRequest_C()
				.setResidingSince_C(leadReq.getAppLeadDetails().getResSinceInNoYear() != null
						&& leadReq.getAppLeadDetails().getResSinceInNoMths() != null
								? (residingSinceYrA * 12 + residingSinceMthA)
								: null);

		// req.getCbreRequest_A().setWorkingSinceFI_A(workingSinceFI_A);
		if (leadReq.getAppLeadDetails().getBureauCalcResponse() != null) {

			req.getCbreRequest_A()
					.setBureauScoreA(leadReq.getAppLeadDetails().getBureauCalcResponse().getBureau_score() != null
							? Integer.valueOf(leadReq.getAppLeadDetails().getBureauCalcResponse().getBureau_score())
							: null);
			req.getCbreRequest_A()
					.setBureauTypeA(leadReq.getAppLeadDetails().getBureauCalcResponse().getBureau() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse().getBureau().toUpperCase()
							: null);

			req.getCbreRequest_A().setOverdueNonCCAccQualMaxAmt_A(
					leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_maxoverduenonccaccounts_amount() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse()
									.getIcas_maxoverduenonccaccounts_amount().doubleValue()
							: null);
			req.getCbreRequest_A()
					.setOverdueNonCCAccQualMaxDPD_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_maxoverdueddpnonccaccount_amount() != null
									? leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_maxoverdueddpnonccaccount_amount().doubleValue()
									: null);
			req.getCbreRequest_A().setOverdueCCAccQualMaxAmt_A(
					leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_maxoverdueccaccounts_amount() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_maxoverdueccaccounts_amount()
									.doubleValue()
							: null);

			req.getCbreRequest_A().setWrittenOffCCAccQualMaxAmt_A(
					leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_maxwrittenoffccaccounts_amount() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse()
									.getIcas_maxwrittenoffccaccounts_amount().doubleValue()
							: null);
			req.getCbreRequest_A()
					.setWrittenOffNonCCAccQualMaxAmt_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_maxwrittenoffnonccaccount_amount() != null
									? leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_maxwrittenoffnonccaccount_amount().doubleValue()
									: null);
			req.getCbreRequest_A().setWrittenOffCCAccQualMaxDPD_A(
					leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_maxwrittenoffccaccounts_amount() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse()
									.getIcas_maxwrittenoffccaccounts_amount().doubleValue()
							: null);

			req.getCbreRequest_A()
					.setMaxClosureDateLT3_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_anyclosuredatelessthen_3year_cc() != null
									? (leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_anyclosuredatelessthen_3year_cc() > 0 ? "TRUE" : "FALSE")
									: null);
			req.getCbreRequest_A()
					.setMaxClosureDateLT3_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_anyclosuredatelessthen3year_ncc() != null
									? (leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_anyclosuredatelessthen3year_ncc() > 0 ? "TRUE" : "FALSE")
									: null);
			req.getCbreRequest_A()
					.setMaxClosureDateGT3_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_anyclosuredatemorethen_3year_cc() != null
									? (leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_anyclosuredatemorethen_3year_cc() > 0 ? "TRUE" : "FALSE")
									: null);
			req.getCbreRequest_A()
					.setMaxClosureDateGT3_A(leadReq.getAppLeadDetails().getBureauCalcResponse()
							.getIcas_anyclosuredatemorethen3year_ncc() != null
									? (leadReq.getAppLeadDetails().getBureauCalcResponse()
											.getIcas_anyclosuredatemorethen3year_ncc() > 0 ? "TRUE" : "FALSE")
									: null);

			req.getCbreRequest_A().setWO_OD_Settled_Status_A(
					leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse().getIcas_wo_odsettledstatus()
									.toString().toUpperCase()
							: null);
			req.getCbreRequest_A()
					.setBSBand_A(leadReq.getAppLeadDetails().getBureauCalcResponse().getBand_code() != null
							? leadReq.getAppLeadDetails().getBureauCalcResponse().getBand_code().toUpperCase()
							: null);

		}

		req.getCbreRequest_A()
				.setLandHoldingOwn_A(leadReq.getAppLeadDetails().getLandHoldingOwn() != null
						? leadReq.getAppLeadDetails().getLandHoldingOwn()
						: null);
		req.getCbreRequest_A()
				.setLandHoldingLea_A(leadReq.getAppLeadDetails().getLandHoldingLea() != null
						? leadReq.getAppLeadDetails().getLandHoldingLea()
						: null);
		req.getCbreRequest_A()
				.setNoOfBouncing_A(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing() != null
						? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_no_of_bouncing())
						: null);

		// req.getCbreRequest_A().setProneArea_A(proneArea_A);

		req.getCbreRequest_A()
				.setAge_A(leadReq.getAppLeadDetails().getAgeInMonth() != null
						? leadReq.getAppLeadDetails().getAgeInMonth() / 12
						: null);
		// req.getCbreRequest_A().setPinCodeMatchedOff_A(pinCodeMatchedOff_A);
		// req.getCbreRequest_A().setPinCodeMatchedPer_A(pinCodeMatchedPer_A);
		// req.getCbreRequest_A().setPinCodeMatchedRes_A(pinCodeMatchedRes_A);
		// req.getCbreRequest_A().setTVR_BusinessStatus();
		// req.getCbreRequest_A().setTVR_PermAddressStatus();
		// req.getCbreRequest_A().setTVR_ReferenceStatus_1(tVR_ReferenceStatus_1);
		// req.getCbreRequest_A().setTVR_ReferenceStatus_2(tVR_ReferenceStatus_2);
		// req.getCbreRequest_A().setTVR_Status(tVR_Status);
		// req.getCbreRequest_A().setTVR_Status_A(tVR_Status_A);
		req.getCbreRequest_A().setNA_NegativeArea_A(leadReq.getAppLeadDetails().isNegArea() ? "YES" : "NO");

		// req.getCbreRequest_A().setFIPres_A(fIPres_A);
		// req.getCbreRequest_A().setFIPerm_A(fIPerm_A);
		req.getCbreRequest_A()
				.setHRPProfile_A(leadReq.getAppLeadDetails().getApplProfile() != null
						? (leadReq.getAppLeadDetails().getApplProfile().startsWith("HRP") ? "YES" : "NO")
						: null);
		req.getCbreRequest_A()
				.setProfile_A(leadReq.getAppLeadDetails().getApplProfile() != null
						? leadReq.getAppLeadDetails().getApplProfile()
						: null);
		// req.getCbreRequest_A().setFIOff_A(fIOff_A);
		// req.getCbreRequest_A().setTPC_A(tPC_A);

		// req.getCbreRequest_A().setFI_Office_A();
		// req.getCbreRequest_A().setFi_Status_A();
		// req.getCbreRequest_A().setFi_Type_A();
		req.getCbreRequest_A()
				.setFraudMatchFlag_A(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflaga() != null
						? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getL_fraudmatchflaga())
						: null);
		return req;
	}

	private CreditBreRequest commonFiledsMapping(CreditBreRequest req, CbreLeadReq leadReq) {
		leadReq.getLeadDetails().setCustomerType("1");
		req.setCoAppChange(leadReq.getLeadDetails().isCoAppChange());
		req.setGrntrChange(leadReq.getLeadDetails().isGrntrChange());

		req.setDisbursementDateOldLAN(
				leadReq.getLeadDetails().getDisbDate() != null ? leadReq.getLeadDetails().getDisbDate() : null);

		if (leadReq.getLeadDetails().getDisbDate() != null) {
			System.out.println("Login Date : " + leadReq.getLeadDetails().getDisbDate());
		}

		req.setLoginDate(
				leadReq.getLeadDetails().getLoginDate() != null ? leadReq.getLeadDetails().getLoginDate() : null);

		req.setLeadId(leadReq.getLeadDetails().getLeadId() != null ? leadReq.getLeadDetails().getLeadId() : null);
		req.setUid_A(leadReq.getLeadDetails().getUid() != null ? leadReq.getLeadDetails().getUid() : null);
		req.setUid_C(leadReq.getLeadDetails().getUid_C() != null ? leadReq.getLeadDetails().getUid_C() : null);
		req.setUid_G(leadReq.getLeadDetails().getUid_G() != null ? leadReq.getLeadDetails().getUid_G() : null);

		req.setPresent_C(leadReq.getLeadDetails().isPresent_C() ? "TRUE" : "FALSE");
		req.setPresent_G(leadReq.getLeadDetails().isPresent_G() ? "TRUE" : "FALSE");
		System.out.println("LTV >>>>>>>>> " + leadReq.getLeadDetails().getLtv());
		System.out.println("Actual LTV >>>>>>>>>> " + leadReq.getLeadDetails().getLtv());
		System.out.println("Eligible LTV >>>>>>>>>> " + leadReq.getLeadDetails().getEligibleLtv());
		if (leadReq.getCoAppLeadDetails() != null) {
			req.setRelWithApp_C(leadReq.getCoAppLeadDetails().getCoRelationshipWithApplicant() != null
					? leadReq.getCoAppLeadDetails().getCoRelationshipWithApplicant().toString().toUpperCase()
					: null);
			req.setCoAppRelation(leadReq.getCoAppLeadDetails().getCoRelationshipWithApplicant() != null
					? leadReq.getCoAppLeadDetails().getCoRelationshipWithApplicant().toString().toUpperCase()
					: null);
		}
		req.setAppliedNetLtv(leadReq.getLeadDetails().getLtv() != null ? leadReq.getLeadDetails().getLtv() : null);
		req.setCoAppRelation("NO RELATION"); // TO DO Hardcoded
		req.setEMI(leadReq.getLeadDetails().getEmi() != null ? leadReq.getLeadDetails().getEmi() : null);
		req.setFutureEMI(leadReq.getLeadDetails().getDedupeResponse().getFuture_emi_l() != null
				? Double.valueOf(leadReq.getLeadDetails().getDedupeResponse().getFuture_emi_l())
				: 0.0D);
		req.setNoOfFutureEMI(leadReq.getLeadDetails().getDedupeResponse().getFuture_emi_l() != null
				? Integer.valueOf(leadReq.getLeadDetails().getDedupeResponse().getFuture_emi_l())
				: 0);
		req.setAdvanceEMIAmt(leadReq.getLeadDetails().getAdvanceEmiAmount() != null
				? leadReq.getLeadDetails().getAdvanceEmiAmount().intValue()
				: null);

		req.setLTV(leadReq.getLeadDetails().getLtv() != null ? leadReq.getLeadDetails().getLtv() : null);
		req.setRegistrationNo(
				leadReq.getLeadDetails().getRegistrationNo() != null ? leadReq.getLeadDetails().getRegistrationNo()
						: null);

		req.setNoOfVehicles(
				leadReq.getLeadDetails().getNoOfVehicles() != null ? leadReq.getLeadDetails().getNoOfVehicles() : null);
		req.setTotalNumberOfVehicle(leadReq.getLeadDetails().getDedupeResponse() != null
				? leadReq.getLeadDetails().getDedupeResponse().getTotal_number_of_vehicle_l()
				: null); // applied no of vehicles + no of vehicles from dedupe result
		req.setTenure(leadReq.getLeadDetails().getTenure());
		req.setProduct(
				leadReq.getLeadDetails().getProductFlag() != null ? leadReq.getLeadDetails().getProductFlag() : null);
		req.setProductCategory(
				leadReq.getLeadDetails().getProductFlag() != null ? leadReq.getLeadDetails().getProductFlag() : null);
		req.setAmountFinanced(leadReq.getLeadDetails().getOfferAmount());
		req.setAppliedFinanceAmt(leadReq.getLeadDetails().getOfferAmount());
		req.setTotalAmountFinanced(leadReq.getLeadDetails().getTotalAmountFinanced()!=null ? 
				leadReq.getLeadDetails().getTotalAmountFinanced() : null);
		System.out.println("Total Amount Financed == "+leadReq.getLeadDetails().getTotalAmountFinanced());
		// loan amount

		req.setMarginMoney(leadReq.getLeadDetails().getMarginMoney());
		req.setCustomerType(leadReq.getLeadDetails().getCustomerType());

		req.setRepaymentMode(leadReq.getLeadDetails().getRepaymentModeId() != null ? MasterCache
				.getLovByIcasId(leadReq.getLeadDetails().getRepaymentModeId(), MstConstants.LOV_TYPES.REPAYMENT_MODE)
				.getDisplayName().toUpperCase() : null);
		if (leadReq.getLeadDetails().getRepaymentFromId() != null) {
			if ("1".equalsIgnoreCase(leadReq.getLeadDetails().getRepaymentFromId())) {
				// leadReq.getLeadDetails().setRepaymentFromId("A");
				req.setRepaymentFrom("A");
			} else {
				// leadReq.getLeadDetails().setRepaymentFromId("C");
				req.setRepaymentFrom("C");
			}
		}
		/*
		 * req.setRepaymentFrom(leadReq.getLeadDetails().getRepaymentFromId() != null ?
		 * MasterCache.getLovByIcasId(leadReq.getLeadDetails().getRepaymentFromId().
		 * toString(), MstConstants.LOV_TYPES.REPAY_FRM).getDisplayName().toUpperCase()
		 * : null);
		 */

		req.setABB(leadReq.getLeadDetails().getAvgBankBalanceAmt() != null
				? leadReq.getLeadDetails().getAvgBankBalanceAmt().intValue()
				: null);
		// req.setSubscriberId(subscriberId);
		// req.setRuleId(ruleId);
		// req.setLayoutId(layoutId);
		/*
		 * req.setAccountVintage(leadReq.getLeadDetails().getBankVintageId() != null ?
		 * MasterCache.getLovByIcasId(leadReq.getLeadDetails().getBankVintageId().
		 * toString(),
		 * MstConstants.LOV_TYPES.BANK_VINTAGE).getDisplayName().toUpperCase() : null);
		 */

		req.setRegistrationNo(
				leadReq.getLeadDetails().getRegistrationNo() != null ? leadReq.getLeadDetails().getRegistrationNo()
						: null);
		// req.setLoginDate(leadReq.getLo);
		// req.setDisbursementDateOldLAN(disbursementDateOldLAN);
		req.setBlueBookPrice(leadReq.getLeadDetails().getBlueBookPrice() != null
				? Double.valueOf(leadReq.getLeadDetails().getBlueBookPrice())
				: null);
		/*
		 * req.setSchemeType(leadReq.getLeadDetails().getSchemeType() != null ?
		 * MasterCache .getLovByIcasId(leadReq.getLeadDetails().getSchemeType(),
		 * MstConstants.LOV_TYPES.SCHEME_TYPE) .getDisplayName().toUpperCase() : null);
		 */
		req.setSchemeType(leadReq.getLeadDetails().getSchemeType() != null
				? leadReq.getLeadDetails().getSchemeType().toString().toUpperCase()
				: null);

		// subcode according to repayment from value
		MstLov subcode = null;
		/*if (leadReq.getLeadDetails().getRbpOfferCalcFor() != null) {

			if (leadReq.getAppLeadDetails().getSubCodeId() != null
					&& "A".equalsIgnoreCase(leadReq.getLeadDetails().getRbpOfferCalcFor())) {
				req.setAccountVintage(leadReq.getAppLeadDetails().getBankVintageId() != null
						? MasterCache.getLovByIcasId(leadReq.getAppLeadDetails().getBankVintageId().toString(),
								MstConstants.LOV_TYPES.BANK_VINTAGE).getDisplayName()
						: null);
				subcode = MasterCache.getLovByIcasId(leadReq.getAppLeadDetails().getSubCodeId().toString(),
						MstConstants.LOV_TYPES.SUB_CODE);
			} else if (leadReq.getCoAppLeadDetails().getSubCodeId() != null
					&& "C".equalsIgnoreCase(leadReq.getLeadDetails().getRbpOfferCalcFor())) {
				req.setAccountVintage(leadReq.getCoAppLeadDetails().getBankVintageId() != null
						? leadReq.getCoAppLeadDetails().getBankVintageId().toString()
						: null);
				subcode = MasterCache.getLovByIcasId(leadReq.getCoAppLeadDetails().getSubCodeId().toString(),
						MstConstants.LOV_TYPES.SUB_CODE);
			} else if (leadReq.getGrntrLeadDetails().getSubCodeId() != null
					&& "G".equalsIgnoreCase(leadReq.getLeadDetails().getRbpOfferCalcFor())) {
				subcode = MasterCache.getLovByIcasId(leadReq.getGrntrLeadDetails().getSubCodeId().toString(),
						MstConstants.LOV_TYPES.SUB_CODE);
			}

			if (subcode != null) {
				req.setSubCode(subcode.getDisplayName().toUpperCase());
			}
		} else {
			leadReq.getLeadDetails().setRbpOfferCalcFor("A");
			if (leadReq.getAppLeadDetails().getSubCodeId() != null
					&& "A".equalsIgnoreCase(leadReq.getLeadDetails().getRbpOfferCalcFor())) {
				subcode = MasterCache.getLovByIcasId(leadReq.getAppLeadDetails().getSubCodeId().toString(),
						MstConstants.LOV_TYPES.SUB_CODE);
			}
		}*/
		
		
		
		if(leadReq.getAppLeadDetails()!=null && leadReq.getAppLeadDetails().getSubCodeId()!=null) {
			System.out.println("App subcode .. "+leadReq.getAppLeadDetails().getSubCodeId());
			leadReq.getLeadDetails().setSubCodeId(leadReq.getAppLeadDetails().getSubCodeId());
		}else if(leadReq.getCoAppLeadDetails()!=null && leadReq.getCoAppLeadDetails().getSubCodeId()!=null) {
			System.out.println("CoApp subcode .. "+leadReq.getCoAppLeadDetails().getSubCodeId());
			Integer sub = Integer.valueOf(leadReq.getCoAppLeadDetails().getSubCodeId());
			leadReq.getLeadDetails().setSubCodeId(sub);
		}else if(leadReq.getGrntrLeadDetails()!=null && leadReq.getGrntrLeadDetails().getSubCodeId()!=null) {
			System.out.println("Guar subcode .. "+leadReq.getGrntrLeadDetails().getSubCodeId());
			leadReq.getLeadDetails().setSubCodeId(leadReq.getGrntrLeadDetails().getSubCodeId());
		}
		
		subcode = MasterCache.getLovByIcasId(leadReq.getLeadDetails().getSubCodeId().toString(),
				MstConstants.LOV_TYPES.SUB_CODE);
		
		if (subcode != null) {
			req.setSubCode(subcode.getDisplayName().toUpperCase());
		}

		req.setCustCatFinal(leadReq.getLeadDetails().getCustCategoryId() != null ? MasterCache
				.getLovByIcasId(leadReq.getLeadDetails().getCustCategoryId(), MstConstants.LOV_TYPES.RISK_CATEGORY)
				.getDisplayName().toUpperCase() : null);

		

		req.setOfferType(
				leadReq.getLeadDetails().getOfferType() != null ? leadReq.getLeadDetails().getOfferType() : null);

		/*
		 * req.setSegment(leadReq.getLeadDetails().getSegment() != null ? MasterCache
		 * .getLovByIcasId(leadReq.getLeadDetails().getSegment(),
		 * MstConstants.LOV_TYPES.VEHICLE_SEGMENT) .getDisplayName().toUpperCase() :
		 * null);
		 */

		if (req != null && req.getProduct() != null && "CV".equalsIgnoreCase(req.getProduct())
				|| "3W".equalsIgnoreCase(req.getProduct()) || "3R".equalsIgnoreCase(req.getProduct())) {
			req.setSegment(leadReq.getLeadDetails().getSegment() != null
					? MasterCache.getLovByQcapCode(leadReq.getLeadDetails().getSegment()).getDisplayName().toUpperCase()
					: null);
		} else {
			req.setSegment(leadReq.getLeadDetails().getSegment() != null ? MasterCache
					.getLovByIcasId(leadReq.getLeadDetails().getSegment(), MstConstants.LOV_TYPES.VEHICLE_SEGMENT)
					.getDisplayName().toUpperCase() : null);
		}
	/*	req.setSegment("EXECUTIVE");*/
		req.setAssetType(leadReq.getLeadDetails().getProductFlag() != null
				? leadReq.getLeadDetails().getProductFlag().toUpperCase()
				: null);
		
		Fin1LeaSchemeM schCode = null ;
		schCode = MasterCacheFinnone.getSchemeBySchemeCode(leadReq.getLeadDetails().getSchemeCodeId()+"");
		if(schCode!=null) {
			req.setSchemeCode(schCode.getSchemedesc().toUpperCase());
		}
		
		Fin1LosSchMaster schGrp = null;
		schGrp =  MasterCacheFinnone.getLosSchById(leadReq.getLeadDetails().getSchemeGroupId()+"");
		
		System.out.println("SCHEME GROUP --- ID = >> "+schGrp.getSchDesc());
		if(schGrp!=null) {
			req.setSchemeGrp(schGrp.getSchDesc().toUpperCase());
		}
		 

		/*if (leadReq.getLeadDetails().getSupplierCodeId() != null) {
			MstSupplierDetail supl = MasterCacheMap
					.getSupplierDetail(Integer.valueOf(leadReq.getLeadDetails().getSupplierCodeId()));
			if (supl != null) {
				req.setBranch(supl.getBranchName().toUpperCase());
				if (supl.getSuppState() != null)
					req.setSupplierState(supl.getSuppState().toUpperCase());
			}
		}*/
		
		if (leadReq.getLeadDetails().getSupplierCodeId() != null) {
			MstSupplierDetail supl = MasterCacheMap.
					getSupplierDetailsBySupplierId(Integer.valueOf(leadReq.getLeadDetails().getSupplierCodeId()));		
					
			if (supl != null) {
				if(supl.getBranchName()!=null) {
					req.setBranch(supl.getBranchName().toUpperCase());
				}
				
				if (supl.getSuppState() != null)
					req.setSupplierState(supl.getSuppState().toUpperCase());
			}
		}
		if(leadReq.getLeadDetails().getSupplierCateogyId()==null) {
			leadReq.getLeadDetails().setSupplierCateogyId("2");
		}
		if (leadReq.getLeadDetails().getSupplierCateogyId() != null) {
			MstLov supplierCat = MasterCache.getLovByIcasId(leadReq.getLeadDetails().getSupplierCateogyId().toString(),
					MstConstants.LOV_TYPES.SUPPLIER_CATEGORY);
			if (supplierCat != null) {
				System.out.println("LOV supl cat ++ " + supplierCat.getDisplayName());
				req.setSupplierCategory(supplierCat.getDisplayName().toUpperCase());
				// req.setSuplCatLtv(MasterCacheMap.supp);
			}
		}
		req.setTotalExposure(leadReq.getLeadDetails().getDedupeResponse().getTotal_exposure_l() != null
				? leadReq.getLeadDetails().getDedupeResponse().getTotal_exposure_l().intValue()
				: null);
		req.setCreatedDate(new Date());

		/*MstMakeModel model = null;
		if(leadReq.getLeadDetails().getModelId() != null) {
			model = MasterCacheMap.getModelByIcasId(leadReq.getLeadDetails().getModelId());
		}*/
		
		MstMakeModel make = null;
		if(leadReq.getLeadDetails().getMakeId() != null) {
			make = MasterCacheMap.getMakeByIcasId(leadReq.getLeadDetails().getMakeId());
		}
		
		req.setMake(make.getMakeName().toUpperCase());
		System.out.println("MAKE = "+req.getMake());
		req.setModel(make.getModelName().toUpperCase());
		System.out.println("MODEL = "+req.getModel());
		System.out.println("FCU STATUS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   ::::::: "
				+ leadReq.getLeadDetails().getRcuStatus());

		req.setEligibleLtv(leadReq.getLeadDetails().getEligibleLtv());
		req.setFcuStatus(leadReq.getLeadDetails().getRcuStatus() != null
				? leadReq.getLeadDetails().getRcuStatus().toString().toUpperCase()
				: null);
		req.setTypeOfRefinance(leadReq.getLeadDetails().getRefinanceType() != null
				? leadReq.getLeadDetails().getRefinanceType().toUpperCase()
				: null);
		MstRbpSubCodeRiskCatLtv cust = null;
		MstRbpSubCodeSupCatLtv supl = null;

		MstRbpSubCodeRiskCatLtvCv custcv = null;
		MstRbpSubCodeSupCatLtvCv suplcv = null;

		String custSubRiskBand = null;
		System.out.println("Product Type : == " + req.getProduct() + " -- " + req.getProductCategory());
		if (req.getProduct() != null && "2W".equalsIgnoreCase(req.getProduct())) {
			if (subcode != null && subcode.getIcasId() != null) {
				logger.warn("subcode is ok " + subcode.getIcasId());
				if (leadReq.getLeadDetails().getMakeId() != null) {
					logger.warn("Make is ok " + leadReq.getLeadDetails().getMakeId());
					if (leadReq.getLeadDetails().getCustCategoryId() != null) {
						logger.warn("Cust Cat is ok " + leadReq.getLeadDetails().getCustCategoryId());
						cust = MasterCacheMap.getNormalBySubCodeMakeRiskCat(subcode.getIcasId(),
								leadReq.getLeadDetails().getMakeId().toString(),
								leadReq.getLeadDetails().getCustCategoryId().toString());
					}
					if (leadReq.getLeadDetails().getSupplierCateogyId() != null) {
						supl = MasterCacheMap.getNormalBySubCodeSuppCat(subcode.getIcasId(),
								leadReq.getLeadDetails().getSupplierCateogyId().toString());
					}
				}
			}
		} else if (req.getProduct() != null && "3W".equalsIgnoreCase(req.getProduct())) {
			if (leadReq.getLeadDetails().getCustCategoryId() != null) {
				logger.warn("Cust Cat is ok " + leadReq.getLeadDetails().getCustCategoryId());
				if (leadReq.getLeadDetails().getSegment() != null) {
					logger.warn("vehicle segment is ok " + leadReq.getLeadDetails().getSegment());
					if (leadReq.getLeadDetails().getCustSubRiskBand() != null) {
						logger.warn("cust risk band is ok " + leadReq.getLeadDetails().getCustSubRiskBand());
						// custSubRiskBand =
						// leadReq.getLeadDetails().getCustSubRiskBand().trim().replace("-"," ");
						custSubRiskBand = leadReq.getLeadDetails().getCustSubRiskBand().trim().replaceAll("\\s", "")
								.replace("-", " ");
						logger.warn("cust risk band converted is ok " + custSubRiskBand);
						custcv = MasterCacheMapCv.getNormalBySubCodeMakeRiskCat(
								leadReq.getLeadDetails().getCustomerType(),
								leadReq.getLeadDetails().getSegment(), custSubRiskBand.toUpperCase());
						req.setCustSubCat(custSubRiskBand.toUpperCase());
					
					}

					if (leadReq.getLeadDetails().getSupplierCateogyId() != null) {
						logger.warn("supplier cat is ok " + leadReq.getLeadDetails().getSupplierCateogyId());

						suplcv = MasterCacheMapCv.getNormalBySubCodeSuppCat(
								leadReq.getLeadDetails().getCustomerType(),
								leadReq.getLeadDetails().getSegment(), leadReq.getLeadDetails().getSupplierCateogyId());
					}

				}
			}

		}

		if (req.getProduct() != null && "2W".equalsIgnoreCase(req.getProduct())) {
			if (supl != null && supl.getLtv() != null) {
				System.out.println("supl = " + supl.getLtv());
				req.setSuplCatLtv(supl.getLtv() != null ? supl.getLtv() : 0.0d);
			} else {
				System.out.println("supl = " + supl);
				req.setSuplCatLtv(0.0d);
			}
			if (cust != null && cust.getLtv() != null) {
				System.out.println("cust = " + cust.getLtv());
				req.setCustCatLtv(cust.getLtv() != null ? cust.getLtv() : 0.0d);
			} else {
				System.out.println("cust = " + cust);
				req.setCustCatLtv(0.0d);
			}
		} else {
			if (suplcv != null && suplcv.getLtv() != null) {
				System.out.println("suplcv = " + suplcv.getLtv());
				req.setSuplCatLtv(suplcv.getLtv() != null ? suplcv.getLtv() : 0.0d);
			} else {
				System.out.println("suplcv = " + suplcv);
				req.setSuplCatLtv(0.0d);
			}
			if (custcv != null && custcv.getLtv() != null) {
				System.out.println("custcv = " + custcv.getLtv());
				req.setCustCatLtv(custcv.getLtv() != null ? custcv.getLtv() : 0.0d);
			
			} else {
				System.out.println("custcv = " + custcv);
				req.setCustCatLtv(0.0d);
			}
		}

		Double value = req.getAppliedNetLtv() - req.getSuplCatLtv();
		/*
		 * System.out.println("Supplier >>>>>>>>>> " + value);
		 * System.out.println("Supplier Cat : " + req.getSupplierCategory());
		 * System.out.println("Supplier LTV : " + req.getSuplCatLtv());
		 */
		return req;
	}
}
