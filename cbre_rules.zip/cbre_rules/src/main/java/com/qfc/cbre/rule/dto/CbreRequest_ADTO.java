package com.qfc.cbre.rule.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cbre_request_a")
public class CbreRequest_ADTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "lead_id")
	private Long leadId;
	@Column(name = "uid_a")
	private String uid_A;
	@Column(name = "gender_a")
	private String gender_A;
	
	@OneToOne
	@JoinColumn(name="bre_req_id")
	private CreditBreRequestDTO breRequestId;
	
	@Column(name = "landline_no_a")
	private String landlineNo_A;
	@Column(name = "buss_landline_no")
	private String bussLandlineNo;	
	@Column(name = "present_state_a")
	private String presentState_A;	// NO C & G
	
	@Column(name = "constitution_a")
	private String constitution_A;
	@Column(name = "dedupe_status_af_a")
	private String dedupeStatusAF_A;
	@Column(name = "dedupe_status_cf_a")
	private String dedupeStatusCF_A;
	@Column(name = "dedupe_status_a")
	private String dedupeStatus_A;
	@Column(name = "dedupe_tenure_a")
	private String dedupeTenure_A;
	@Column(name = "dedupe_count_af_a")
	private Integer dedupeCountAF_A;
	@Column(name = "dob_incorp_a")
	private Date dobIncorp_A;
	@Column(name = "fi_neg_rea_resi_a")
	private String fiNegReaResi_A;
	@Column(name = "fi_neg_rea_perm_a")
	private String fiNegReaPerm_A;
	@Column(name = "fi_neg_rea_office_a")
	private String fiNegReaOffice_A;
	@Column(name = "income_proof_a")
	private String incomeProof_A;
	@Column(name = "mobile_connection_a")
	private String mobileConnection_A;
	@Column(name = "present_city_a")
	private String presentCity_A;
	@Column(name = "primary_employment_a")
	private String primaryEmployment_A;//Diff between primaryEmployment_A & primaryEmpType_A
	@Column(name = "primary_emp_type_a")
	private String primaryEmpType_A;
	@Column(name = "property_status_a")
	private String propertyStatus_A;
	@Column(name = "residence_status_a")
	private String residenceStatus_A;
	@Column(name = "residing_since_a")
	private Integer residingSince_A;		//TODO: Bajaj to confirm the datatype
	@Column(name = "residing_since_fi_a")
	private Integer residingSinceFI_A;
	@Column(name = "total_income_a")
	private Integer totalIncome_A;
	@Column(name = "monthly_income_a")
	private Integer monthlyIncome_A=0;
	@Column(name = "tpc_a")
	private String TPC_A;
	@Column(name = "working_since_a")
	private Integer workingSince_A;
	@Column(name = "working_since_fi_a")
	private Integer workingSinceFI_A;
	@Column(name = "bureau_score_a")
	private Integer bureauScoreA;
	@Column(name = "bureau_type_a")
	private String bureauTypeA;
	@Column(name = "crops_per_year_a")
	private String cropsPerYear_A;
	@Column(name = "land_holding_own_a")
	private String landHoldingOwn_A;
	@Column(name = "land_holding_lea_a")
	private String landHoldingLea_A;
	@Column(name = "no_of_bouncing_a")
	private Integer noOfBouncing_A;
	@Column(name = "max_closure_date_gt3_a")
	private String maxClosureDateGT3_A;
	@Column(name = "max_closure_date_lt3_a")
	private String maxClosureDateLT3_A;
	@Column(name = "present_add_as_perm_addr_a")
	private String presentAddAsPermAddr_A;
	@Column(name = "present_add_as_off_addr_a")
	private String presentAddrAsOffAddr_A;
	
//	@Column(name = "tvr_status")
	private Integer TVR_Status; 	// Diff between this and TVR_AppStatus
	
	@Column(name = "tvr_status_a")
	private String tvrStatus_A;
	@Column(name = "tvr_business_status")
	private String tvrBusinessStatus;
	@Column(name = "tvr_perm_add_status")
	private String tvrPermAddStatus;
	@Column(name = "tvr_ref_status_1")
	private String tvrRefStatus_1;
	@Column(name = "tvr_ref_status_2")
	private String tvrRefStatus_2;
	
	@Column(name = "na_negative_area_a")
	private String naNegativeArea_A;
	@Column(name = "hrp_profile_a")
	private String hrpProfile_A;
	@Column(name = "prone_area_a")
	private String proneArea_A;
	@Column(name = "fraud_match_flag_a")
	private Integer fraudMatchFlag_A;
	@Column(name = "overdue_cc_acc_qual_max_amt_a")
	private Double overdueCCAccQualMaxAmt_A;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_a")
	private Double overdueNonCCAccQualMaxAmt_A;
	@Column(name = "writtenoff_cc_acc_qual_max_dpd_a")
	private Double writtenOffCCAccQualMaxDPD_A; // NO C & G
	@Column(name = "writtenoff_cc_acc_qual_max_amt_a")
	private Double writtenOffCCAccQualMaxAmt_A;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_a")
	private Double writtenOffNonCCAccQualMaxAmt_A;
	@Column(name = "wo_od_settled_status_a")
	private String woODSettledStatus_A;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_a")
	private Double overdueNonCCAccQualMaxDPD_A;
	@Column(name = "age_a")
	private Integer age_A;	//TODO: Bajaj to confirm the age in months, yr or date
	@Column(name = "fi_off_a")
	private String fiOff_A;
	@Column(name = "fi_perm_a")
	private String fiPerm_A;
	@Column(name = "fi_pres_a")
	private String fiPres_A;
	@Column(name = "fi_office_a")
	private String fiOffice_A;
	@Column(name = "pincode_matched_res_a")
	private String pincodeMatchedRes_A;
	@Column(name = "pincode_matched_off_a")
	private String pincodeMatchedOff_A;
	@Column(name = "pincode_matched_per_a")
	private String pincodeMatchedPer_A;
	@Column(name = "bs_band_a")
	private String BSBand_A;
	
	@Column(name = "fi_type_a")
	private String fi_Type_A;
	@Column(name = "fi_status_a")
	private String fi_Status_A;
	@Column(name ="profile_a")
	private String profile_A;
	@Column(name = "landholding_type_a")
	private String landHoldingType_A;
	
	public String getLandHoldingType_A() {
		return landHoldingType_A;
	}
	public void setLandHoldingType_A(String landHoldingType_A) {
		this.landHoldingType_A = landHoldingType_A;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public CreditBreRequestDTO getBreRequestId() {
		return breRequestId;
	}
	public void setBreRequestId(CreditBreRequestDTO breRequestId) {
		this.breRequestId = breRequestId;
	}
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getUid_A() {
		return uid_A;
	}
	public void setUid_A(String uid_A) {
		this.uid_A = uid_A;
	}
	public String getGender_A() {
		return gender_A;
	}
	public void setGender_A(String gender_A) {
		this.gender_A = gender_A;
	}
	public String getLandlineNo_A() {
		return landlineNo_A;
	}
	public void setLandlineNo_A(String landlineNo_A) {
		this.landlineNo_A = landlineNo_A;
	}
	public String getBussLandlineNo() {
		return bussLandlineNo;
	}
	public void setBussLandlineNo(String bussLandlineNo) {
		this.bussLandlineNo = bussLandlineNo;
	}
	public String getPresentState_A() {
		return presentState_A;
	}
	public void setPresentState_A(String presentState_A) {
		this.presentState_A = presentState_A;
	}
	public String getConstitution_A() {
		return constitution_A;
	}
	public void setConstitution_A(String constitution_A) {
		this.constitution_A = constitution_A;
	}
	public String getDedupeStatusAF_A() {
		return dedupeStatusAF_A;
	}
	public void setDedupeStatusAF_A(String dedupeStatusAF_A) {
		this.dedupeStatusAF_A = dedupeStatusAF_A;
	}
	public String getDedupeStatusCF_A() {
		return dedupeStatusCF_A;
	}
	public void setDedupeStatusCF_A(String dedupeStatusCF_A) {
		this.dedupeStatusCF_A = dedupeStatusCF_A;
	}
	public String getDedupeStatus_A() {
		return dedupeStatus_A;
	}
	public void setDedupeStatus_A(String dedupeStatus_A) {
		this.dedupeStatus_A = dedupeStatus_A;
	}
	public String getDedupeTenure_A() {
		return dedupeTenure_A;
	}
	public void setDedupeTenure_A(String dedupeTenure_A) {
		this.dedupeTenure_A = dedupeTenure_A;
	}
	public Integer getDedupeCountAF_A() {
		return dedupeCountAF_A;
	}
	public void setDedupeCountAF_A(Integer dedupeCountAF_A) {
		this.dedupeCountAF_A = dedupeCountAF_A;
	}
	public Date getDobIncorp_A() {
		return dobIncorp_A;
	}
	public void setDobIncorp_A(Date dobIncorp_A) {
		this.dobIncorp_A = dobIncorp_A;
	}
	public String getFiNegReaResi_A() {
		return fiNegReaResi_A;
	}
	public void setFiNegReaResi_A(String fiNegReaResi_A) {
		this.fiNegReaResi_A = fiNegReaResi_A;
	}
	public String getFiNegReaPerm_A() {
		return fiNegReaPerm_A;
	}
	public void setFiNegReaPerm_A(String fiNegReaPerm_A) {
		this.fiNegReaPerm_A = fiNegReaPerm_A;
	}
	public String getFiNegReaOffice_A() {
		return fiNegReaOffice_A;
	}
	public void setFiNegReaOffice_A(String fiNegReaOffice_A) {
		this.fiNegReaOffice_A = fiNegReaOffice_A;
	}
	public String getIncomeProof_A() {
		return incomeProof_A;
	}
	public void setIncomeProof_A(String incomeProof_A) {
		this.incomeProof_A = incomeProof_A;
	}
	public String getMobileConnection_A() {
		return mobileConnection_A;
	}
	public void setMobileConnection_A(String mobileConnection_A) {
		this.mobileConnection_A = mobileConnection_A;
	}
	public String getPresentCity_A() {
		return presentCity_A;
	}
	public void setPresentCity_A(String presentCity_A) {
		this.presentCity_A = presentCity_A;
	}
	public String getPrimaryEmployment_A() {
		return primaryEmployment_A;
	}
	public void setPrimaryEmployment_A(String primaryEmployment_A) {
		this.primaryEmployment_A = primaryEmployment_A;
	}
	public String getPrimaryEmpType_A() {
		return primaryEmpType_A;
	}
	public void setPrimaryEmpType_A(String primaryEmpType_A) {
		this.primaryEmpType_A = primaryEmpType_A;
	}
	public String getPropertyStatus_A() {
		return propertyStatus_A;
	}
	public void setPropertyStatus_A(String propertyStatus_A) {
		this.propertyStatus_A = propertyStatus_A;
	}
	public String getResidenceStatus_A() {
		return residenceStatus_A;
	}
	public void setResidenceStatus_A(String residenceStatus_A) {
		this.residenceStatus_A = residenceStatus_A;
	}
	
	public Integer getTotalIncome_A() {
		return totalIncome_A;
	}
	public void setTotalIncome_A(Integer totalIncome_A) {
		this.totalIncome_A = totalIncome_A;
	}
	public String getTPC_A() {
		return TPC_A;
	}
	public void setTPC_A(String tPC_A) {
		TPC_A = tPC_A;
	}

	public Integer getResidingSince_A() {
		return residingSince_A;
	}
	public void setResidingSince_A(Integer residingSince_A) {
		this.residingSince_A = residingSince_A;
	}
	public Integer getResidingSinceFI_A() {
		return residingSinceFI_A;
	}
	public void setResidingSinceFI_A(Integer residingSinceFI_A) {
		this.residingSinceFI_A = residingSinceFI_A;
	}
	public Integer getWorkingSince_A() {
		return workingSince_A;
	}
	public void setWorkingSince_A(Integer workingSince_A) {
		this.workingSince_A = workingSince_A;
	}
	public Integer getWorkingSinceFI_A() {
		return workingSinceFI_A;
	}
	public void setWorkingSinceFI_A(Integer workingSinceFI_A) {
		this.workingSinceFI_A = workingSinceFI_A;
	}
	public Integer getBureauScoreA() {
		return bureauScoreA;
	}
	public void setBureauScoreA(Integer bureauScoreA) {
		this.bureauScoreA = bureauScoreA;
	}
	public String getBureauTypeA() {
		return bureauTypeA;
	}
	public void setBureauTypeA(String bureauTypeA) {
		this.bureauTypeA = bureauTypeA;
	}
	public String getCropsPerYear_A() {
		return cropsPerYear_A;
	}
	public void setCropsPerYear_A(String cropsPerYear_A) {
		this.cropsPerYear_A = cropsPerYear_A;
	}
	public String getLandHoldingOwn_A() {
		return landHoldingOwn_A;
	}
	public void setLandHoldingOwn_A(String landHoldingOwn_A) {
		this.landHoldingOwn_A = landHoldingOwn_A;
	}
	public String getLandHoldingLea_A() {
		return landHoldingLea_A;
	}
	public void setLandHoldingLea_A(String landHoldingLea_A) {
		this.landHoldingLea_A = landHoldingLea_A;
	}
	public Integer getNoOfBouncing_A() {
		return noOfBouncing_A;
	}
	public void setNoOfBouncing_A(Integer noOfBouncing_A) {
		this.noOfBouncing_A = noOfBouncing_A;
	}
	public String getMaxClosureDateGT3_A() {
		return maxClosureDateGT3_A;
	}
	public void setMaxClosureDateGT3_A(String maxClosureDateGT3_A) {
		this.maxClosureDateGT3_A = maxClosureDateGT3_A;
	}
	public String getMaxClosureDateLT3_A() {
		return maxClosureDateLT3_A;
	}
	public void setMaxClosureDateLT3_A(String maxClosureDateLT3_A) {
		this.maxClosureDateLT3_A = maxClosureDateLT3_A;
	}
	public String getPresentAddAsPermAddr_A() {
		return presentAddAsPermAddr_A;
	}
	public void setPresentAddAsPermAddr_A(String presentAddAsPermAddr_A) {
		this.presentAddAsPermAddr_A = presentAddAsPermAddr_A;
	}
	public Integer getTVR_Status() {
		return TVR_Status;
	}
	public void setTVR_Status(Integer tVR_Status) {
		TVR_Status = tVR_Status;
	}
	public String getTvrStatus_A() {
		return tvrStatus_A;
	}
	public void setTvrStatus_A(String tvrStatus_A) {
		this.tvrStatus_A = tvrStatus_A;
	}
	public String getTvrBusinessStatus() {
		return tvrBusinessStatus;
	}
	public void setTvrBusinessStatus(String tvrBusinessStatus) {
		this.tvrBusinessStatus = tvrBusinessStatus;
	}
	public String getTvrPermAddStatus() {
		return tvrPermAddStatus;
	}
	public void setTvrPermAddStatus(String tvrPermAddStatus) {
		this.tvrPermAddStatus = tvrPermAddStatus;
	}
	public String getTvrRefStatus_1() {
		return tvrRefStatus_1;
	}
	public void setTvrRefStatus_1(String tvrRefStatus_1) {
		this.tvrRefStatus_1 = tvrRefStatus_1;
	}
	public String getTvrRefStatus_2() {
		return tvrRefStatus_2;
	}
	public void setTvrRefStatus_2(String tvrRefStatus_2) {
		this.tvrRefStatus_2 = tvrRefStatus_2;
	}
	public String getNaNegativeArea_A() {
		return naNegativeArea_A;
	}
	public void setNaNegativeArea_A(String naNegativeArea_A) {
		this.naNegativeArea_A = naNegativeArea_A;
	}
	public String getHrpProfile_A() {
		return hrpProfile_A;
	}
	public void setHrpProfile_A(String hrpProfile_A) {
		this.hrpProfile_A = hrpProfile_A;
	}
	public String getProneArea_A() {
		return proneArea_A;
	}
	public void setProneArea_A(String proneArea_A) {
		this.proneArea_A = proneArea_A;
	}
	public Integer getFraudMatchFlag_A() {
		return fraudMatchFlag_A;
	}
	public void setFraudMatchFlag_A(Integer fraudMatchFlag_A) {
		this.fraudMatchFlag_A = fraudMatchFlag_A;
	}
	public Double getOverdueCCAccQualMaxAmt_A() {
		return overdueCCAccQualMaxAmt_A;
	}
	public void setOverdueCCAccQualMaxAmt_A(Double overdueCCAccQualMaxAmt_A) {
		this.overdueCCAccQualMaxAmt_A = overdueCCAccQualMaxAmt_A;
	}
	
	public Double getOverdueNonCCAccQualMaxAmt_A() {
		return overdueNonCCAccQualMaxAmt_A;
	}
	public void setOverdueNonCCAccQualMaxAmt_A(Double overdueNonCCAccQualMaxAmt_A) {
		this.overdueNonCCAccQualMaxAmt_A = overdueNonCCAccQualMaxAmt_A;
	}
	public Double getWrittenOffCCAccQualMaxDPD_A() {
		return writtenOffCCAccQualMaxDPD_A;
	}
	public void setWrittenOffCCAccQualMaxDPD_A(Double writtenOffCCAccQualMaxDPD_A) {
		this.writtenOffCCAccQualMaxDPD_A = writtenOffCCAccQualMaxDPD_A;
	}
	public Double getWrittenOffCCAccQualMaxAmt_A() {
		return writtenOffCCAccQualMaxAmt_A;
	}
	public void setWrittenOffCCAccQualMaxAmt_A(Double writtenOffCCAccQualMaxAmt_A) {
		this.writtenOffCCAccQualMaxAmt_A = writtenOffCCAccQualMaxAmt_A;
	}
	public Double getWrittenOffNonCCAccQualMaxAmt_A() {
		return writtenOffNonCCAccQualMaxAmt_A;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_A(Double writtenOffNonCCAccQualMaxAmt_A) {
		this.writtenOffNonCCAccQualMaxAmt_A = writtenOffNonCCAccQualMaxAmt_A;
	}
	public String getWoODSettledStatus_A() {
		return woODSettledStatus_A;
	}
	public void setWoODSettledStatus_A(String woODSettledStatus_A) {
		this.woODSettledStatus_A = woODSettledStatus_A;
	}
	public Double getOverdueNonCCAccQualMaxDPD_A() {
		return overdueNonCCAccQualMaxDPD_A;
	}
	public void setOverdueNonCCAccQualMaxDPD_A(Double overdueNonCCAccQualMaxDPD_A) {
		this.overdueNonCCAccQualMaxDPD_A = overdueNonCCAccQualMaxDPD_A;
	}
	public Integer getAge_A() {
		return age_A;
	}
	public void setAge_A(Integer age_A) {
		this.age_A = age_A;
	}
	public String getFiOff_A() {
		return fiOff_A;
	}
	public void setFiOff_A(String fiOff_A) {
		this.fiOff_A = fiOff_A;
	}
	public String getFiPerm_A() {
		return fiPerm_A;
	}
	public void setFiPerm_A(String fiPerm_A) {
		this.fiPerm_A = fiPerm_A;
	}
	public String getFiPres_A() {
		return fiPres_A;
	}
	public void setFiPres_A(String fiPres_A) {
		this.fiPres_A = fiPres_A;
	}
	public String getFiOffice_A() {
		return fiOffice_A;
	}
	public void setFiOffice_A(String fiOffice_A) {
		this.fiOffice_A = fiOffice_A;
	}
	public String getPincodeMatchedRes_A() {
		return pincodeMatchedRes_A;
	}
	public void setPincodeMatchedRes_A(String pincodeMatchedRes_A) {
		this.pincodeMatchedRes_A = pincodeMatchedRes_A;
	}
	public String getPincodeMatchedOff_A() {
		return pincodeMatchedOff_A;
	}
	public void setPincodeMatchedOff_A(String pincodeMatchedOff_A) {
		this.pincodeMatchedOff_A = pincodeMatchedOff_A;
	}
	public String getPincodeMatchedPer_A() {
		return pincodeMatchedPer_A;
	}
	public void setPincodeMatchedPer_A(String pincodeMatchedPer_A) {
		this.pincodeMatchedPer_A = pincodeMatchedPer_A;
	}
	public String getBSBand_A() {
		return BSBand_A;
	}
	public void setBSBand_A(String bSBand_A) {
		BSBand_A = bSBand_A;
	}
	public String getFi_Type_A() {
		return fi_Type_A;
	}
	public void setFi_Type_A(String fi_Type_A) {
		this.fi_Type_A = fi_Type_A;
	}
	public String getFi_Status_A() {
		return fi_Status_A;
	}
	public void setFi_Status_A(String fi_Status_A) {
		this.fi_Status_A = fi_Status_A;
	}
	public String getProfile_A() {
		return profile_A;
	}
	public void setProfile_A(String profile_A) {
		this.profile_A = profile_A;
	}
	
	public String getPresentAddrAsOffAddr_A() {
		return presentAddrAsOffAddr_A;
	}
	public void setPresentAddrAsOffAddr_A(String presentAddrAsOffAddr_A) {
		this.presentAddrAsOffAddr_A = presentAddrAsOffAddr_A;
	}
	
	public Integer getMonthlyIncome_A() {
		return monthlyIncome_A;
	}
	public void setMonthlyIncome_A(Integer monthlyIncome_A) {
		this.monthlyIncome_A = monthlyIncome_A;
	}
	@Override
	public String toString() {
		return "CbreRequest_ADTO [id=" + id + ", leadId=" + leadId + ", uid_A=" + uid_A + ", gender_A=" + gender_A
				+ ", breRequestId=" + breRequestId + ", landlineNo_A=" + landlineNo_A + ", bussLandlineNo="
				+ bussLandlineNo + ", presentState_A=" + presentState_A + ", constitution_A=" + constitution_A
				+ ", dedupeStatusAF_A=" + dedupeStatusAF_A + ", dedupeStatusCF_A=" + dedupeStatusCF_A
				+ ", dedupeStatus_A=" + dedupeStatus_A + ", dedupeTenure_A=" + dedupeTenure_A + ", dedupeCountAF_A="
				+ dedupeCountAF_A + ", dobIncorp_A=" + dobIncorp_A + ", fiNegReaResi_A=" + fiNegReaResi_A
				+ ", fiNegReaPerm_A=" + fiNegReaPerm_A + ", fiNegReaOffice_A=" + fiNegReaOffice_A + ", incomeProof_A="
				+ incomeProof_A + ", mobileConnection_A=" + mobileConnection_A + ", presentCity_A=" + presentCity_A
				+ ", primaryEmployment_A=" + primaryEmployment_A + ", primaryEmpType_A=" + primaryEmpType_A
				+ ", propertyStatus_A=" + propertyStatus_A + ", residenceStatus_A=" + residenceStatus_A
				+ ", residingSince_A=" + residingSince_A + ", residingSinceFI_A=" + residingSinceFI_A
				+ ", totalIncome_A=" + totalIncome_A + ", TPC_A=" + TPC_A + ", workingSince_A=" + workingSince_A
				+ ", workingSinceFI_A=" + workingSinceFI_A + ", bureauScoreA=" + bureauScoreA + ", bureauTypeA="
				+ bureauTypeA + ", cropsPerYear_A=" + cropsPerYear_A + ", landHoldingOwn_A=" + landHoldingOwn_A
				+ ", landHoldingLea_A=" + landHoldingLea_A + ", noOfBouncing_A=" + noOfBouncing_A
				+ ", maxClosureDateGT3_A=" + maxClosureDateGT3_A + ", maxClosureDateLT3_A=" + maxClosureDateLT3_A
				+ ", presentAddAsPermAddr_A=" + presentAddAsPermAddr_A + ", presentAddrAsOffAddr_A="
				+ presentAddrAsOffAddr_A + ", TVR_Status=" + TVR_Status + ", tvrStatus_A=" + tvrStatus_A
				+ ", tvrBusinessStatus=" + tvrBusinessStatus + ", tvrPermAddStatus=" + tvrPermAddStatus
				+ ", tvrRefStatus_1=" + tvrRefStatus_1 + ", tvrRefStatus_2=" + tvrRefStatus_2 + ", naNegativeArea_A="
				+ naNegativeArea_A + ", hrpProfile_A=" + hrpProfile_A + ", proneArea_A=" + proneArea_A
				+ ", fraudMatchFlag_A=" + fraudMatchFlag_A + ", overdueCCAccQualMaxAmt_A=" + overdueCCAccQualMaxAmt_A
				+ ", overdueNonCCAccQualMaxAmt_A=" + overdueNonCCAccQualMaxAmt_A + ", writtenOffCCAccQualMaxDPD_A="
				+ writtenOffCCAccQualMaxDPD_A + ", writtenOffCCAccQualMaxAmt_A=" + writtenOffCCAccQualMaxAmt_A
				+ ", writtenOffNonCCAccQualMaxAmt_A=" + writtenOffNonCCAccQualMaxAmt_A + ", woODSettledStatus_A="
				+ woODSettledStatus_A + ", overdueNonCCAccQualMaxDPD_A=" + overdueNonCCAccQualMaxDPD_A + ", age_A="
				+ age_A + ", fiOff_A=" + fiOff_A + ", fiPerm_A=" + fiPerm_A + ", fiPres_A=" + fiPres_A + ", fiOffice_A="
				+ fiOffice_A + ", pincodeMatchedRes_A=" + pincodeMatchedRes_A + ", pincodeMatchedOff_A="
				+ pincodeMatchedOff_A + ", pincodeMatchedPer_A=" + pincodeMatchedPer_A + ", BSBand_A=" + BSBand_A
				+ ", fi_Type_A=" + fi_Type_A + ", fi_Status_A=" + fi_Status_A + ", profile_A=" + profile_A + "]";
	}
	
	
	
}
