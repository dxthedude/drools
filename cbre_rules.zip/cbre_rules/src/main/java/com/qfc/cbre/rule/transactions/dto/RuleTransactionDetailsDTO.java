package com.qfc.cbre.rule.transactions.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.qfc.cbre.common.dto.BaseDTO;

@Entity
@Table(name = "rule_transaction_details")
public class RuleTransactionDetailsDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "lead_id")
	private Long leadid;
	
	@Column(name = "bre_req_id")
	private Long breRequestId;
	
	@Column(name = "app_uid")
	private String appUid;
	
	@Column(name = "coapp_uid")
	private String coappUid;
	
	@Column(name = "guar_uid")
	private String guarUid;
	
	@Column(name = "app_present")
	private Boolean appPresent = Boolean.FALSE;;
	
	@Column(name = "coapp_present")
	private Boolean coappPresent = Boolean.FALSE;
	
	@Column(name = "guar_present")
	private Boolean guarPresent = Boolean.FALSE;;
	
	@Column(name = "executed")
	private String executed;
	
	@Column(name = "notexecuted")
	private String notExecuted;
	
	@JsonIgnore
	@Column(name = "input_string")
	private String inputString;
	
	@JsonIgnore
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<CreditBreResponseDTO> response =  new ArrayList<CreditBreResponseDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<DoneTransactionsDTO> doneTransactions = new ArrayList<DoneTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<DtwoTransactionsDTO> dtwoTransactions = new ArrayList<DtwoTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<DthreeTransactionsDTO> dthreeTransactions = new ArrayList<DthreeTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<DfourTransactionsDTO> dfourTransactions = new ArrayList<DfourTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<DfiveTransactionsDTO> dfiveTransactions = new ArrayList<DfiveTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<LpoOneTransactionsDTO> lpoOneTransactions = new ArrayList<LpoOneTransactionsDTO>();

	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<LpoTwoTransactionsDTO> lpoTwoTransactions = new ArrayList<LpoTwoTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<LpoThreeTransactionsDTO> lpoThreeTransactions = new ArrayList<LpoThreeTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<CvRefinanceTransactionsDTO> cvRefinanceTransactions = new ArrayList<CvRefinanceTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<NewCvTransactionsDTO> newCvTransactions = new ArrayList<NewCvTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<PincodeMasterTransactionsDTO> pincodeTransactions = new ArrayList<PincodeMasterTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<RbpCvTransactionsDTO> rbpCvTransactions = new ArrayList<RbpCvTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<RbpTwowTransactionsDTO> rbpTwowTransactions = new ArrayList<RbpTwowTransactionsDTO>();
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<TwoWRefinanceTransactionsDTO> twowRefinanceTransactions = new ArrayList<TwoWRefinanceTransactionsDTO>();
	
	
	@OneToMany(mappedBy="ruleTransactionId",cascade = CascadeType.ALL)
	private List<VapTransactionsDTO> vapTransactions = new ArrayList<VapTransactionsDTO>();
	

	public List<DtwoTransactionsDTO> getDtwoTransactions() {
		return dtwoTransactions;
	}

	public void setDtwoTransactions(List<DtwoTransactionsDTO> dtwoTransactions) {
		this.dtwoTransactions = dtwoTransactions;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLeadid() {
		return leadid;
	}

	public void setLeadid(Long leadid) {
		this.leadid = leadid;
	}

	public String getAppUid() {
		return appUid;
	}

	public void setAppUid(String appUid) {
		this.appUid = appUid;
	}

	public String getCoappUid() {
		return coappUid;
	}

	public void setCoappUid(String coappUid) {
		this.coappUid = coappUid;
	}

	public String getGuarUid() {
		return guarUid;
	}

	public void setGuarUid(String guarUid) {
		this.guarUid = guarUid;
	}

	public Boolean getAppPresent() {
		return appPresent;
	}

	public void setAppPresent(Boolean appPresent) {
		this.appPresent = appPresent;
	}

	public Boolean getCoappPresent() {
		return coappPresent;
	}

	public void setCoappPresent(Boolean coappPresent) {
		this.coappPresent = coappPresent;
	}

	public Boolean getGuarPresent() {
		return guarPresent;
	}

	public void setGuarPresent(Boolean guarPresent) {
		this.guarPresent = guarPresent;
	}

	public String getExecuted() {
		return executed;
	}

	public void setExecuted(String executed) {
		this.executed = executed;
	}

	public String getNotExecuted() {
		return notExecuted;
	}

	public void setNotExecuted(String notExecuted) {
		this.notExecuted = notExecuted;
	}

	public Long getBreRequestId() {
		return breRequestId;
	}

	public void setBreRequestId(Long breRequestId) {
		this.breRequestId = breRequestId;
	}

	public List<DoneTransactionsDTO> getDoneTransactions() {
		return doneTransactions;
	}

	public void setDoneTransactions(List<DoneTransactionsDTO> doneTransactions) {
		this.doneTransactions = doneTransactions;
	}

	public List<VapTransactionsDTO> getVapTransactions() {
		return vapTransactions;
	}

	public void setVapTransactions(List<VapTransactionsDTO> vapTransactions) {
		this.vapTransactions = vapTransactions;
	}

	public List<DthreeTransactionsDTO> getDthreeTransactions() {
		return dthreeTransactions;
	}

	public void setDthreeTransactions(List<DthreeTransactionsDTO> dthreeTransactions) {
		this.dthreeTransactions = dthreeTransactions;
	}

	public List<DfourTransactionsDTO> getDfourTransactions() {
		return dfourTransactions;
	}

	public void setDfourTransactions(List<DfourTransactionsDTO> dfourTransactions) {
		this.dfourTransactions = dfourTransactions;
	}

	public List<DfiveTransactionsDTO> getDfiveTransactions() {
		return dfiveTransactions;
	}

	public void setDfiveTransactions(List<DfiveTransactionsDTO> dfiveTransactions) {
		this.dfiveTransactions = dfiveTransactions;
	}

	public List<LpoOneTransactionsDTO> getLpoOneTransactions() {
		return lpoOneTransactions;
	}

	public void setLpoOneTransactions(List<LpoOneTransactionsDTO> lpoOneTransactions) {
		this.lpoOneTransactions = lpoOneTransactions;
	}

	public List<LpoTwoTransactionsDTO> getLpoTwoTransactions() {
		return lpoTwoTransactions;
	}

	public void setLpoTwoTransactions(List<LpoTwoTransactionsDTO> lpoTwoTransactions) {
		this.lpoTwoTransactions = lpoTwoTransactions;
	}

	public List<LpoThreeTransactionsDTO> getLpoThreeTransactions() {
		return lpoThreeTransactions;
	}

	public void setLpoThreeTransactions(List<LpoThreeTransactionsDTO> lpoThreeTransactions) {
		this.lpoThreeTransactions = lpoThreeTransactions;
	}

	public List<CvRefinanceTransactionsDTO> getCvRefinanceTransactions() {
		return cvRefinanceTransactions;
	}

	public void setCvRefinanceTransactions(List<CvRefinanceTransactionsDTO> cvRefinanceTransactions) {
		this.cvRefinanceTransactions = cvRefinanceTransactions;
	}

	public List<NewCvTransactionsDTO> getNewCvTransactions() {
		return newCvTransactions;
	}

	public void setNewCvTransactions(List<NewCvTransactionsDTO> newCvTransactions) {
		this.newCvTransactions = newCvTransactions;
	}

	public List<PincodeMasterTransactionsDTO> getPincodeTransactions() {
		return pincodeTransactions;
	}

	public void setPincodeTransactions(List<PincodeMasterTransactionsDTO> pincodeTransactions) {
		this.pincodeTransactions = pincodeTransactions;
	}

	public List<RbpCvTransactionsDTO> getRbpCvTransactions() {
		return rbpCvTransactions;
	}

	public void setRbpCvTransactions(List<RbpCvTransactionsDTO> rbpCvTransactions) {
		this.rbpCvTransactions = rbpCvTransactions;
	}

	public List<RbpTwowTransactionsDTO> getRbpTwowTransactions() {
		return rbpTwowTransactions;
	}

	public void setRbpTwowTransactions(List<RbpTwowTransactionsDTO> rbpTwowTransactions) {
		this.rbpTwowTransactions = rbpTwowTransactions;
	}

	public List<TwoWRefinanceTransactionsDTO> getTwowRefinanceTransactions() {
		return twowRefinanceTransactions;
	}

	public void setTwowRefinanceTransactions(List<TwoWRefinanceTransactionsDTO> twowRefinanceTransactions) {
		this.twowRefinanceTransactions = twowRefinanceTransactions;
	}

	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public List<CreditBreResponseDTO> getResponse() {
		return response;
	}

	public void setResponse(List<CreditBreResponseDTO> response) {
		this.response = response;
	}

	
	
}
