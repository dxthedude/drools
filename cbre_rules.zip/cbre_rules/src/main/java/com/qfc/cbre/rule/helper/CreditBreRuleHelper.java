package com.qfc.cbre.rule.helper;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.codehaus.jettison.json.JSONObject;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qfc.bre.rules.config.DroolsBeanFactory;
import com.qfc.cbre.common.util.CbreConstants;
import com.qfc.cbre.dao.CreditBreDao;
import com.qfc.cbre.rule.input.master.dto.MstInputMasterDTO;
import com.qfc.cbre.rule.transactions.dto.CreditBreResponseDTO;
import com.qfc.cbre.rule.transactions.dto.CvRefinanceTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.DfiveTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.DfourTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.DoneTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.DthreeTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.DtwoTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.LpoOneTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.LpoThreeTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.LpoTwoTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.NewCvTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.PincodeMasterTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.RbpCvTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.RbpTwowTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.RuleTransactionDetailsDTO;
import com.qfc.cbre.rule.transactions.dto.TwoWRefinanceTransactionsDTO;
import com.qfc.cbre.rule.transactions.dto.VapTransactionsDTO;
import com.qfc.cbre.rule.vo.CreditBreInputVo;
import com.qfc.cbre.rule.vo.CvRefinanceTransactions;
import com.qfc.cbre.rule.vo.DfiveTransactions;
import com.qfc.cbre.rule.vo.DfourTransactions;
import com.qfc.cbre.rule.vo.DoneTransactions;
import com.qfc.cbre.rule.vo.DthreeTransactions;
import com.qfc.cbre.rule.vo.DtwoTransactions;
import com.qfc.cbre.rule.vo.LpoOneTransactions;
import com.qfc.cbre.rule.vo.LpoThreeTransactions;
import com.qfc.cbre.rule.vo.LpoTwoTransactions;
import com.qfc.cbre.rule.vo.NewCvTransactions;
import com.qfc.cbre.rule.vo.PincodeMasterTransactions;
import com.qfc.cbre.rule.vo.RbpCvTransactions;
import com.qfc.cbre.rule.vo.RbpTwowTransactions;
import com.qfc.cbre.rule.vo.TwowRefinanceTransactions;
import com.qfc.cbre.rule.vo.VapTransactions;
import com.qfc.cbre.service.MiddlewareService;
import com.qfc.cbre.rule.vo.CreditBreRequest;
import com.qfc.cbre.rule.vo.CreditBreResponse;


@Component(value="creditBreRuleHelper")
public class CreditBreRuleHelper {

	RuleTransactionDetailsDTO details = new RuleTransactionDetailsDTO();
	@Autowired
	MiddlewareService service ;
	
	@Autowired
	CreditBreDao cbredao ;
	/*private static CreditBreDao cbredao1 ;
	*/
	@PostConstruct
	public void init() {
		//CreditBreRuleHelper.cbredao1 = cbredao;	
		MST_RULE_MASTER = cbredao.gelAllRuleMaster(1);
	}
	
	private static KieSession kSession;
	private static KieSession kSessionnormal;
	private static KieSession kSessiondss;
	private static KieSession kSessionktm;
	private static KieSession kSessionninja;
	private static KieSession kSessioncorporate;
	private static KieSession kSessionlpoone;
	private static KieSession kSessionlpotwo;
	private static KieSession kSessionlpothree;
	private static KieSession kSessioncvrefinance;
	private static KieSession kSession2wrefinance;
	private static KieSession kSessionnewcv;
	private static KieSession kSessionrbp2w;
	private static KieSession kSessionrbpcv;
	private static KieSession kSessionvap;
	private static KieSession kSessionpincodemaster;

	public static Map<String, MstInputMasterDTO> MST_RULE_MASTER = new HashMap<>();

	
	private Integer seq=0;
	static {
		Resource resource = ResourceFactory.newClassPathResource("/dtables/credit-bre-master.xls", CreditBreRuleHelper.class);
		kSession = new DroolsBeanFactory().getKieSession(resource);
		System.out.println(kSession);
		
		Resource resourcenormal = ResourceFactory.newClassPathResource("/dtables/done-normal.xls", CreditBreRuleHelper.class);
		kSessionnormal = new DroolsBeanFactory().getKieSession(resourcenormal);
		System.out.println(kSessionnormal);
		
		Resource resourcedss = ResourceFactory.newClassPathResource("/dtables/dtwo-dss.xls", CreditBreRuleHelper.class);
		kSessiondss = new DroolsBeanFactory().getKieSession(resourcedss);
		System.out.println(kSessiondss);
		
		
		Resource resourcektm = ResourceFactory.newClassPathResource("/dtables/dthree-ktm.xls", CreditBreRuleHelper.class);
		kSessionktm = new DroolsBeanFactory().getKieSession(resourcektm);
		System.out.println(kSessionktm);
		
		Resource resourceninja = ResourceFactory.newClassPathResource("/dtables/dfour-ninja.xls", CreditBreRuleHelper.class);
		kSessionninja = new DroolsBeanFactory().getKieSession(resourceninja);
		System.out.println(kSessionninja);
		
		Resource resourcecorporate = ResourceFactory.newClassPathResource("/dtables/dfive-corporate.xls", CreditBreRuleHelper.class);
		kSessioncorporate = new DroolsBeanFactory().getKieSession(resourcecorporate);
		System.out.println(kSessioncorporate);
		
		Resource resourcelpoone = ResourceFactory.newClassPathResource("/dtables/lpo-one.xls", CreditBreRuleHelper.class);
		kSessionlpoone = new DroolsBeanFactory().getKieSession(resourcelpoone);
		System.out.println(kSessionlpoone);
		
		Resource resourcelpotwo = ResourceFactory.newClassPathResource("/dtables/lpo-two.xls", CreditBreRuleHelper.class);
		kSessionlpotwo = new DroolsBeanFactory().getKieSession(resourcelpotwo);
		System.out.println(kSessionlpotwo);
		
		Resource resourcelpothree = ResourceFactory.newClassPathResource("/dtables/lpo-three.xls", CreditBreRuleHelper.class);
		kSessionlpothree = new DroolsBeanFactory().getKieSession(resourcelpothree);
		System.out.println(kSessionlpothree);
		
		Resource resourcecvrefinance = ResourceFactory.newClassPathResource("/dtables/cv-refinance.xls", CreditBreRuleHelper.class);
		kSessioncvrefinance = new DroolsBeanFactory().getKieSession(resourcecvrefinance);
		System.out.println(kSessioncvrefinance);
		
		Resource resource2wrefinance = ResourceFactory.newClassPathResource("/dtables/2w-refinance.xls", CreditBreRuleHelper.class);
		kSession2wrefinance = new DroolsBeanFactory().getKieSession(resource2wrefinance);
		System.out.println(kSession2wrefinance);
		
		Resource resourcerbp2w = ResourceFactory.newClassPathResource("/dtables/rbp-2w.xls", CreditBreRuleHelper.class);
		kSessionrbp2w = new DroolsBeanFactory().getKieSession(resourcerbp2w);
		System.out.println(kSessionrbp2w);
		
		Resource resourcerbpcv = ResourceFactory.newClassPathResource("/dtables/rbp-cv.xls", CreditBreRuleHelper.class);
		kSessionrbpcv = new DroolsBeanFactory().getKieSession(resourcerbpcv);
		System.out.println(kSessionrbpcv);
		
		Resource resourcenewcv = ResourceFactory.newClassPathResource("/dtables/new-cv.xls", CreditBreRuleHelper.class);
		kSessionnewcv = new DroolsBeanFactory().getKieSession(resourcenewcv);
		System.out.println(kSessionnewcv);
			
		Resource resourcevap = ResourceFactory.newClassPathResource("/dtables/vap.xls", CreditBreRuleHelper.class);
		kSessionvap = new DroolsBeanFactory().getKieSession(resourcevap);
		System.out.println(kSessionvap);
		
		Resource resourcepincodemaster = ResourceFactory.newClassPathResource("/dtables/pincode-master.xls", CreditBreRuleHelper.class);
		kSessionpincodemaster = new DroolsBeanFactory().getKieSession(resourcepincodemaster);
		System.out.println(kSessionpincodemaster);
		
		
	}
	

	public RuleTransactionDetailsDTO executeBreRequests(CreditBreRequest req) {
		
		CreditBreInputVo breInputVo = new CreditBreInputVo();
		breInputVo.setBreRequest(req);
		fireMasterRule(breInputVo);
		breInputVo = setAminusBDate(breInputVo,req);
		RuleTransactionDetailsDTO  ruledetails = RuleResult(breInputVo);
		
		if(ruledetails!=null) {
			if(ruledetails.getResponse()!=null) {
				if(ruledetails.getResponse().size()>0) {
					CreditBreResponse res = CbreConstants.MAPPER.map(ruledetails.getResponse().get(0), CreditBreResponse.class);
					
					res.setResponseMsg("Success");
					res.setResponseCode("00S");
					System.out.println("Highest Deviation === "+res+"\n\n");
				}else {
					List<CreditBreResponseDTO> resdto = new ArrayList<>();
					CreditBreResponseDTO res = new CreditBreResponseDTO();
					res.setRuleTransactionId(ruledetails);
					resdto.add(res);
					res.setLeadId(breInputVo.getBreRequest().getLeadId());
					res.setExecutionFor("All");
					res.setResponseMsg("SYSTEM APPROVED");
					res.setResponseCode("00");
					res.setDeviationMsg("NO DEVIATION");
					ruledetails.setResponse(resdto);
					System.out.println("System Deviation === "+res+"\n\n");
				}
			}
		}
		
		
		return ruledetails;
		
	}
	


	/*public static void main(String[] args) throws Exception {		
		CreditBreInputVo breInputVo = new CreditBreInputVo();
		breInputVo = setInputValues(breInputVo);
		fireMasterRule(breInputVo);
		RuleResult(breInputVo);
	}*/


	private CreditBreInputVo setAminusBDate(CreditBreInputVo breInputVo, CreditBreRequest req) {
		 Date loginDate = req.getLoginDate();
		 Date disbursementDateOldLAN = req.getDisbursementDateOldLAN();
		 
		// Date d = new Date();
		 
		 System.out.println("Login Date : "+loginDate);
		 System.out.println("Disbursed Date : "+disbursementDateOldLAN);
		 
		 if(loginDate!=null && disbursementDateOldLAN!=null) {
		 
		
		 LocalDate logindate = new java.sql.Date(loginDate.getTime()).toLocalDate();
		 LocalDate disbddate = new java.sql.Date(disbursementDateOldLAN.getTime()).toLocalDate();
		 System.out.println("Login Date : "+logindate);
		 System.out.println("Disbursed Date : "+disbddate);
		 Period age = Period.between(disbddate,logindate);
		 System.out.println("Age : "+age);
		 System.out.println("Months : "+age.getMonths()+"  ||  Years : "+age.getYears());
		 int diffMonth = 0 ;
		 if(age!=null  && age.getYears()>0) {
			 diffMonth = age.getMonths() + (age.getYears() * 12);
		 }else {
			 diffMonth = age.getMonths();
		 }
		  System.out.println("Diff in months :: "+diffMonth);
		 breInputVo.setAminusBMonths(diffMonth);
		 return breInputVo;
		 }else {
		return breInputVo;
		 }
	}



	private  RuleTransactionDetailsDTO RuleResult(CreditBreInputVo breInputVo) {
		 details = new RuleTransactionDetailsDTO();
		
		 List<String> allRules= breInputVo.getAllRules();
		 List<String> executedRules = breInputVo.getExecutedRules();
		 List<String> notExecutedRules = breInputVo.getNotExecutedRules();


		notExecutedRules.addAll( allRules.stream().filter(object -> 
			!executedRules.contains(object)).collect(Collectors.toList()));
		
		System.out.println("\n Not Executed Rules :: \n"+notExecutedRules);
		System.out.println("\n Executed Rules :: \n"+executedRules);
		System.out.println("\n All Rules :: \n"+allRules);
	
		
		if(breInputVo.getBreRequest().getId()!=null) {
		details.setBreRequestId(breInputVo.getBreRequest().getId());
		details.setExecuted(executedRules.toString());
		details.setNotExecuted(notExecutedRules.toString());
		details.setLeadid(breInputVo.getBreRequest().getLeadId());
		if(breInputVo!=null && breInputVo.getBreRequest()!=null && breInputVo.getBreRequest().getUid_A()!=null) {
		details.setAppUid(breInputVo.getBreRequest().getUid_A());
		details.setAppPresent(Boolean.TRUE);
		breInputVo.getRuleTransactionDetails().setAppPresent(Boolean.TRUE);
		}
		if(breInputVo!=null && breInputVo.getBreRequest()!=null && breInputVo.getBreRequest().getUid_C()!=null && "TRUE".equalsIgnoreCase(breInputVo.getBreRequest().getPresent_C())) {
			details.setCoappUid(breInputVo.getBreRequest().getUid_C());
			details.setCoappPresent(Boolean.TRUE);
			breInputVo.getRuleTransactionDetails().setCoappPresent(Boolean.TRUE);
		}
		if(breInputVo!=null && breInputVo.getBreRequest()!=null && breInputVo.getBreRequest().getUid_G()!=null && "TRUE".equalsIgnoreCase(breInputVo.getBreRequest().getPresent_G())) {
			details.setGuarUid(breInputVo.getBreRequest().getUid_G());
			details.setGuarPresent(Boolean.TRUE);
			breInputVo.getRuleTransactionDetails().setGuarPresent(Boolean.TRUE);
		}
		}
		 details.setInputString("SchemeType / Segment / Constitution_A / AssetType / RepaymentMode / OfferType \n---------------\n "+breInputVo.getInputString()+"\n");
		
		 System.out.println("\n Master Rule Set Inputs :: \n"+details.getInputString());
		 
		 List<CreditBreResponse> responselist = new ArrayList<>();
		 fireExecutedRules(executedRules.toString(),breInputVo,responselist);
		 System.out.println("DISPLAY ********************************************************************* ");
		 for(CreditBreResponse resp : responselist) {
				System.out.println("Before sort Levels ::: "+resp.getLevel());
			}
		responselist.sort(Comparator.comparing(CreditBreResponse::getLevel)
                .reversed());
		for(CreditBreResponse resp : responselist) {
			System.out.println("After Sort Levels ::: "+resp.getLevel());
		}
		CreditBreResponse sortedresponse =  responselist.stream().findFirst().orElse(null);
		if(sortedresponse != null) {
		CreditBreResponseDTO dto = CbreConstants.MAPPER.map(sortedresponse, CreditBreResponseDTO.class);
		dto.setRuleTransactionId(details);
		details.getResponse().add(dto);
		}
		return details;
		
	}


	


	private void fireExecutedRules(String executedRules,CreditBreInputVo breInputVo,List<CreditBreResponse> responselist) {
		
		CreditBreResponse response = null;
		
		if(executedRules.contains(CbreConstants.MasterRules.D1NORMAL)) {
			System.out.println("TRUE NORMAL");
			System.out.println("Firing Rule for D1-NORMAL");
			kSessionnormal.insert(breInputVo);
			kSessionnormal.fireAllRules();
			
			List<DoneTransactions> dn = breInputVo.getRuleTransactionDetails().getDoneTransactions();
			
			dn.sort(Comparator.comparing(DoneTransactions::getLevel)
                    .reversed());
			DoneTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
		    response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.D1NORMAL);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<DoneTransactionsDTO> dtolist = new ArrayList<DoneTransactionsDTO>();
			for(DoneTransactions vo : dn) {
				DoneTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DoneTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setDoneTransactions(dtolist);
			
		}
		if(executedRules.contains(CbreConstants.MasterRules.D2DSS)) {
			System.out.println("TRUE D2-DSS");
			System.out.println("Firing Rule for D2-DSS");
			kSessiondss.insert(breInputVo);
			kSessiondss.fireAllRules();
			List<DtwoTransactions> dn = breInputVo.getRuleTransactionDetails().getDtwoTransactions();
			
			dn.sort(Comparator.comparing(DtwoTransactions::getLevel)
                    .reversed());
			DtwoTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
		    response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.D2DSS);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<DtwoTransactionsDTO> dtolist = new ArrayList<DtwoTransactionsDTO>();
			
			for(DtwoTransactions vo : dn) {
				DtwoTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DtwoTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setDtwoTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.D3KTM)) {
			System.out.println("TRUE D3-KTM");
			System.out.println("Firing Rule for D3-KTM");
			kSessionktm.insert(breInputVo);
			kSessionktm.fireAllRules();
			/*List<DthreeTransactions> dn = breInputVo.getRuleTransactionDetails().getDthreeTransactions();
			List<DthreeTransactionsDTO> dtolist = new ArrayList<DthreeTransactionsDTO>();
			
			for(DthreeTransactions vo : dn) {
				DthreeTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DthreeTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setDthreeTransactions(dtolist);*/
			
List<DthreeTransactions> dn = breInputVo.getRuleTransactionDetails().getDthreeTransactions();
			
			dn.sort(Comparator.comparing(DthreeTransactions::getLevel)
                    .reversed());
			DthreeTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.D3KTM);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<DthreeTransactionsDTO> dtolist = new ArrayList<DthreeTransactionsDTO>();
			
			for(DthreeTransactions vo : dn) {
				DthreeTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DthreeTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setDthreeTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.D4NINJA)) {
			System.out.println("TRUE D4-NINJA");
			System.out.println("Firing Rule for D4-NINJA");
			kSessionninja.insert(breInputVo);
			kSessionninja.fireAllRules();
			/*List<DfourTransactions> dn = breInputVo.getRuleTransactionDetails().getDfourTransactions();
			List<DfourTransactionsDTO> dtolist = new ArrayList<DfourTransactionsDTO>();
			
			for(DfourTransactions vo : dn) {
				DfourTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DfourTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setDfourTransactions(dtolist);*/
			
			List<DfourTransactions> dn = breInputVo.getRuleTransactionDetails().getDfourTransactions();
			
			dn.sort(Comparator.comparing(DfourTransactions::getLevel)
                    .reversed());
			DfourTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.D4NINJA);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<DfourTransactionsDTO> dtolist = new ArrayList<DfourTransactionsDTO>();
			
			for(DfourTransactions vo : dn) {
				DfourTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DfourTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setDfourTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.D5CORPORATE)) {
			System.out.println("TRUE D5-CORPORATE");
			System.out.println("Firing Rule for D5-CORPORATE");
			kSessioncorporate.insert(breInputVo);
			kSessioncorporate.fireAllRules();
			/*List<DfiveTransactions> dn = breInputVo.getRuleTransactionDetails().getDfiveTransactions();
			List<DfiveTransactionsDTO> dtolist = new ArrayList<DfiveTransactionsDTO>();
			
			for(DfiveTransactions vo : dn) {
				DfiveTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DfiveTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setDfiveTransactions(dtolist);*/
			
List<DfiveTransactions> dn = breInputVo.getRuleTransactionDetails().getDfiveTransactions();
			
			dn.sort(Comparator.comparing(DfiveTransactions::getLevel)
                    .reversed());
			DfiveTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.D5CORPORATE);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<DfiveTransactionsDTO> dtolist = new ArrayList<DfiveTransactionsDTO>();
			
			for(DfiveTransactions vo : dn) {
				DfiveTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, DfiveTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setDfiveTransactions(dtolist);
		}
	
		if(executedRules.contains(CbreConstants.MasterRules.LPO1)) {
			System.out.println("TRUE LPO1");
			System.out.println("Firing Rule for LPO1");
			kSessionlpoone.insert(breInputVo);
			kSessionlpoone.fireAllRules();
			/*List<LpoOneTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoOneTransactions();
			List<LpoOneTransactionsDTO> dtolist = new ArrayList<LpoOneTransactionsDTO>();
			
			for(LpoOneTransactions vo : dn) {
				LpoOneTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoOneTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setLpoOneTransactions(dtolist);*/
			
			List<LpoOneTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoOneTransactions();
			
			dn.sort(Comparator.comparing(LpoOneTransactions::getLevel)
                    .reversed());
			LpoOneTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.LPO1);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<LpoOneTransactionsDTO> dtolist = new ArrayList<LpoOneTransactionsDTO>();
			
			for(LpoOneTransactions vo : dn) {
				LpoOneTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoOneTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setLpoOneTransactions(dtolist);
		} 
		if(executedRules.contains(CbreConstants.MasterRules.LPO2)) {
			System.out.println("TRUE LPO2");
			System.out.println("Firing Rule for LPO2");
			kSessionlpotwo.insert(breInputVo);
			kSessionlpotwo.fireAllRules();
			/*List<LpoTwoTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoTwoTransactions();
			List<LpoTwoTransactionsDTO> dtolist = new ArrayList<LpoTwoTransactionsDTO>();
			
			for(LpoTwoTransactions vo : dn) {
				LpoTwoTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoTwoTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setLpoTwoTransactions(dtolist);*/
			
List<LpoTwoTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoTwoTransactions();
			
			dn.sort(Comparator.comparing(LpoTwoTransactions::getLevel)
                    .reversed());
			LpoTwoTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.LPO2);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<LpoTwoTransactionsDTO> dtolist = new ArrayList<LpoTwoTransactionsDTO>();
			
			for(LpoTwoTransactions vo : dn) {
				LpoTwoTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoTwoTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setLpoTwoTransactions(dtolist);
			
			
		}
		if(executedRules.contains(CbreConstants.MasterRules.LPO3)) {
			System.out.println("TRUE LPO3");
			System.out.println("Firing Rule for LPO3");
			kSessionlpothree.insert(breInputVo);
			kSessionlpothree.fireAllRules();
			/*List<LpoThreeTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoThreeTransactions();
			List<LpoThreeTransactionsDTO> dtolist = new ArrayList<LpoThreeTransactionsDTO>();
			
			for(LpoThreeTransactions vo : dn) {
				LpoThreeTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoThreeTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setLpoThreeTransactions(dtolist);*/
			
			List<LpoThreeTransactions> dn = breInputVo.getRuleTransactionDetails().getLpoThreeTransactions();
			
			dn.sort(Comparator.comparing(LpoThreeTransactions::getLevel)
                    .reversed());
			LpoThreeTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.LPO3);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<LpoThreeTransactionsDTO> dtolist = new ArrayList<LpoThreeTransactionsDTO>();
			for(LpoThreeTransactions vo : dn) {
				LpoThreeTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, LpoThreeTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setLpoThreeTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.NEWCV)) {
			System.out.println("TRUE NEW-CV");
			System.out.println("Firing Rule for NEW-CV");
			kSessionnewcv.insert(breInputVo);
			kSessionnewcv.fireAllRules();
			/*List<NewCvTransactions> dn = breInputVo.getRuleTransactionDetails().getNewCvTransactions();
			List<NewCvTransactionsDTO> dtolist = new ArrayList<NewCvTransactionsDTO>();
			
			for(NewCvTransactions vo : dn) {
				NewCvTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, NewCvTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setNewCvTransactions(dtolist);*/
			
List<NewCvTransactions> dn = breInputVo.getRuleTransactionDetails().getNewCvTransactions();
			
			dn.sort(Comparator.comparing(NewCvTransactions::getLevel)
                    .reversed());
			NewCvTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.NEWCV);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<NewCvTransactionsDTO> dtolist = new ArrayList<NewCvTransactionsDTO>();
			
			for(NewCvTransactions vo : dn) {
				NewCvTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, NewCvTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setNewCvTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.CVREFINANCE)) {
			System.out.println("TRUE CV-REFINANCE");
			System.out.println("Firing Rule for CV-REFINANCE");
			kSessioncvrefinance.insert(breInputVo);
			kSessioncvrefinance.fireAllRules();
			/*List<CvRefinanceTransactions> dn = breInputVo.getRuleTransactionDetails().getCvRefinanceTransactions();
			List<CvRefinanceTransactionsDTO> dtolist = new ArrayList<CvRefinanceTransactionsDTO>();
			
			for(CvRefinanceTransactions vo : dn) {
				CvRefinanceTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, CvRefinanceTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setCvRefinanceTransactions(dtolist);*/
			
List<CvRefinanceTransactions> dn = breInputVo.getRuleTransactionDetails().getCvRefinanceTransactions();
			
			dn.sort(Comparator.comparing(CvRefinanceTransactions::getLevel)
                    .reversed());
			CvRefinanceTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.CVREFINANCE);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<CvRefinanceTransactionsDTO> dtolist = new ArrayList<CvRefinanceTransactionsDTO>();
			
			for(CvRefinanceTransactions vo : dn) {
				CvRefinanceTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, CvRefinanceTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setCvRefinanceTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.TWOWREFINANCE)) {
			System.out.println("TRUE 2W-REFINANCE");
			System.out.println("Firing Rule for 2W-REFINANCE");
			kSession2wrefinance.insert(breInputVo);
			kSession2wrefinance.fireAllRules();
		/*	List<TwowRefinanceTransactions> dn = breInputVo.getRuleTransactionDetails().getTwowRefinanceTransactions();
			List<TwoWRefinanceTransactionsDTO> dtolist = new ArrayList<TwoWRefinanceTransactionsDTO>();
			
			for(TwowRefinanceTransactions vo : dn) {
				TwoWRefinanceTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, TwoWRefinanceTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setTwowRefinanceTransactions(dtolist);*/
			
			
List<TwowRefinanceTransactions> dn = breInputVo.getRuleTransactionDetails().getTwowRefinanceTransactions();
			
			dn.sort(Comparator.comparing(TwowRefinanceTransactions::getLevel)
                    .reversed());
			TwowRefinanceTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.TWOWREFINANCE);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<TwoWRefinanceTransactionsDTO> dtolist = new ArrayList<TwoWRefinanceTransactionsDTO>();
			
			for(TwowRefinanceTransactions vo : dn) {
				TwoWRefinanceTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, TwoWRefinanceTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setTwowRefinanceTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.RBP2W)) {
			System.out.println("TRUE RBP-2W");
			System.out.println("Firing Rule for RBP-2W");
			kSessionrbp2w.insert(breInputVo);
			kSessionrbp2w.fireAllRules();
			/*List<RbpTwowTransactions> dn = breInputVo.getRuleTransactionDetails().getRbpTwowTransactions();
			List<RbpTwowTransactionsDTO> dtolist = new ArrayList<RbpTwowTransactionsDTO>();
			
			for(RbpTwowTransactions vo : dn) {
				RbpTwowTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, RbpTwowTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setRbpTwowTransactions(dtolist);*/
			
List<RbpTwowTransactions> dn = breInputVo.getRuleTransactionDetails().getRbpTwowTransactions();
			
			dn.sort(Comparator.comparing(RbpTwowTransactions::getLevel)
                    .reversed());
			RbpTwowTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.RBP2W);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<RbpTwowTransactionsDTO> dtolist = new ArrayList<RbpTwowTransactionsDTO>();
			
			for(RbpTwowTransactions vo : dn) {
				RbpTwowTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, RbpTwowTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setRbpTwowTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.RBPCV)) {
			System.out.println("TRUE RBP-CV");
			System.out.println("Firing Rule for RBP-CV");
			kSessionrbpcv.insert(breInputVo);
			kSessionrbpcv.fireAllRules();
			/*List<RbpCvTransactions> dn = breInputVo.getRuleTransactionDetails().getRbpCvTransactions();
			List<RbpCvTransactionsDTO> dtolist = new ArrayList<RbpCvTransactionsDTO>();
			
			for(RbpCvTransactions vo : dn) {
				RbpCvTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, RbpCvTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setRbpCvTransactions(dtolist);*/
			
			List<RbpCvTransactions> dn = breInputVo.getRuleTransactionDetails().getRbpCvTransactions();
			
			dn.sort(Comparator.comparing(RbpCvTransactions::getLevel)
                    .reversed());
			RbpCvTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.RBPCV);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<RbpCvTransactionsDTO> dtolist = new ArrayList<RbpCvTransactionsDTO>();
			
			for(RbpCvTransactions vo : dn) {
				RbpCvTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, RbpCvTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setRbpCvTransactions(dtolist);
		}
		if(executedRules.contains(CbreConstants.MasterRules.VAP)) {
			System.out.println("TRUE VAP");
			System.out.println("Firing Rule for VAP");
			kSessionvap.insert(breInputVo);
			kSessionvap.fireAllRules();
			/*List<VapTransactions> dn = breInputVo.getRuleTransactionDetails().getVapTransactions();
			List<VapTransactionsDTO> dtolist = new ArrayList<VapTransactionsDTO>();
			
			for(VapTransactions vo : dn) {
				VapTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, VapTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				dtolist.add(dndto);
			}
			details.setVapTransactions(dtolist);*/
			
			
List<VapTransactions> dn = breInputVo.getRuleTransactionDetails().getVapTransactions();
			
			dn.sort(Comparator.comparing(VapTransactions::getLevel)
                    .reversed());
			VapTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.VAP);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<VapTransactionsDTO> dtolist = new ArrayList<VapTransactionsDTO>();
			for(VapTransactions vo : dn) {
				VapTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, VapTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setVapTransactions(dtolist);
		}
		
		
		
		if(executedRules.contains(CbreConstants.MasterRules.PINCODEMASTER)) {
			System.out.println("TRUE PINCODE-MASTER/HRP-MASTER");
			System.out.println("Firing Rule for PINCODE-MASTER/HRP-MASTER");
			kSessionpincodemaster.insert(breInputVo);
			kSessionpincodemaster.fireAllRules();

			
			
			List<PincodeMasterTransactions> dn = breInputVo.getRuleTransactionDetails().getPincodeTransactions();
			
			dn.sort(Comparator.comparing(PincodeMasterTransactions::getLevel)
                    .reversed());
			PincodeMasterTransactions dnsorted =  dn.stream().findFirst().orElse(null);
			if(dnsorted != null) {
			response = new CreditBreResponse();
			response.setDeviationGroup(dnsorted.getMainDeviationGroup());
			response.setSubDeviationGroup(dnsorted.getSubDeviationGroup());
			response.setDeviationMsg(dnsorted.getDeviationMsg());
			response.setExecSeq(seq+1);
			response.setMainRule(CbreConstants.MasterRules.PINCODEMASTER);
			response.setSubRule(dnsorted.getRuleName());
			response.setExecutionFor(dnsorted.getRunFor());
			response.setExecutedOn(dnsorted.getCreatedDatetime());
			response.setLevel(dnsorted.getLevel());
			response.setLeadId(dnsorted.getLeadid());
			responselist.add(response);
			}
			
			List<PincodeMasterTransactionsDTO> dtolist = new ArrayList<PincodeMasterTransactionsDTO>();
			for(PincodeMasterTransactions vo : dn) {
				PincodeMasterTransactionsDTO dndto = CbreConstants.MAPPER.map(vo, PincodeMasterTransactionsDTO.class);
				dndto.setRuleTransactionId(details);
				String inputs = setInputFields(dndto.getRuleName(),breInputVo,details);
				dndto.setInputString(inputs);
				dtolist.add(dndto);
			}
			details.setPincodeTransactions(dtolist);
		}
		
	}



	private String setInputFields(String ruleName,CreditBreInputVo breInputVo,RuleTransactionDetailsDTO details) {
		//System.out.println(ruleName);
		MstInputMasterDTO  inputMasterDTO= new MstInputMasterDTO();
		String inputs = "";	
		
		if(MST_RULE_MASTER.get(ruleName)!=null) {
			inputMasterDTO = MST_RULE_MASTER.get(ruleName);

		if(inputMasterDTO!=null) {
	
			if ( inputMasterDTO.getMarginMoney()!=null && inputMasterDTO.getMarginMoney()!=Boolean.FALSE ){
				inputs = inputs+"|| Margin Money : "+breInputVo.getBreRequest().getMarginMoney();
				
			};
			if ( inputMasterDTO.getCustomerType()!=null && inputMasterDTO.getCustomerType()!=Boolean.FALSE ){
				inputs = inputs+"|| Customer Type : "+breInputVo.getBreRequest().getCustomerType();
				
			};
			if ( inputMasterDTO.getCustCatFinal()!=null && inputMasterDTO.getCustCatFinal()!=Boolean.FALSE ){
				inputs = inputs+"|| Customer Category Final : "+breInputVo.getBreRequest().getCustCatFinal();
				
			};
			if ( inputMasterDTO.getRepaymentMode()!=null && inputMasterDTO.getRepaymentMode()!=Boolean.FALSE ){
				inputs = inputs+"|| Repayment Mode : "+breInputVo.getBreRequest().getRepaymentMode();
				
			};
			if ( inputMasterDTO.getRepaymentFrom()!=null && inputMasterDTO.getRepaymentFrom()!=Boolean.FALSE ){
				inputs = inputs+"|| Repayment From : "+breInputVo.getBreRequest().getRepaymentFrom();
				
			};
			if ( inputMasterDTO.getSubscriberId()!=null && inputMasterDTO.getSubscriberId()!=Boolean.FALSE ){
				inputs = inputs+"|| Subscriber Id : "+breInputVo.getBreRequest().getSubscriberId();
				
			};
			if ( inputMasterDTO.getLayoutId()!=null && inputMasterDTO.getLayoutId()!=Boolean.FALSE ){
				inputs = inputs+"|| Layout Id : "+breInputVo.getBreRequest().getLayoutId();
				
			};
			if ( inputMasterDTO.getABB()!=null && inputMasterDTO.getABB()!=Boolean.FALSE ){
				inputs = inputs+"|| ABB : "+breInputVo.getBreRequest().getABB();
				
			};
			if ( inputMasterDTO.getAccountVintage()!=null && inputMasterDTO.getAccountVintage()!=Boolean.FALSE ){
				inputs = inputs+"|| Account Vintage : "+breInputVo.getBreRequest().getAccountVintage();
				
			};
			if ( inputMasterDTO.getTypeOfRefinance()!=null && inputMasterDTO.getTypeOfRefinance()!=Boolean.FALSE ){
				inputs = inputs+"|| Type Of Refinance : "+breInputVo.getBreRequest().getTypeOfRefinance();
				
			};
			if ( inputMasterDTO.getRegistrationNo()!=null && inputMasterDTO.getRegistrationNo()!=Boolean.FALSE ){
				inputs = inputs+"|| Registration No : "+breInputVo.getBreRequest().getRegistrationNo();
				
			};
			/*if ( inputMasterDTO.getLoginBoolean()!=null && inputMasterDTO.getLoginBoolean()!=Boolean.FALSE ){
				inputs = inputs+"|| Login Boolean : "+breInputVo.getBreRequest().getLoginBoolean();
				
			};*/
			/*if ( inputMasterDTO.getDisbursementBooleanOldLAN()!=null && inputMasterDTO.getDisbursementBooleanOldLAN()!=Boolean.FALSE ){
				inputs = inputs+"|| Disbursement Boolean OldLAN : "+breInputVo.getBreRequest().getDisbursementBooleanOldLAN();
				
			};*/
			if ( inputMasterDTO.getBlueBookPrice()!=null && inputMasterDTO.getBlueBookPrice()!=Boolean.FALSE ){
				inputs = inputs+"|| Blue Book Price : "+breInputVo.getBreRequest().getBlueBookPrice();
				
			};
			if ( inputMasterDTO.getSchemeType()!=null && inputMasterDTO.getSchemeType()!=Boolean.FALSE ){
				inputs = inputs+"|| Scheme Type : "+breInputVo.getBreRequest().getSchemeType();
				
			};
			if ( inputMasterDTO.getSegment()!=null && inputMasterDTO.getSegment()!=Boolean.FALSE ){
				inputs = inputs+"|| Segment : "+breInputVo.getBreRequest().getSegment();
				
			};
			if ( inputMasterDTO.getSubCode()!=null && inputMasterDTO.getSubCode()!=Boolean.FALSE ){
				inputs = inputs+"|| Sub Code : "+breInputVo.getBreRequest().getSubCode();
				
			};
			if ( inputMasterDTO.getAssetType()!=null && inputMasterDTO.getAssetType()!=Boolean.FALSE ){
				inputs = inputs+"|| Asset Type : "+breInputVo.getBreRequest().getAssetType();
				
			};
			if ( inputMasterDTO.getOfferType()!=null && inputMasterDTO.getOfferType()!=Boolean.FALSE ){
				inputs = inputs+"|| Offer Type : "+breInputVo.getBreRequest().getOfferType();
				
			};
			if ( inputMasterDTO.getSchemeGrp()!=null && inputMasterDTO.getSchemeGrp()!=Boolean.FALSE ){
				inputs = inputs+"|| Scheme Grp : "+breInputVo.getBreRequest().getSchemeGrp();
				
			};
			if ( inputMasterDTO.getSchemeCode()!=null && inputMasterDTO.getSchemeCode()!=Boolean.FALSE ){
				inputs = inputs+"|| Scheme Code : "+breInputVo.getBreRequest().getSchemeCode();
				
			};
			if ( inputMasterDTO.getBranch()!=null && inputMasterDTO.getBranch()!=Boolean.FALSE ){
				inputs = inputs+"|| Branch : "+breInputVo.getBreRequest().getBranch();
				
			};
			if ( inputMasterDTO.getSupplierCategory()!=null && inputMasterDTO.getSupplierCategory()!=Boolean.FALSE ){
				inputs = inputs+"|| Supplier Category : "+breInputVo.getBreRequest().getSupplierCategory();
				
			};
			if ( inputMasterDTO.getSupplierState()!=null && inputMasterDTO.getSupplierState()!=Boolean.FALSE ){
				inputs = inputs+"|| Supplier State : "+breInputVo.getBreRequest().getSupplierState();
				
			};
			if ( inputMasterDTO.getTotalExposure()!=null && inputMasterDTO.getTotalExposure()!=Boolean.FALSE ){
				inputs = inputs+"|| Total Exposure : "+breInputVo.getBreRequest().getTotalExposure();
				
			};
			if ( inputMasterDTO.getDedupeStatusAF_G()!=null && inputMasterDTO.getDedupeStatusAF_G()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatusAF for G : "+breInputVo.getBreRequest().getCbreRequest_G().getDedupeStatusAF_G();
				
			};
			if ( inputMasterDTO.getDedupeStatusCF_G()!=null && inputMasterDTO.getDedupeStatusCF_G()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatusCF for G : "+breInputVo.getBreRequest().getCbreRequest_G().getDedupeStatusCF_G();
				
			};
			if ( inputMasterDTO.getDedupeStatus_G()!=null && inputMasterDTO.getDedupeStatus_G()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus for G() : "+breInputVo.getBreRequest().getCbreRequest_G().getDedupeStatus_G();
				
			};
			if ( inputMasterDTO.getDedupeTenure_G()!=null && inputMasterDTO.getDedupeTenure_G()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeTenure for G : "+breInputVo.getBreRequest().getCbreRequest_G().getDedupeTenure_G();
				
			};
			if ( inputMasterDTO.getDobIncorp_G()!=null && inputMasterDTO.getDobIncorp_G()!=Boolean.FALSE ){
				inputs = inputs+"|| DobIncorp for G : "+breInputVo.getBreRequest().getCbreRequest_G().getDobIncorp_G();
				
			};
			if ( inputMasterDTO.getFiNegReaResi_G()!=null && inputMasterDTO.getFiNegReaResi_G()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaResi for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFiNegReaResi_G();
				
			};
			if ( inputMasterDTO.getFiNegReaPerm_G()!=null && inputMasterDTO.getFiNegReaPerm_G()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaPerm for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFiNegReaPerm_G();
				
			};
			if ( inputMasterDTO.getFiNegReaOffice_G()!=null && inputMasterDTO.getFiNegReaOffice_G()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaOffice for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFiNegReaOffice_G();
				
			};
			if ( inputMasterDTO.getPrimaryEmpType_G()!=null && inputMasterDTO.getPrimaryEmpType_G()!=Boolean.FALSE ){
				inputs = inputs+"|| PrimaryEmpType for G : "+breInputVo.getBreRequest().getCbreRequest_G().getPrimaryEmpType_G();
				
			};
			if ( inputMasterDTO.getPropertyStatus_G()!=null && inputMasterDTO.getPropertyStatus_G()!=Boolean.FALSE ){
				inputs = inputs+"|| PropertyStatus for G : "+breInputVo.getBreRequest().getCbreRequest_G().getPropertyStatus_G();
				
			};
			if ( inputMasterDTO.getResidenceStatus_G()!=null && inputMasterDTO.getResidenceStatus_G()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidenceStatus for G : "+breInputVo.getBreRequest().getCbreRequest_G().getResidenceStatus_G();
				
			};
			if ( inputMasterDTO.getResidingSince_G()!=null && inputMasterDTO.getResidingSince_G()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidingSince for G : "+breInputVo.getBreRequest().getCbreRequest_G().getResidingSince_G();
				
			};
			if ( inputMasterDTO.getResidingSinceFI_G()!=null && inputMasterDTO.getResidingSinceFI_G()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidingSinceFI for G : "+breInputVo.getBreRequest().getCbreRequest_G().getResidingSinceFI_G();
				
			};
			if ( inputMasterDTO.getTpc_G()!=null && inputMasterDTO.getTpc_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Tpc for G : "+breInputVo.getBreRequest().getCbreRequest_G().getTPC_G();
				
			};
			if ( inputMasterDTO.getWorkingSince_G()!=null && inputMasterDTO.getWorkingSince_G()!=Boolean.FALSE ){
				inputs = inputs+"|| WorkingSince for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWorkingSince_G();
				
			};
			if ( inputMasterDTO.getWorkingSinceFI_G()!=null && inputMasterDTO.getWorkingSinceFI_G()!=Boolean.FALSE ){
				inputs = inputs+"|| WorkingSinceFI for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWorkingSinceFI_G();
				
			};
			if ( inputMasterDTO.getBureauScore_G()!=null && inputMasterDTO.getBureauScore_G()!=Boolean.FALSE ){
				inputs = inputs+"|| BureauScore for G : "+breInputVo.getBreRequest().getCbreRequest_G().getBureauScore_G();
				
			};
			if ( inputMasterDTO.getBureauType_G()!=null && inputMasterDTO.getBureauType_G()!=Boolean.FALSE ){
				inputs = inputs+"|| BureauType for G : "+breInputVo.getBreRequest().getCbreRequest_G().getBureauType_G();
				
			};
			if ( inputMasterDTO.getNoOfBouncing_G()!=null && inputMasterDTO.getNoOfBouncing_G()!=Boolean.FALSE ){
				inputs = inputs+"|| NoOf Bouncing for G : "+breInputVo.getBreRequest().getCbreRequest_G().getNoOfBouncing_G();
				
			};
			if ( inputMasterDTO.getMaxClosureDateGT3_G()!=null && inputMasterDTO.getMaxClosureDateGT3_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Max Closure BooleanGT3 for G : "+breInputVo.getBreRequest().getCbreRequest_G().getMaxClosureDateGT3_G();
				
			};
			if ( inputMasterDTO.getMaxClosureDateLT3_G()!=null && inputMasterDTO.getMaxClosureDateGT3_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Max Closure BooleanLT3 for G : "+breInputVo.getBreRequest().getCbreRequest_G().getMaxClosureDateLT3_G();
				
			};
			if ( inputMasterDTO.getTvrStatus_G()!=null && inputMasterDTO.getTvrStatus_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Tvr Status for G : "+breInputVo.getBreRequest().getCbreRequest_G().getTVR_Status_G();
				
			};
			if ( inputMasterDTO.getNaNegativeArea_G()!=null && inputMasterDTO.getNaNegativeArea_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Na NegativeArea for G : "+breInputVo.getBreRequest().getCbreRequest_G().getNA_NegativeArea_G();
				
			};
			if ( inputMasterDTO.getHRPProfile_G()!=null && inputMasterDTO.getHRPProfile_G()!=Boolean.FALSE ){
				inputs = inputs+"|| HRP Profile for G : "+breInputVo.getBreRequest().getCbreRequest_G().getHRPProfile_G();
				
			};
			if ( inputMasterDTO.getProneArea_G()!=null && inputMasterDTO.getProneArea_G()!=Boolean.FALSE ){
				inputs = inputs+"|| ProneArea for G : "+breInputVo.getBreRequest().getCbreRequest_G().getProneAreaG();
				
			};
			if ( inputMasterDTO.getNa_G()!=null && inputMasterDTO.getNa_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Na for G : "+breInputVo.getBreRequest().getCbreRequest_G().getNA_G();
				
			};
			if ( inputMasterDTO.getNp_G()!=null && inputMasterDTO.getNp_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Np for G : "+breInputVo.getBreRequest().getCbreRequest_G().getNP_G();
				
			};
			if ( inputMasterDTO.getPa_G()!=null && inputMasterDTO.getPa_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Pa for G : "+breInputVo.getBreRequest().getCbreRequest_G().getPA_G();
				
			};
			if ( inputMasterDTO.getFraudMatchFlag_G()!=null && inputMasterDTO.getFraudMatchFlag_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Fraud MatchFlag for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFraudMatchFlag_G();
				
			};
			if ( inputMasterDTO.getFm_G()!=null && inputMasterDTO.getFm_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Fm for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFM_G();
				
			};
			if ( inputMasterDTO.getOverdueCCAccQualMaxAmt_G()!=null && inputMasterDTO.getOverdueCCAccQualMaxAmt_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue CC AccQualMaxAmt for G : "+breInputVo.getBreRequest().getCbreRequest_G().getOverdueCCAccQualMaxAmt_G();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxAmt_G()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxAmt_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue NonCC AccQualMaxAmt for G : "+breInputVo.getBreRequest().getCbreRequest_G().getOverdueNonCCAccQualMaxAmt_G();
				
			};
			if ( inputMasterDTO.getWrittenOffNonCCAccQualMaxDPD_G()!=null && inputMasterDTO.getWrittenOffNonCCAccQualMaxDPD_G()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff NonCC AccQualMaxDPD for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWrittenOffNonCCAccQualMaxDPD_G();
				
			};
			if ( inputMasterDTO.getWrittenOffCCAccQualMaxAmt_G()!=null && inputMasterDTO.getWrittenOffCCAccQualMaxAmt_G()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff CC AccQualMaxAmt for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWrittenOffCCAccQualMaxAmt_G();
				
			};
			if ( inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_G()!=null && inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_G()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff NonCC AccQualMaxAmt for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWrittenOffNonCCAccQualMaxAmt_G();
				
			};
			if ( inputMasterDTO.getWoODSettledStatus_G()!=null && inputMasterDTO.getWoODSettledStatus_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Wo OD SettledStatus for G : "+breInputVo.getBreRequest().getCbreRequest_G().getWO_OD_Settled_Status_G();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxDPD_G()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxDPD_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue NonCC AccQualMaxDPD for G : "+breInputVo.getBreRequest().getCbreRequest_G().getOverdueNonCCAccQualMaxDPD_G();
				
			};
			if ( inputMasterDTO.getAge_G()!=null && inputMasterDTO.getAge_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Age for G : "+breInputVo.getBreRequest().getCbreRequest_G().getAge_G();
				
			};
			if ( inputMasterDTO.getFiPres_G()!=null && inputMasterDTO.getFiPres_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Fi Pres for G : "+breInputVo.getBreRequest().getCbreRequest_G().getFIPres_G();
				
			};
			if ( inputMasterDTO.getPincodeMatchedRes_G()!=null && inputMasterDTO.getPincodeMatchedRes_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Pincode Matched Res for G : "+breInputVo.getBreRequest().getCbreRequest_G().getPinCodeMatchedRes_G();
				
			};
			if ( inputMasterDTO.getPincodeMatchedOff_G()!=null && inputMasterDTO.getPincodeMatchedOff_G()!=Boolean.FALSE ){
				inputs = inputs+"|| Pincode Matched Off for G : "+breInputVo.getBreRequest().getCbreRequest_G().getPinCodeMatchedOff_G();
				
			};
			if ( inputMasterDTO.getBSBand_G()!=null && inputMasterDTO.getBSBand_G()!=Boolean.FALSE ){
				inputs = inputs+"|| BSBand for G : "+breInputVo.getBreRequest().getCbreRequest_G().getBSBand_G();
				
			};
			if ( inputMasterDTO.getLandlineNo_C()!=null && inputMasterDTO.getLandlineNo_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Landline No for C : "+breInputVo.getBreRequest().getCbreRequest_C().getLandlineNo_C();
				
			};
			if ( inputMasterDTO.getBusinessLandlineNo_C()!=null && inputMasterDTO.getBusinessLandlineNo_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Business Landline No for C : "+breInputVo.getBreRequest().getCbreRequest_C().getBusinessLandlineNo_C();
				
			};
			if ( inputMasterDTO.getConstitutionC()!=null && inputMasterDTO.getConstitutionC()!=Boolean.FALSE ){
				inputs = inputs+"|| Constitution for C : "+breInputVo.getBreRequest().getCbreRequest_C().getConstitutionC();
				
			};
			if ( inputMasterDTO.getDedupeStatusAF_C()!=null && inputMasterDTO.getDedupeStatusAF_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus AF C : "+breInputVo.getBreRequest().getCbreRequest_C().getDedupeStatusAF_C();
				
			};
			if ( inputMasterDTO.getDedupeStatusCF_C()!=null && inputMasterDTO.getDedupeStatusCF_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus CF C : "+breInputVo.getBreRequest().getCbreRequest_C().getDedupeStatusCF_C();
				
			};
			if ( inputMasterDTO.getDedupeStatus_C()!=null && inputMasterDTO.getDedupeStatus_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus C : "+breInputVo.getBreRequest().getCbreRequest_C().getDedupeStatus_C();
				
			};
			if ( inputMasterDTO.getDedupeTenure_C()!=null && inputMasterDTO.getDedupeTenure_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeTenure for C : "+breInputVo.getBreRequest().getCbreRequest_C().getDedupeTenure_C();
				
			};
			if ( inputMasterDTO.getDedupeCountAF_C()!=null && inputMasterDTO.getDedupeCountAF_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeCount AF for C : "+breInputVo.getBreRequest().getCbreRequest_C().getDedupeAFCount_C();
				
			};
			if ( inputMasterDTO.getDobIncorp_C()!=null && inputMasterDTO.getDobIncorp_C()!=Boolean.FALSE ){
				inputs = inputs+"|| DobIncorp C : "+breInputVo.getBreRequest().getCbreRequest_C().getDobIncorp_C();
				
			};
			if ( inputMasterDTO.getFiNegReaResi_C()!=null && inputMasterDTO.getFiNegReaResi_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaResi C : "+breInputVo.getBreRequest().getCbreRequest_C().getFiNegReaResi_C();
				
			};
			if ( inputMasterDTO.getFiNegReaPerm_C()!=null && inputMasterDTO.getFiNegReaPerm_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaPerm C : "+breInputVo.getBreRequest().getCbreRequest_C().getFiNegReaPerm_C();
				
			};
			if ( inputMasterDTO.getFiNegReaOffice_C()!=null && inputMasterDTO.getFiNegReaOffice_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaOffice C : "+breInputVo.getBreRequest().getCbreRequest_C().getFiNegReaOffice_C();
				
			};
			if ( inputMasterDTO.getIncomeProof_C()!=null && inputMasterDTO.getIncomeProof_C()!=Boolean.FALSE ){
				inputs = inputs+"|| IncomeProof C : "+breInputVo.getBreRequest().getCbreRequest_C().getIncomeProof_C();
				
			};
			if ( inputMasterDTO.getMobileConnection_C()!=null && inputMasterDTO.getMobileConnection_C()!=Boolean.FALSE ){
				inputs = inputs+"|| MobileConnection C : "+breInputVo.getBreRequest().getCbreRequest_C().getMobileConnection_C();
				
			};
			if ( inputMasterDTO.getPresentCity_C()!=null && inputMasterDTO.getPresentCity_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PresentCity C : "+breInputVo.getBreRequest().getCbreRequest_C().getPresentCity_C();
				
			};
			if ( inputMasterDTO.getPrimaryEmpType_C()!=null && inputMasterDTO.getPrimaryEmpType_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PrimaryEmpType C : "+breInputVo.getBreRequest().getCbreRequest_C().getPrimaryEmpType_C();
				
			};
			if ( inputMasterDTO.getPropertyStatus_C()!=null && inputMasterDTO.getPropertyStatus_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PropertyStatus C : "+breInputVo.getBreRequest().getCbreRequest_C().getPropertyStatus_C();
				
			};
			if ( inputMasterDTO.getResidenceStatus_C()!=null && inputMasterDTO.getResidenceStatus_C()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidenceStatus C : "+breInputVo.getBreRequest().getCbreRequest_C().getResidenceStatus_C();
				
			};
			if ( inputMasterDTO.getResidingSince_C()!=null && inputMasterDTO.getResidingSince_C()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidingSince C : "+breInputVo.getBreRequest().getCbreRequest_C().getResidingSince_C();
				
			};
			if ( inputMasterDTO.getResidingSinceFI_C()!=null && inputMasterDTO.getResidingSinceFI_C()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidingSince FI C : "+breInputVo.getBreRequest().getCbreRequest_C().getResidingSinceFI_C();
				
			};
			if ( inputMasterDTO.getTotalIncome_C()!=null && inputMasterDTO.getTotalIncome_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Total Income C : "+breInputVo.getBreRequest().getCbreRequest_C().getTotalIncome_C();
				
			};
			if ( inputMasterDTO.getTpc_C()!=null && inputMasterDTO.getTpc_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Tpc C : "+breInputVo.getBreRequest().getCbreRequest_C().getTPC_C();
				
			};
			if ( inputMasterDTO.getWorkingSince_C()!=null && inputMasterDTO.getWorkingSince_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Working Since C : "+breInputVo.getBreRequest().getCbreRequest_C().getWorkingSince_C();
				
			};
			if ( inputMasterDTO.getWorkingSinceFI_C()!=null && inputMasterDTO.getWorkingSinceFI_C()!=Boolean.FALSE ){
				inputs = inputs+"|| WorkingSinceFI C : "+breInputVo.getBreRequest().getCbreRequest_C().getWorkingSinceFI_C();
				
			};
			if ( inputMasterDTO.getBureauScore_C()!=null && inputMasterDTO.getBureauScore_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Bureau Score C : "+breInputVo.getBreRequest().getCbreRequest_C().getBureauScore_C();
				
			};
			if ( inputMasterDTO.getBureauType_C()!=null && inputMasterDTO.getBureauType_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Bureau Type C : "+breInputVo.getBreRequest().getCbreRequest_C().getBureauType_C();
				
			};
			if ( inputMasterDTO.getCropsPerYear_C()!=null && inputMasterDTO.getCropsPerYear_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Crops Per Year C : "+breInputVo.getBreRequest().getCbreRequest_C().getCropsPerYear_C();
				
			};
			if ( inputMasterDTO.getLandHoldingOwn_C()!=null && inputMasterDTO.getLandHoldingOwn_C()!=Boolean.FALSE ){
				inputs = inputs+"|| LandHoldingOwn C : "+breInputVo.getBreRequest().getCbreRequest_C().getLandHoldingOwn_C();
				
			};
			if ( inputMasterDTO.getLandHoldingLea_C()!=null && inputMasterDTO.getLandHoldingLea_C()!=Boolean.FALSE ){
				inputs = inputs+"|| LandHolding Lea C : "+breInputVo.getBreRequest().getCbreRequest_C().getLandHoldingLea_C();
				
			};
			if ( inputMasterDTO.getNoOfBouncing_C()!=null && inputMasterDTO.getNoOfBouncing_C()!=Boolean.FALSE ){
				inputs = inputs+"|| NoOfBouncing C : "+breInputVo.getBreRequest().getCbreRequest_C().getNoOfBouncing_C();
				
			};
			if ( inputMasterDTO.getMaxClosureDateGT3_C()!=null && inputMasterDTO.getMaxClosureDateGT3_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Max ClosureDate GT3 C : "+breInputVo.getBreRequest().getCbreRequest_C().getMaxClosureDateGT3_C();
				
			};
			if ( inputMasterDTO.getMaxClosureDateGT3_C()!=null && inputMasterDTO.getMaxClosureDateGT3_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Max Closure Date LT3 C : "+breInputVo.getBreRequest().getCbreRequest_C().getMaxClosureDateLT3_C();
				
			};
			if ( inputMasterDTO.getPresentAddrAsPermAddr_C()!=null && inputMasterDTO.getPresentAddrAsPermAddr_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Present Addr AsPermAddr C : "+breInputVo.getBreRequest().getCbreRequest_C().getPresentAddrAsPermAddr_C();
				
			};
			if ( inputMasterDTO.getFiResidence_C()!=null && inputMasterDTO.getFiResidence_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiResidence C : "+breInputVo.getBreRequest().getCbreRequest_C().getFI_Residence_C();
				
			};
			if ( inputMasterDTO.getPrimaryEmployment_C()!=null && inputMasterDTO.getPrimaryEmployment_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PrimaryEmployment C : "+breInputVo.getBreRequest().getCbreRequest_C().getPrimaryEmployment_C();
				
			};
			if ( inputMasterDTO.getTvrStatus_C()!=null && inputMasterDTO.getTvrStatus_C()!=Boolean.FALSE ){
				inputs = inputs+"|| TvrStatus C : "+breInputVo.getBreRequest().getCbreRequest_C().getTVR_Status_C();
				
			};
			if ( inputMasterDTO.getNaNegativeArea_C()!=null && inputMasterDTO.getNaNegativeArea_C()!=Boolean.FALSE ){
				inputs = inputs+"|| NegativeArea for C : "+breInputVo.getBreRequest().getCbreRequest_C().getNA_NegativeArea_C();
				
			};
			if ( inputMasterDTO.getHrpProfile_C()!=null && inputMasterDTO.getHrpProfile_C()!=Boolean.FALSE ){
				inputs = inputs+"|| HrpProfile C : "+breInputVo.getBreRequest().getCbreRequest_C().getHRPProfile_C();
				
			};
			if ( inputMasterDTO.getProneArea_C()!=null && inputMasterDTO.getProneArea_C()!=Boolean.FALSE ){
				inputs = inputs+"|| ProneArea C : "+breInputVo.getBreRequest().getCbreRequest_C().getProneArea_C();
				
			};
			if ( inputMasterDTO.getNaPresent_C()!=null && inputMasterDTO.getNaPresent_C()!=Boolean.FALSE ){
				inputs = inputs+"|| NaPresent C : "+breInputVo.getBreRequest().getCbreRequest_C().getNA_present_C();
				
			};
			if ( inputMasterDTO.getNpPresent_C()!=null && inputMasterDTO.getNpPresent_C()!=Boolean.FALSE ){
				inputs = inputs+"|| NpPresent C : "+breInputVo.getBreRequest().getCbreRequest_C().getNP_present_C();
				
			};
			if ( inputMasterDTO.getPa_present_c()!=null && inputMasterDTO.getPa_present_c()!=Boolean.FALSE ){
				inputs = inputs+"|| Pa_present C : "+breInputVo.getBreRequest().getCbreRequest_C().getPA_present_C();
				
			};
			if ( inputMasterDTO.getFraudMatchFlag_C()!=null && inputMasterDTO.getFraudMatchFlag_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FraudMatchFlag C : "+breInputVo.getBreRequest().getCbreRequest_C().getFraudMatchFlag_C();
				
			};
			if ( inputMasterDTO.getFm_C()!=null && inputMasterDTO.getFm_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Fm C : "+breInputVo.getBreRequest().getCbreRequest_C().getFM_C();
				
			};
			if ( inputMasterDTO.getOverdueCCAccQualMaxAmt_C()!=null && inputMasterDTO.getOverdueCCAccQualMaxAmt_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue CC AccQualMaxAmt C : "+breInputVo.getBreRequest().getCbreRequest_C().getOverdueCCAccQualMaxAmt_C();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxAmt_C()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxAmt_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue NonCC AccQualMaxAmt C : "+breInputVo.getBreRequest().getCbreRequest_C().getOverdueNonCCAccQualMaxAmt_C();
				
			};
			if ( inputMasterDTO.getWrittenOffNonCCAccQualMaxDPD_C()!=null && inputMasterDTO.getWrittenOffNonCCAccQualMaxDPD_C()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff NonCC AccQualMaxDPD C : "+breInputVo.getBreRequest().getCbreRequest_C().getWrittenOffNonCCAccQualMaxDPD_C();
				
			};
			if ( inputMasterDTO.getWrittenOffCCAccQualMaxAmt_C()!=null && inputMasterDTO.getWrittenOffCCAccQualMaxAmt_C()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff CC AccQualMaxAmt C : "+breInputVo.getBreRequest().getCbreRequest_C().getWrittenOffCCAccQualMaxAmt_C();
				
			};
			if ( inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_C()!=null && inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_C()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff NonCC AccQualMaxAmt C : "+breInputVo.getBreRequest().getCbreRequest_C().getWrittenOffNonCCAccQualMaxAmt_C();
				
			};
			if ( inputMasterDTO.getWrittenOffODSettledStatus_C()!=null && inputMasterDTO.getWrittenOffODSettledStatus_C()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff ODSettled Status C : "+breInputVo.getBreRequest().getCbreRequest_C().getWO_OD_Settled_Status_C();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxDPD_C()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxDPD_C()!=Boolean.FALSE ){
				inputs = inputs+"|| OverdueNonCCAccQualMaxDPD C : "+breInputVo.getBreRequest().getCbreRequest_C().getOverdueNonCCAccQualMaxDPD_C();
				
			};
			if ( inputMasterDTO.getAge_C()!=null && inputMasterDTO.getAge_C()!=Boolean.FALSE ){
				inputs = inputs+"|| Age C : "+breInputVo.getBreRequest().getCbreRequest_C().getAge_C();
				
			};
			if ( inputMasterDTO.getFiOff_C()!=null && inputMasterDTO.getFiOff_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiOff C : "+breInputVo.getBreRequest().getCbreRequest_C().getFIOff_C();
				
			};
			if ( inputMasterDTO.getFiPerm_C()!=null && inputMasterDTO.getFiPerm_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiPerm C : "+breInputVo.getBreRequest().getCbreRequest_C().getFIPerm_C();
				
			};
			if ( inputMasterDTO.getFiPres_C()!=null && inputMasterDTO.getFiPres_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiPres C : "+breInputVo.getBreRequest().getCbreRequest_C().getFIPres_C();
				
			};
			if ( inputMasterDTO.getFiOffice_C()!=null && inputMasterDTO.getFiOffice_C()!=Boolean.FALSE ){
				inputs = inputs+"|| FiOffice C : "+breInputVo.getBreRequest().getCbreRequest_C().getFI_Office_C();
				
			};
			if ( inputMasterDTO.getPincodeMatchedRes_C()!=null && inputMasterDTO.getPincodeMatchedRes_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PincodeMatchedRes C : "+breInputVo.getBreRequest().getCbreRequest_C().getPinCodeMatchedRes_C();
				
			};
			if ( inputMasterDTO.getPincodeMatchedOff_C()!=null && inputMasterDTO.getPincodeMatchedOff_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PincodeMatchedOff C : "+breInputVo.getBreRequest().getCbreRequest_C().getPinCodeMatchedOff_C();
				
			};
			if ( inputMasterDTO.getPinCodeMatchedPer_C()!=null && inputMasterDTO.getPinCodeMatchedPer_C()!=Boolean.FALSE ){
				inputs = inputs+"|| PinCodeMatchedPer C : "+breInputVo.getBreRequest().getCbreRequest_C().getPinCodeMatchedPer_C();
				
			};
			if ( inputMasterDTO.getBSBand_C()!=null && inputMasterDTO.getBSBand_C()!=Boolean.FALSE ){
				inputs = inputs+"|| BSBand for C : "+breInputVo.getBreRequest().getCbreRequest_C().getBSBand_C();
				
			};
			if ( inputMasterDTO.getGender_A()!=null && inputMasterDTO.getGender_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Gender for A : "+breInputVo.getBreRequest().getCbreRequest_A().getGender_A();
				
			};
			if ( inputMasterDTO.getLandlineNo_A()!=null && inputMasterDTO.getLandlineNo_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Landline No A : "+breInputVo.getBreRequest().getCbreRequest_A().getLandlineNo_A();
				
			};
			if ( inputMasterDTO.getBussLandlineNo()!=null && inputMasterDTO.getBussLandlineNo()!=Boolean.FALSE ){
				inputs = inputs+"|| BussLandlineNo A : "+breInputVo.getBreRequest().getCbreRequest_A().getBusinessLandlineNo();
				
			};
			if ( inputMasterDTO.getPresentState_A()!=null && inputMasterDTO.getPresentState_A()!=Boolean.FALSE ){
				inputs = inputs+"|| PresentState A : "+breInputVo.getBreRequest().getCbreRequest_A().getPresentState_A();
				
			};
			if ( inputMasterDTO.getConstitution_A()!=null && inputMasterDTO.getConstitution_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Constitution A : "+breInputVo.getBreRequest().getCbreRequest_A().getConstitution_A();
				
			};
			if ( inputMasterDTO.getDedupeStatusAF_A()!=null && inputMasterDTO.getDedupeStatusAF_A()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus AF A : "+breInputVo.getBreRequest().getCbreRequest_A().getDedupeStatusAF_A();
				
			};
			if ( inputMasterDTO.getDedupeStatusCF_A()!=null && inputMasterDTO.getDedupeStatusCF_A()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeStatus CF A : "+breInputVo.getBreRequest().getCbreRequest_A().getDedupeStatusCF_A();
				
			};
			if ( inputMasterDTO.getDedupeStatus_A()!=null && inputMasterDTO.getDedupeStatus_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Dedupe Status A : "+breInputVo.getBreRequest().getCbreRequest_A().getDedupeStatus_A();
				
			};
			if ( inputMasterDTO.getDedupeTenure_A()!=null && inputMasterDTO.getDedupeTenure_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Dedupe Tenure A : "+breInputVo.getBreRequest().getCbreRequest_A().getDedupeTenure_A();
				
			};
			if ( inputMasterDTO.getDedupeCountAF_A()!=null && inputMasterDTO.getDedupeCountAF_A()!=Boolean.FALSE ){
				inputs = inputs+"|| DedupeCount AF A : "+breInputVo.getBreRequest().getCbreRequest_A().getDedupeStatusAF_A();
				
			};
			if ( inputMasterDTO.getDobIncorp_A()!=null && inputMasterDTO.getDobIncorp_A()!=Boolean.FALSE ){
				inputs = inputs+"|| DobIncorp A : "+breInputVo.getBreRequest().getCbreRequest_A().getDobIncorp_A();
				
			};
			if ( inputMasterDTO.getFiNegReaResi_A()!=null && inputMasterDTO.getFiNegReaResi_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaResi A : "+breInputVo.getBreRequest().getCbreRequest_A().getFiNegReaResi_A();
				
			};
			if ( inputMasterDTO.getFiNegReaPerm_A()!=null && inputMasterDTO.getFiNegReaPerm_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaPerm A : "+breInputVo.getBreRequest().getCbreRequest_A().getFiNegReaPerm_A();
				
			};
			if ( inputMasterDTO.getFiNegReaOffice_A()!=null && inputMasterDTO.getFiNegReaOffice_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiNegReaOffice A : "+breInputVo.getBreRequest().getCbreRequest_A().getFiNegReaOffice_A();
				
			};
			if ( inputMasterDTO.getIncomeProof_A()!=null && inputMasterDTO.getIncomeProof_A()!=Boolean.FALSE ){
				inputs = inputs+"|| IncomeProof A : "+breInputVo.getBreRequest().getCbreRequest_A().getIncomeProof_A();
				
			};
			if ( inputMasterDTO.getMobileConnection_A()!=null && inputMasterDTO.getMobileConnection_A()!=Boolean.FALSE ){
				inputs = inputs+"|| MobileConnection A : "+breInputVo.getBreRequest().getCbreRequest_A().getMobileConnection_A();
				
			};
			if ( inputMasterDTO.getPresentCity_A()!=null && inputMasterDTO.getPresentCity_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Present City A : "+breInputVo.getBreRequest().getCbreRequest_A().getPresentCity_A();
				
			};
			if ( inputMasterDTO.getPrimaryEmployment_A()!=null && inputMasterDTO.getPrimaryEmployment_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Primary Employment A : "+breInputVo.getBreRequest().getCbreRequest_A().getPrimaryEmployment_A();
				
			};
			if ( inputMasterDTO.getPrimaryEmpType_A()!=null && inputMasterDTO.getPrimaryEmpType_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Primary EmpType A : "+breInputVo.getBreRequest().getCbreRequest_A().getPrimaryEmpType_A();
				
			};
			if ( inputMasterDTO.getPropertyStatus_A()!=null && inputMasterDTO.getPropertyStatus_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Property Status A : "+breInputVo.getBreRequest().getCbreRequest_A().getPropertyStatus_A();
				
			};
			if ( inputMasterDTO.getResidenceStatus_A()!=null && inputMasterDTO.getResidenceStatus_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Residence Status A : "+breInputVo.getBreRequest().getCbreRequest_A().getResidenceStatus_A();
				
			};
			if ( inputMasterDTO.getResidingSince_A()!=null && inputMasterDTO.getResidingSince_A()!=Boolean.FALSE ){
				inputs = inputs+"|| ResidingSince A : "+breInputVo.getBreRequest().getCbreRequest_A().getResidingSince_A();
				
			};
			if ( inputMasterDTO.getResidingSinceFI_A()!=null && inputMasterDTO.getResidingSinceFI_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Residing SinceFI  A : "+breInputVo.getBreRequest().getCbreRequest_A().getResidingSinceFI_A();
				
			};
			if ( inputMasterDTO.getTotalIncome_A()!=null && inputMasterDTO.getTotalIncome_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Total Income A : "+breInputVo.getBreRequest().getCbreRequest_A().getTotalIncome_A();
				
			};
			if ( inputMasterDTO.getTPC_A()!=null && inputMasterDTO.getTPC_A()!=Boolean.FALSE ){
				inputs = inputs+"|| TPC A : "+breInputVo.getBreRequest().getCbreRequest_A().getTPC_A();
				
			};
			if ( inputMasterDTO.getWorkingSince_A()!=null && inputMasterDTO.getWorkingSince_A()!=Boolean.FALSE ){
				inputs = inputs+"|| WorkingSince A : "+breInputVo.getBreRequest().getCbreRequest_A().getWorkingSince_A();
				
			};
			if ( inputMasterDTO.getWorkingSinceFI_A()!=null && inputMasterDTO.getWorkingSinceFI_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Working SinceFI A : "+breInputVo.getBreRequest().getCbreRequest_A().getWorkingSinceFI_A();
				
			};
			if ( inputMasterDTO.getBureauScoreA()!=null && inputMasterDTO.getBureauScoreA()!=Boolean.FALSE ){
				inputs = inputs+"|| BureauScore A : "+breInputVo.getBreRequest().getCbreRequest_A().getBureauScoreA();
				
			};
			if ( inputMasterDTO.getBureauTypeA()!=null && inputMasterDTO.getBureauTypeA()!=Boolean.FALSE ){
				inputs = inputs+"|| BureauType A : "+breInputVo.getBreRequest().getCbreRequest_A().getBureauTypeA();
				
			};
			if ( inputMasterDTO.getCropsPerYear_A()!=null && inputMasterDTO.getCropsPerYear_A()!=Boolean.FALSE ){
				inputs = inputs+"|| CropsPerYear A : "+breInputVo.getBreRequest().getCbreRequest_A().getCropsPerYear_A();
				
			};
			if ( inputMasterDTO.getLandHoldingOwn_A()!=null && inputMasterDTO.getLandHoldingOwn_A()!=Boolean.FALSE ){
				inputs = inputs+"|| LandHoldingOwn A : "+breInputVo.getBreRequest().getCbreRequest_A().getLandHoldingOwn_A();
				
			};
			if ( inputMasterDTO.getLandHoldingLea_A()!=null && inputMasterDTO.getLandHoldingLea_A()!=Boolean.FALSE ){
				inputs = inputs+"|| LandHoldingLea A : "+breInputVo.getBreRequest().getCbreRequest_A().getLandHoldingLea_A();
				
			};
			if ( inputMasterDTO.getNoOfBouncing_A()!=null && inputMasterDTO.getNoOfBouncing_A()!=Boolean.FALSE ){
				inputs = inputs+"|| NoOf Bouncing A : "+breInputVo.getBreRequest().getCbreRequest_A().getNoOfBouncing_A();
				
			};
			if ( inputMasterDTO.getMaxClosureDateGT3_A()!=null && inputMasterDTO.getMaxClosureDateGT3_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Max Closure Date GT3 A : "+breInputVo.getBreRequest().getCbreRequest_A().getMaxClosureDateGT3_A();
				
			};
			if ( inputMasterDTO.getMaxClosureDateGT3_A()!=null && inputMasterDTO.getMaxClosureDateGT3_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Max Closure Date LT3 A : "+breInputVo.getBreRequest().getCbreRequest_A().getMaxClosureDateLT3_A();
				
			};
			if ( inputMasterDTO.getPresentAddAsPermAddr_A()!=null && inputMasterDTO.getPresentAddAsPermAddr_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Present Add AsPermAddr A : "+breInputVo.getBreRequest().getCbreRequest_A().getPresentAddrAsPermAddr_A();
				
			};
			if ( inputMasterDTO.getTVR_Status()!=null && inputMasterDTO.getTVR_Status()!=Boolean.FALSE ){
				inputs = inputs+"|| TVR Status: "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_Status();
			};
			if ( inputMasterDTO.getTvrStatus_A()!=null && inputMasterDTO.getTvrStatus_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Tvr Status for A : "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_Status_A();
				
			};
			if ( inputMasterDTO.getTvrBusinessStatus()!=null && inputMasterDTO.getTvrBusinessStatus()!=Boolean.FALSE ){
				inputs = inputs+"|| Tvr Business Status : "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_BusinessStatus();
				
			};
			if ( inputMasterDTO.getTvrPermAddStatus()!=null && inputMasterDTO.getTvrPermAddStatus()!=Boolean.FALSE ){
				inputs = inputs+"|| Tvr PermAdd Status : "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_PermAddressStatus();
				
			};
			if ( inputMasterDTO.getTvrRefStatus_1()!=null && inputMasterDTO.getTvrRefStatus_1()!=Boolean.FALSE ){
				inputs = inputs+"|| TvrRef Status 1 : "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_ReferenceStatus_1();
				
			};
			if ( inputMasterDTO.getTvrRefStatus_2()!=null && inputMasterDTO.getTvrRefStatus_2()!=Boolean.FALSE ){
				inputs = inputs+"|| TvrRef Status 2 : "+breInputVo.getBreRequest().getCbreRequest_A().getTVR_ReferenceStatus_2();
				
			};
			if ( inputMasterDTO.getNaNegativeArea_A()!=null && inputMasterDTO.getNaNegativeArea_A()!=Boolean.FALSE ){
				inputs = inputs+"|| NegativeArea A : "+breInputVo.getBreRequest().getCbreRequest_A().getNA_NegativeArea_A();
				
			};
			if ( inputMasterDTO.getHrpProfile_A()!=null && inputMasterDTO.getHrpProfile_A()!=Boolean.FALSE ){
				inputs = inputs+"|| HrpProfile A : "+breInputVo.getBreRequest().getCbreRequest_A().getHRPProfile_A();
				
			};
			if ( inputMasterDTO.getProneArea_A()!=null && inputMasterDTO.getProneArea_A()!=Boolean.FALSE ){
				inputs = inputs+"|| ProneArea A : "+breInputVo.getBreRequest().getCbreRequest_A().getProneArea_A();
				
			};
			if ( inputMasterDTO.getFraudMatchFlag_A()!=null && inputMasterDTO.getFraudMatchFlag_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FraudMatch Flag A : "+breInputVo.getBreRequest().getCbreRequest_A().getFraudMatchFlag_A();
				
			};
			if ( inputMasterDTO.getOverdueCCAccQualMaxAmt_A()!=null && inputMasterDTO.getOverdueCCAccQualMaxAmt_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue CC AccQualMaxAmt A : "+breInputVo.getBreRequest().getCbreRequest_A().getOverdueCCAccQualMaxAmt_A();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxAmt_A()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxAmt_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue NonCC AccQualMaxAmt A : "+breInputVo.getBreRequest().getCbreRequest_A().getOverdueNonCCAccQualMaxAmt_A();
				
			};
			if ( inputMasterDTO.getWrittenOffCCAccQualMaxDPD_A()!=null && inputMasterDTO.getWrittenOffCCAccQualMaxDPD_A()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff CC AccQualMaxDPD A : "+breInputVo.getBreRequest().getCbreRequest_A().getWrittenOffCCAccQualMaxDPD_A();
				
			};
			if ( inputMasterDTO.getWrittenOffCCAccQualMaxAmt_A()!=null && inputMasterDTO.getWrittenOffCCAccQualMaxAmt_A()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff CC AccQualMaxAmt A : "+breInputVo.getBreRequest().getCbreRequest_A().getWrittenOffCCAccQualMaxAmt_A();
				
			};
			if ( inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_A()!=null && inputMasterDTO.getWrittenOffNonCCAccQualMaxAmt_A()!=Boolean.FALSE ){
				inputs = inputs+"|| WrittenOff NonCC AccQualMaxAmt A : "+breInputVo.getBreRequest().getCbreRequest_A().getWrittenOffNonCCAccQualMaxAmt_A();
				
			};
			if ( inputMasterDTO.getWoODSettledStatus_A()!=null && inputMasterDTO.getWoODSettledStatus_A()!=Boolean.FALSE ){
				inputs = inputs+"|| WO OD SettledStatus A : "+breInputVo.getBreRequest().getCbreRequest_A().getWO_OD_Settled_Status_A();
				
			};
			if ( inputMasterDTO.getOverdueNonCCAccQualMaxDPD_A()!=null && inputMasterDTO.getOverdueNonCCAccQualMaxDPD_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Overdue NonCC AccQualMaxDPD A : "+breInputVo.getBreRequest().getCbreRequest_A().getOverdueNonCCAccQualMaxDPD_A();
				
			};
			if ( inputMasterDTO.getAge_A()!=null && inputMasterDTO.getAge_A()!=Boolean.FALSE ){
				inputs = inputs+"|| Age A : "+breInputVo.getBreRequest().getCbreRequest_A().getAge_A();
				
			};
			if ( inputMasterDTO.getFiOff_A()!=null && inputMasterDTO.getFiOff_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiOff A : "+breInputVo.getBreRequest().getCbreRequest_A().getFIOff_A();
				
			};
			if ( inputMasterDTO.getFiPerm_A()!=null && inputMasterDTO.getFiPerm_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiPerm A : "+breInputVo.getBreRequest().getCbreRequest_A().getFIPerm_A();
				
			};
			if ( inputMasterDTO.getFiPres_A()!=null && inputMasterDTO.getFiPres_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiPres A : "+breInputVo.getBreRequest().getCbreRequest_A().getFIPres_A();
				
			};
			if ( inputMasterDTO.getFiOffice_A()!=null && inputMasterDTO.getFiOffice_A()!=Boolean.FALSE ){
				inputs = inputs+"|| FiOffice A : "+breInputVo.getBreRequest().getCbreRequest_A().getFI_Office_A();
				
			};
			if ( inputMasterDTO.getPincodeMatchedRes_A()!=null && inputMasterDTO.getPincodeMatchedRes_A()!=Boolean.FALSE ){
				inputs = inputs+"|| PincodeMatched Res A : "+breInputVo.getBreRequest().getCbreRequest_A().getPinCodeMatchedRes_A();
				
			};
			if ( inputMasterDTO.getPincodeMatchedOff_A()!=null && inputMasterDTO.getPincodeMatchedOff_A()!=Boolean.FALSE ){
				inputs = inputs+"|| PincodeMatchedOff A : "+breInputVo.getBreRequest().getCbreRequest_A().getPinCodeMatchedOff_A();
				
			};
			if ( inputMasterDTO.getPincodeMatchedPer_A()!=null && inputMasterDTO.getPincodeMatchedPer_A()!=Boolean.FALSE ){
				inputs = inputs+"|| PincodeMatchedPer A : "+breInputVo.getBreRequest().getCbreRequest_A().getPinCodeMatchedPer_A();
				
			};
			if ( inputMasterDTO.getBSBand_A()!=null && inputMasterDTO.getBSBand_A()!=Boolean.FALSE ){
				inputs = inputs+"|| BSBand A : "+breInputVo.getBreRequest().getCbreRequest_A().getBSBand_A();
				
			};
			if ( inputMasterDTO.getAppPresent()!=null){
				inputs = inputs+"|| AppPresent A : "+breInputVo.getRuleTransactionDetails().getAppPresent();
			};
			if ( inputMasterDTO.getCoappPresent()!=null){
				inputs = inputs+"|| Co-App-Present : "+breInputVo.getRuleTransactionDetails().getCoappPresent();
			};
			if ( inputMasterDTO.getGuarPresent()!=null){
				inputs = inputs+"|| GuarPresent A : "+breInputVo.getRuleTransactionDetails().getGuarPresent();
			};
		}
		System.out.println(inputs+"\n");
		}
		return inputs;
	}



	private  void fireMasterRule(CreditBreInputVo breInputVo) {
		System.out.println("Firing Rule");
		kSession.insert(breInputVo);
		kSession.fireAllRules();
	}



}
