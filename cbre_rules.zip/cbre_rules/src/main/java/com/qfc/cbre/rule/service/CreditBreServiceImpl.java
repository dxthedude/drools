package com.qfc.cbre.rule.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qfc.cbre.common.util.CbreConstants;
import com.qfc.cbre.dao.CreditBreDao;
import com.qfc.cbre.qcam.vo.CbreLeadReq;
import com.qfc.cbre.rule.helper.CbreMapper;
import com.qfc.cbre.rule.helper.CreditBreRuleHelper;
import com.qfc.cbre.rule.input.vo.MstInputMasterVo;
import com.qfc.cbre.rule.transactions.dto.RuleTransactionDetailsDTO;
import com.qfc.cbre.rule.vo.CreditBreRequest;
import com.qfc.cbre.rule.vo.CreditBreResponse;
import com.qfc.cbre.rule.vo.RuleTransactionDetails;
import com.qfc.cbre.service.MiddlewareService;
import com.qfc.mst.masters.cache.MasterCache;

@Service(value="creditBreService")
public class CreditBreServiceImpl implements MiddlewareService {

	@Autowired
	CreditBreDao dao;
	@Autowired
	CreditBreRuleHelper creditBreRuleHelper;
	@Autowired
	MasterCache masterCache;
	@Autowired
	CbreMapper mapper;
	
	RuleTransactionDetailsDTO  ruledetails = new RuleTransactionDetailsDTO();
	@Override
	public CreditBreResponse saveCreditBreRequest(CreditBreRequest req,CreditBreResponse resp) {
		req.setBreStatus(CbreConstants.BreStatus.NEW);
		Long reqid = dao.saveCreditBreRequest(req);
		req.setId(reqid);
		resp = processMasterRule(req);
		return resp;
	}
	
	
	@Override
	public CreditBreResponse saveCreditBreLeadRequest(CreditBreRequest req,CreditBreResponse resp,CbreLeadReq leadReq) {
	/*	ObjectMapper map = new ObjectMapper();
		map.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);*/
		req = mapper.mapLeadDetailsToCbreRequest(req,leadReq);
		req.setBreStatus(CbreConstants.BreStatus.NEW);
		Long reqid = dao.saveCreditBreRequest(req);
		req.setId(reqid);
		resp = processMasterRule(req);
		return resp;
	}

	private CreditBreResponse processMasterRule(CreditBreRequest req) {

		ruledetails = creditBreRuleHelper.executeBreRequests(req);
		System.out.println(ruledetails);
/*		System.out.println(ruledetails.getDoneTransactions());
		System.out.println(ruledetails.getDoneTransactions().toString());*/
		dao.saveRuleDetails(ruledetails);
		if(ruledetails.getResponse()!=null) {
		System.out.println("????"+ruledetails.getResponse().get(0));
		return  CbreConstants.MAPPER.map(ruledetails.getResponse().get(0), CreditBreResponse.class);
		}else {
			return new CreditBreResponse();
		}
		
		
	}

	public void saveRuleInputDetails(MstInputMasterVo input) {
		dao.saveRuleInputDetails(input);
	}
	
	@Override
	public List<RuleTransactionDetails> getRuleTransactionList(Long leadid){
		
		return dao.getRuleTransactionList(leadid);
	}
	@Override
	public List<CreditBreResponse> getCreditBreHighestResponse(Long leadid){
		
		return dao.getCreditBreHighestResponse(leadid);
	}
	
}
