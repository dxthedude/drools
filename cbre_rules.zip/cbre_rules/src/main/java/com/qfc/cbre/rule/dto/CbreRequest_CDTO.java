package com.qfc.cbre.rule.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "cbre_request_c")
public class CbreRequest_CDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "lead_id")
	private Long leadId;
	@Column(name = "uid_c")
	private String uid_C;

	@OneToOne
	@JoinColumn(name="bre_req_id")
	private CreditBreRequestDTO breRequestId;
	
	@Column(name = "landline_no_c")
	private String landlineNo_C;
	@Column(name = "buss_landline_no_c")
	private String businessLandlineNo_C;
	@Column(name = "constitution_c")
	private String constitutionC;
	@Column(name = "dedupe_status_af_c")
	private String dedupeStatusAF_C;
	@Column(name = "dedupe_status_cf_c")
	private String dedupeStatusCF_C;
	@Column(name = "dedupe_status_c")
	private String dedupeStatus_C;
	@Column(name = "dedupe_tenure_c")
	private String dedupeTenure_C;
	@Column(name = "dedupe_count_af_c")
	private Integer dedupeCountAF_C;
	@Column(name = "dob_incorp_c")
	private Date dobIncorp_C;
	@Column(name = "fi_neg_rea_resi_c")
	private String fiNegReaResi_C;
	@Column(name = "fi_neg_rea_perm_c")
	private String fiNegReaPerm_C;
	@Column(name = "fi_neg_rea_office_c")
	private String fiNegReaOffice_C;
	@Column(name = "income_proof_c")
	private String incomeProof_C;
	@Column(name = "mobile_connection_c")
	private String mobileConnection_C; // Prepaid /postpaid
	@Column(name = "present_city_c")
	private String presentCity_C;
	@Column(name = "primary_emp_type_c")
	private String primaryEmpType_C;
	@Column(name = "property_status_c")
	private String propertyStatus_C;
	@Column(name = "residence_status_c")
	private String residenceStatus_C;
	@Column(name = "residing_since_c")
	private Integer residingSince_C;
	@Column(name = "residing_since_fi_c")
	private Integer residingSinceFI_C;
	@Column(name = "total_income_c")
	private Integer totalIncome_C;
	@Column(name = "monthly_income_c")
	private Integer monthlyIncome_C=0;
	@Column(name = "tpc_c")
	private String tpc_C;
	@Column(name = "working_since_c")
	private Integer workingSince_C;
	@Column(name = "working_since_fi_c")
	private Integer workingSinceFI_C;
	@Column(name = "bureau_score_c")
	private Integer bureauScore_C;
	@Column(name = "bureau_type_c")
	private String bureauType_C;
	@Column(name = "crops_per_year_c")
	private String cropsPerYear_C;
	@Column(name = "land_holding_own_c")
	private String landHoldingOwn_C;
	@Column(name = "land_holding_lea_c")
	private String landHoldingLea_C;
	@Column(name = "no_of_bouncing_c")
	private Integer noOfBouncing_C;
	@Column(name = "max_closure_date_gt3_c")
	private String maxClosureDateGT3_C;
	@Column(name = "max_closure_date_lt3_c")
	private String maxClosureDateLT3_C;
	@Column(name = "present_addr_as_perm_addr_c")
	private String presentAddrAsPermAddr_C;
	@Column(name = "present_addr_as_off_addr_c")
	private String presentAddrAsOffAddr_C;
	@Column(name = "fi_residence_c")
	private String fiResidence_C;
	@Column(name = "primary_employment_c")
	private String primaryEmployment_C;
	@Column(name = "tvr_status_c")
	private String tvrStatus_C;
	@Column(name = "na_negative_area_c")
	private String naNegativeArea_C;
	@Column(name = "hrp_profile_c")
	private String hrpProfile_C;
	@Column(name = "prone_area_c")
	private String proneArea_C;
	@Column(name = "na_present_c")
	private Integer naPresent_C;
	@Column(name = "np_present_C")
	private Integer npPresent_C;
	@Column(name = "pa_present_c")
	private Integer pa_present_c;
	@Column(name = "fraud_match_flag_c")
	private Integer fraudMatchFlag_C;
	@Column(name = "fm_c")
	private Integer fm_C;
	@Column(name = "overdue_cc_acc_qual_max_amt_c")
	private Double overdueCCAccQualMaxAmt_C;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_c")
	private Double overdueNonCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_non_cc_acc_qual_max_dpd_c")
	private Double writtenOffNonCCAccQualMaxDPD_C;
	@Column(name = "writtenoff_cc_acc_qual_max_amt_c")
	private Double writtenOffCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_c")
	private Double writtenOffNonCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_od_settled_status_c")
	private String writtenOffODSettledStatus_C;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_c")
	private Double overdueNonCCAccQualMaxDPD_C;
	@Column(name = "age_c")
	private Integer age_C;	//TODO: Bajaj to confirm the age in months, yr or date
	@Column(name = "fi_off_c")
	private String fiOff_C; // Difference between fiOff_C & FI_Office_C
	@Column(name = "wo_od_settled_status_c")
	private String WO_OD_Settled_Status_C;
	@Column(name = "fi_perm_c")
	private String fiPerm_C;
	@Column(name = "fi_pres_c")
	private String fiPres_C;
	@Column(name = "fi_Office_c")
	private String fiOffice_C;
	@Column(name = "pincode_matched_res_c")
	private String pincodeMatchedRes_C;
	@Column(name = "pincode_matched_off_c")
	private String pincodeMatchedOff_C;
	@Column(name = "pincode_matched_per_c")
	private String pinCodeMatchedPer_C;
	@Column(name = "bs_band_c")
	private String BSBand_C;
	
	
	
	@Column(name = "fi_type_c")
	private String fi_Type_C;
	@Column(name = "fi_status_c")
	private String fi_Status_C;
	@Column(name = "profile_c")
	private String profile_C;
	@Column(name = "landholding_type_c")
	private String landHoldingType_C;
	
	public String getProfile_C() {
		return profile_C;
	}
	public void setProfile_C(String profile_C) {
		this.profile_C = profile_C;
	}
	public String getLandHoldingType_C() {
		return landHoldingType_C;
	}
	public void setLandHoldingType_C(String landHoldingType_C) {
		this.landHoldingType_C = landHoldingType_C;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public CreditBreRequestDTO getBreRequestId() {
		return breRequestId;
	}
	public void setBreRequestId(CreditBreRequestDTO breRequestId) {
		this.breRequestId = breRequestId;
	}
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getUid_C() {
		return uid_C;
	}
	public void setUid_C(String uid_C) {
		this.uid_C = uid_C;
	}
	public String getLandlineNo_C() {
		return landlineNo_C;
	}
	public void setLandlineNo_C(String landlineNo_C) {
		this.landlineNo_C = landlineNo_C;
	}
	public String getBusinessLandlineNo_C() {
		return businessLandlineNo_C;
	}
	public void setBusinessLandlineNo_C(String businessLandlineNo_C) {
		this.businessLandlineNo_C = businessLandlineNo_C;
	}
	public String getConstitutionC() {
		return constitutionC;
	}
	public void setConstitutionC(String constitutionC) {
		this.constitutionC = constitutionC;
	}
	public String getDedupeStatusAF_C() {
		return dedupeStatusAF_C;
	}
	public void setDedupeStatusAF_C(String dedupeStatusAF_C) {
		this.dedupeStatusAF_C = dedupeStatusAF_C;
	}
	public String getDedupeStatusCF_C() {
		return dedupeStatusCF_C;
	}
	public void setDedupeStatusCF_C(String dedupeStatusCF_C) {
		this.dedupeStatusCF_C = dedupeStatusCF_C;
	}
	public String getDedupeStatus_C() {
		return dedupeStatus_C;
	}
	public void setDedupeStatus_C(String dedupeStatus_C) {
		this.dedupeStatus_C = dedupeStatus_C;
	}
	public String getDedupeTenure_C() {
		return dedupeTenure_C;
	}
	public void setDedupeTenure_C(String dedupeTenure_C) {
		this.dedupeTenure_C = dedupeTenure_C;
	}
	public Integer getDedupeCountAF_C() {
		return dedupeCountAF_C;
	}
	public void setDedupeCountAF_C(Integer dedupeCountAF_C) {
		this.dedupeCountAF_C = dedupeCountAF_C;
	}
	public Date getDobIncorp_C() {
		return dobIncorp_C;
	}
	public void setDobIncorp_C(Date dobIncorp_C) {
		this.dobIncorp_C = dobIncorp_C;
	}
	public String getFiNegReaResi_C() {
		return fiNegReaResi_C;
	}
	public void setFiNegReaResi_C(String fiNegReaResi_C) {
		this.fiNegReaResi_C = fiNegReaResi_C;
	}
	public String getFiNegReaPerm_C() {
		return fiNegReaPerm_C;
	}
	public void setFiNegReaPerm_C(String fiNegReaPerm_C) {
		this.fiNegReaPerm_C = fiNegReaPerm_C;
	}
	public String getFiNegReaOffice_C() {
		return fiNegReaOffice_C;
	}
	public void setFiNegReaOffice_C(String fiNegReaOffice_C) {
		this.fiNegReaOffice_C = fiNegReaOffice_C;
	}
	public String getIncomeProof_C() {
		return incomeProof_C;
	}
	public void setIncomeProof_C(String incomeProof_C) {
		this.incomeProof_C = incomeProof_C;
	}
	public String getMobileConnection_C() {
		return mobileConnection_C;
	}
	public void setMobileConnection_C(String mobileConnection_C) {
		this.mobileConnection_C = mobileConnection_C;
	}
	public String getPresentCity_C() {
		return presentCity_C;
	}
	public void setPresentCity_C(String presentCity_C) {
		this.presentCity_C = presentCity_C;
	}
	public String getPrimaryEmpType_C() {
		return primaryEmpType_C;
	}
	public void setPrimaryEmpType_C(String primaryEmpType_C) {
		this.primaryEmpType_C = primaryEmpType_C;
	}
	public String getPropertyStatus_C() {
		return propertyStatus_C;
	}
	public void setPropertyStatus_C(String propertyStatus_C) {
		this.propertyStatus_C = propertyStatus_C;
	}
	public String getResidenceStatus_C() {
		return residenceStatus_C;
	}
	public void setResidenceStatus_C(String residenceStatus_C) {
		this.residenceStatus_C = residenceStatus_C;
	}

	public Integer getTotalIncome_C() {
		return totalIncome_C;
	}
	public void setTotalIncome_C(Integer totalIncome_C) {
		this.totalIncome_C = totalIncome_C;
	}
	public String getTpc_C() {
		return tpc_C;
	}
	public void setTpc_C(String tpc_C) {
		this.tpc_C = tpc_C;
	}
	
	public Integer getResidingSince_C() {
		return residingSince_C;
	}
	public void setResidingSince_C(Integer residingSince_C) {
		this.residingSince_C = residingSince_C;
	}
	public Integer getResidingSinceFI_C() {
		return residingSinceFI_C;
	}
	public void setResidingSinceFI_C(Integer residingSinceFI_C) {
		this.residingSinceFI_C = residingSinceFI_C;
	}
	public Integer getWorkingSince_C() {
		return workingSince_C;
	}
	public void setWorkingSince_C(Integer workingSince_C) {
		this.workingSince_C = workingSince_C;
	}
	public Integer getWorkingSinceFI_C() {
		return workingSinceFI_C;
	}
	public void setWorkingSinceFI_C(Integer workingSinceFI_C) {
		this.workingSinceFI_C = workingSinceFI_C;
	}
	public Integer getBureauScore_C() {
		return bureauScore_C;
	}
	public void setBureauScore_C(Integer bureauScore_C) {
		this.bureauScore_C = bureauScore_C;
	}
	public String getBureauType_C() {
		return bureauType_C;
	}
	public void setBureauType_C(String bureauType_C) {
		this.bureauType_C = bureauType_C;
	}
	public String getCropsPerYear_C() {
		return cropsPerYear_C;
	}
	public void setCropsPerYear_C(String cropsPerYear_C) {
		this.cropsPerYear_C = cropsPerYear_C;
	}
	public String getLandHoldingOwn_C() {
		return landHoldingOwn_C;
	}
	public void setLandHoldingOwn_C(String landHoldingOwn_C) {
		this.landHoldingOwn_C = landHoldingOwn_C;
	}
	public String getLandHoldingLea_C() {
		return landHoldingLea_C;
	}
	public void setLandHoldingLea_C(String landHoldingLea_C) {
		this.landHoldingLea_C = landHoldingLea_C;
	}
	public Integer getNoOfBouncing_C() {
		return noOfBouncing_C;
	}
	public void setNoOfBouncing_C(Integer noOfBouncing_C) {
		this.noOfBouncing_C = noOfBouncing_C;
	}
	public String getMaxClosureDateGT3_C() {
		return maxClosureDateGT3_C;
	}
	public void setMaxClosureDateGT3_C(String maxClosureDateGT3_C) {
		this.maxClosureDateGT3_C = maxClosureDateGT3_C;
	}
	public String getMaxClosureDateLT3_C() {
		return maxClosureDateLT3_C;
	}
	public void setMaxClosureDateLT3_C(String maxClosureDateLT3_C) {
		this.maxClosureDateLT3_C = maxClosureDateLT3_C;
	}
	public String getPresentAddrAsPermAddr_C() {
		return presentAddrAsPermAddr_C;
	}
	public void setPresentAddrAsPermAddr_C(String presentAddrAsPermAddr_C) {
		this.presentAddrAsPermAddr_C = presentAddrAsPermAddr_C;
	}
	public String getFiResidence_C() {
		return fiResidence_C;
	}
	public void setFiResidence_C(String fiResidence_C) {
		this.fiResidence_C = fiResidence_C;
	}
	public String getPrimaryEmployment_C() {
		return primaryEmployment_C;
	}
	public void setPrimaryEmployment_C(String primaryEmployment_C) {
		this.primaryEmployment_C = primaryEmployment_C;
	}
	public String getTvrStatus_C() {
		return tvrStatus_C;
	}
	public void setTvrStatus_C(String tvrStatus_C) {
		this.tvrStatus_C = tvrStatus_C;
	}
	public String getNaNegativeArea_C() {
		return naNegativeArea_C;
	}
	public void setNaNegativeArea_C(String naNegativeArea_C) {
		this.naNegativeArea_C = naNegativeArea_C;
	}
	public String getHrpProfile_C() {
		return hrpProfile_C;
	}
	public void setHrpProfile_C(String hrpProfile_C) {
		this.hrpProfile_C = hrpProfile_C;
	}
	public String getProneArea_C() {
		return proneArea_C;
	}
	public void setProneArea_C(String proneArea_C) {
		this.proneArea_C = proneArea_C;
	}
	public Integer getNaPresent_C() {
		return naPresent_C;
	}
	public void setNaPresent_C(Integer naPresent_C) {
		this.naPresent_C = naPresent_C;
	}
	public Integer getNpPresent_C() {
		return npPresent_C;
	}
	public void setNpPresent_C(Integer npPresent_C) {
		this.npPresent_C = npPresent_C;
	}
	public Integer getPa_present_c() {
		return pa_present_c;
	}
	public void setPa_present_c(Integer pa_present_c) {
		this.pa_present_c = pa_present_c;
	}
	public Integer getFraudMatchFlag_C() {
		return fraudMatchFlag_C;
	}
	public void setFraudMatchFlag_C(Integer fraudMatchFlag_C) {
		this.fraudMatchFlag_C = fraudMatchFlag_C;
	}
	public Integer getFm_C() {
		return fm_C;
	}
	public void setFm_C(Integer fm_C) {
		this.fm_C = fm_C;
	}
	public Double getOverdueCCAccQualMaxAmt_C() {
		return overdueCCAccQualMaxAmt_C;
	}
	public void setOverdueCCAccQualMaxAmt_C(Double overdueCCAccQualMaxAmt_C) {
		this.overdueCCAccQualMaxAmt_C = overdueCCAccQualMaxAmt_C;
	}
	
	public String getWrittenOffODSettledStatus_C() {
		return writtenOffODSettledStatus_C;
	}
	public void setWrittenOffODSettledStatus_C(String writtenOffODSettledStatus_C) {
		this.writtenOffODSettledStatus_C = writtenOffODSettledStatus_C;
	}
	
	public Double getOverdueNonCCAccQualMaxAmt_C() {
		return overdueNonCCAccQualMaxAmt_C;
	}
	public void setOverdueNonCCAccQualMaxAmt_C(Double overdueNonCCAccQualMaxAmt_C) {
		this.overdueNonCCAccQualMaxAmt_C = overdueNonCCAccQualMaxAmt_C;
	}
	public Double getWrittenOffNonCCAccQualMaxDPD_C() {
		return writtenOffNonCCAccQualMaxDPD_C;
	}
	public void setWrittenOffNonCCAccQualMaxDPD_C(Double writtenOffNonCCAccQualMaxDPD_C) {
		this.writtenOffNonCCAccQualMaxDPD_C = writtenOffNonCCAccQualMaxDPD_C;
	}
	public Double getWrittenOffCCAccQualMaxAmt_C() {
		return writtenOffCCAccQualMaxAmt_C;
	}
	public void setWrittenOffCCAccQualMaxAmt_C(Double writtenOffCCAccQualMaxAmt_C) {
		this.writtenOffCCAccQualMaxAmt_C = writtenOffCCAccQualMaxAmt_C;
	}
	public Double getWrittenOffNonCCAccQualMaxAmt_C() {
		return writtenOffNonCCAccQualMaxAmt_C;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_C(Double writtenOffNonCCAccQualMaxAmt_C) {
		this.writtenOffNonCCAccQualMaxAmt_C = writtenOffNonCCAccQualMaxAmt_C;
	}
	public Double getOverdueNonCCAccQualMaxDPD_C() {
		return overdueNonCCAccQualMaxDPD_C;
	}
	public void setOverdueNonCCAccQualMaxDPD_C(Double overdueNonCCAccQualMaxDPD_C) {
		this.overdueNonCCAccQualMaxDPD_C = overdueNonCCAccQualMaxDPD_C;
	}
	public Integer getAge_C() {
		return age_C;
	}
	public void setAge_C(Integer age_C) {
		this.age_C = age_C;
	}
	public String getFiOff_C() {
		return fiOff_C;
	}
	public void setFiOff_C(String fiOff_C) {
		this.fiOff_C = fiOff_C;
	}
	public String getFiPerm_C() {
		return fiPerm_C;
	}
	public void setFiPerm_C(String fiPerm_C) {
		this.fiPerm_C = fiPerm_C;
	}
	public String getFiPres_C() {
		return fiPres_C;
	}
	public void setFiPres_C(String fiPres_C) {
		this.fiPres_C = fiPres_C;
	}
	public String getFiOffice_C() {
		return fiOffice_C;
	}
	public void setFiOffice_C(String fiOffice_C) {
		this.fiOffice_C = fiOffice_C;
	}
	public String getPincodeMatchedRes_C() {
		return pincodeMatchedRes_C;
	}
	public void setPincodeMatchedRes_C(String pincodeMatchedRes_C) {
		this.pincodeMatchedRes_C = pincodeMatchedRes_C;
	}
	public String getPincodeMatchedOff_C() {
		return pincodeMatchedOff_C;
	}
	public void setPincodeMatchedOff_C(String pincodeMatchedOff_C) {
		this.pincodeMatchedOff_C = pincodeMatchedOff_C;
	}
	public String getPinCodeMatchedPer_C() {
		return pinCodeMatchedPer_C;
	}
	public void setPinCodeMatchedPer_C(String pinCodeMatchedPer_C) {
		this.pinCodeMatchedPer_C = pinCodeMatchedPer_C;
	}
	public String getBSBand_C() {
		return BSBand_C;
	}
	public void setBSBand_C(String bSBand_C) {
		BSBand_C = bSBand_C;
	}
	public String getFi_Type_C() {
		return fi_Type_C;
	}
	public void setFi_Type_C(String fi_Type_C) {
		this.fi_Type_C = fi_Type_C;
	}
	public String getFi_Status_C() {
		return fi_Status_C;
	}
	public void setFi_Status_C(String fi_Status_C) {
		this.fi_Status_C = fi_Status_C;
	}
	
	public String getWO_OD_Settled_Status_C() {
		return WO_OD_Settled_Status_C;
	}
	public void setWO_OD_Settled_Status_C(String wO_OD_Settled_Status_C) {
		WO_OD_Settled_Status_C = wO_OD_Settled_Status_C;
	}
	
	public String getPresentAddrAsOffAddr_C() {
		return presentAddrAsOffAddr_C;
	}
	public void setPresentAddrAsOffAddr_C(String presentAddrAsOffAddr_C) {
		this.presentAddrAsOffAddr_C = presentAddrAsOffAddr_C;
	}
	
	public Integer getMonthlyIncome_C() {
		return monthlyIncome_C;
	}
	public void setMonthlyIncome_C(Integer monthlyIncome_C) {
		this.monthlyIncome_C = monthlyIncome_C;
	}
	@Override
	public String toString() {
		return "CbreRequest_CDTO [id=" + id + ", leadId=" + leadId + ", uid_C=" + uid_C + ", breRequestId="
				+ breRequestId + ", landlineNo_C=" + landlineNo_C + ", businessLandlineNo_C=" + businessLandlineNo_C
				+ ", constitutionC=" + constitutionC + ", dedupeStatusAF_C=" + dedupeStatusAF_C + ", dedupeStatusCF_C="
				+ dedupeStatusCF_C + ", dedupeStatus_C=" + dedupeStatus_C + ", dedupeTenure_C=" + dedupeTenure_C
				+ ", dedupeCountAF_C=" + dedupeCountAF_C + ", dobIncorp_C=" + dobIncorp_C + ", fiNegReaResi_C="
				+ fiNegReaResi_C + ", fiNegReaPerm_C=" + fiNegReaPerm_C + ", fiNegReaOffice_C=" + fiNegReaOffice_C
				+ ", incomeProof_C=" + incomeProof_C + ", mobileConnection_C=" + mobileConnection_C + ", presentCity_C="
				+ presentCity_C + ", primaryEmpType_C=" + primaryEmpType_C + ", propertyStatus_C=" + propertyStatus_C
				+ ", residenceStatus_C=" + residenceStatus_C + ", residingSince_C=" + residingSince_C
				+ ", residingSinceFI_C=" + residingSinceFI_C + ", totalIncome_C=" + totalIncome_C + ", tpc_C=" + tpc_C
				+ ", workingSince_C=" + workingSince_C + ", workingSinceFI_C=" + workingSinceFI_C + ", bureauScore_C="
				+ bureauScore_C + ", bureauType_C=" + bureauType_C + ", cropsPerYear_C=" + cropsPerYear_C
				+ ", landHoldingOwn_C=" + landHoldingOwn_C + ", landHoldingLea_C=" + landHoldingLea_C
				+ ", noOfBouncing_C=" + noOfBouncing_C + ", maxClosureDateGT3_C=" + maxClosureDateGT3_C
				+ ", maxClosureDateLT3_C=" + maxClosureDateLT3_C + ", presentAddrAsPermAddr_C="
				+ presentAddrAsPermAddr_C + ", presentAddrAsOffAddr_C=" + presentAddrAsOffAddr_C + ", fiResidence_C="
				+ fiResidence_C + ", primaryEmployment_C=" + primaryEmployment_C + ", tvrStatus_C=" + tvrStatus_C
				+ ", naNegativeArea_C=" + naNegativeArea_C + ", hrpProfile_C=" + hrpProfile_C + ", proneArea_C="
				+ proneArea_C + ", naPresent_C=" + naPresent_C + ", npPresent_C=" + npPresent_C + ", pa_present_c="
				+ pa_present_c + ", fraudMatchFlag_C=" + fraudMatchFlag_C + ", fm_C=" + fm_C
				+ ", overdueCCAccQualMaxAmt_C=" + overdueCCAccQualMaxAmt_C + ", overdueNonCCAccQualMaxAmt_C="
				+ overdueNonCCAccQualMaxAmt_C + ", writtenOffNonCCAccQualMaxDPD_C=" + writtenOffNonCCAccQualMaxDPD_C
				+ ", writtenOffCCAccQualMaxAmt_C=" + writtenOffCCAccQualMaxAmt_C + ", writtenOffNonCCAccQualMaxAmt_C="
				+ writtenOffNonCCAccQualMaxAmt_C + ", writtenOffODSettledStatus_C=" + writtenOffODSettledStatus_C
				+ ", overdueNonCCAccQualMaxDPD_C=" + overdueNonCCAccQualMaxDPD_C + ", age_C=" + age_C + ", fiOff_C="
				+ fiOff_C + ", WO_OD_Settled_Status_C=" + WO_OD_Settled_Status_C + ", fiPerm_C=" + fiPerm_C
				+ ", fiPres_C=" + fiPres_C + ", fiOffice_C=" + fiOffice_C + ", pincodeMatchedRes_C="
				+ pincodeMatchedRes_C + ", pincodeMatchedOff_C=" + pincodeMatchedOff_C + ", pinCodeMatchedPer_C="
				+ pinCodeMatchedPer_C + ", BSBand_C=" + BSBand_C + ", fi_Type_C=" + fi_Type_C + ", fi_Status_C="
				+ fi_Status_C + ", profile_C=" + profile_C + "]";
	}
	
	
}
