package com.qfc.cbre.rule.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "cbre_request_g")
public class CbreRequest_GDTO {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "lead_id")
	private Long leadId;
	@Column(name = "uid_g")
	private String uid_G;
	
	@OneToOne
	@JoinColumn(name="bre_req_id")
	private CreditBreRequestDTO breRequestId;
	
	@Column(name = "dedupe_status_af_g")
	private String dedupeStatusAF_G;
	@Column(name = "dedupe_status_cf_g")
	private String dedupeStatusCF_G;
	@Column(name = "dedupe_status_g")
	private String dedupeStatus_G;
	@Column(name = "dedupe_tenure_g")
	private String dedupeTenure_G;
	@Column(name = "dob_incorp_g")
	private Date dobIncorp_G;
	@Column(name = "fi_neg_rea_resi_g")
	private String fiNegReaResi_G;
	@Column(name = "fi_neg_rea_perm_g")
	private String fiNegReaPerm_G;
	@Column(name = "fi_neg_rea_office_g")
	private String fiNegReaOffice_G;
	@Column(name = "primary_emp_type_g")
	private String primaryEmpType_G;
	@Column(name = "property_status_g")
	private String propertyStatus_G;
	@Column(name = "residence_status_g")
	private String residenceStatus_G;
	@Column(name = "residing_since_g")
	private Integer residingSince_G;
	@Column(name = "residing_since_fi_g")
	private Integer residingSinceFI_G;
	@Column(name = "tpc_g")
	private String tpc_G;
	@Column(name = "working_since_g")
	private Integer workingSince_G;
	@Column(name = "working_since_fi_g")
	private Integer workingSinceFI_G;
	@Column(name = "bureau_score_g")
	private Integer bureauScore_G;
	@Column(name = "bureau_type_g")
	private String bureauType_G;
	@Column(name = "no_of_bouncing_g")
	private Integer noOfBouncing_G;
	@Column(name = "max_closure_date_gt3_g")
	private String maxClosureDateGT3_G;
	@Column(name = "max_closure_date_lt3_g")
	private String maxClosureDateLT3_G;
	@Column(name = "tvr_status_g")
	private String tvrStatus_G;
	@Column(name = "na_negative_area_g")
	private String naNegativeArea_G;
	@Column(name = "hrp_profile_g")
	private String HRPProfile_G;
	@Column(name = "prone_area_g")
	private String proneArea_G;
	@Column(name = "na_g")
	private Integer na_G;
	@Column(name = "np_g")
	private Integer np_G;
	@Column(name = "pa_g")
	private Integer pa_G;
	@Column(name = "fraud_match_flag_g")
	private Integer fraudMatchFlag_G;
	@Column(name = "fm_g")
	private Integer fm_G;
	@Column(name = "overdue_cc_acc_qual_max_amt_g")
	private Double overdueCCAccQualMaxAmt_G;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_g")
	private Double overdueNonCCAccQualMaxAmt_G;
	@Column(name = "Writtenoff_non_cc_acc_qual_max_dpd_g")
	private Double WrittenOffNonCCAccQualMaxDPD_G;
	@Column(name = "writtenoff_cc_acc_qual_max_amt_g")
	private Double writtenOffCCAccQualMaxAmt_G;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_g")
	private Double writtenOffNonCCAccQualMaxAmt_G;
	@Column(name = "wo_od_settled_status_g")
	private String woODSettledStatus_G;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_g")
	private Double overdueNonCCAccQualMaxDPD_G;
	@Column(name = "age_g")
	private Integer age_G;	//TODO: Bajaj to confirm the age in months, yr or date
	@Column(name = "fi_pres_g")
	private String fiPres_G;
	@Column(name = "pincode_matched_res_g")
	private String pincodeMatchedRes_G;
	@Column(name = "pincode_matched_off_g")
	private String pincodeMatchedOff_G;
	@Column(name = "bs_band_g")
	private String BSBand_G;
	
	
	@Column(name = "fi_type_g")
	private String fi_Type_G;
	@Column(name = "fi_status_g")
	private String fi_Status_G;
	@Column(name = "profile_g")
	private String profile_G;
	@Column(name = "landholding_type_g")
	private String landHoldingType_G;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getUid_G() {
		return uid_G;
	}
	public void setUid_G(String uid_G) {
		this.uid_G = uid_G;
	}
	public String getDedupeStatusAF_G() {
		return dedupeStatusAF_G;
	}
	public void setDedupeStatusAF_G(String dedupeStatusAF_G) {
		this.dedupeStatusAF_G = dedupeStatusAF_G;
	}
	public String getDedupeStatusCF_G() {
		return dedupeStatusCF_G;
	}
	public void setDedupeStatusCF_G(String dedupeStatusCF_G) {
		this.dedupeStatusCF_G = dedupeStatusCF_G;
	}
	public String getDedupeStatus_G() {
		return dedupeStatus_G;
	}
	public void setDedupeStatus_G(String dedupeStatus_G) {
		this.dedupeStatus_G = dedupeStatus_G;
	}
	public String getDedupeTenure_G() {
		return dedupeTenure_G;
	}
	public void setDedupeTenure_G(String dedupeTenure_G) {
		this.dedupeTenure_G = dedupeTenure_G;
	}
	public Date getDobIncorp_G() {
		return dobIncorp_G;
	}
	public void setDobIncorp_G(Date dobIncorp_G) {
		this.dobIncorp_G = dobIncorp_G;
	}
	public String getFiNegReaResi_G() {
		return fiNegReaResi_G;
	}
	public void setFiNegReaResi_G(String fiNegReaResi_G) {
		this.fiNegReaResi_G = fiNegReaResi_G;
	}
	public String getFiNegReaPerm_G() {
		return fiNegReaPerm_G;
	}
	public void setFiNegReaPerm_G(String fiNegReaPerm_G) {
		this.fiNegReaPerm_G = fiNegReaPerm_G;
	}
	public String getFiNegReaOffice_G() {
		return fiNegReaOffice_G;
	}
	public void setFiNegReaOffice_G(String fiNegReaOffice_G) {
		this.fiNegReaOffice_G = fiNegReaOffice_G;
	}
	public String getPrimaryEmpType_G() {
		return primaryEmpType_G;
	}
	public void setPrimaryEmpType_G(String primaryEmpType_G) {
		this.primaryEmpType_G = primaryEmpType_G;
	}
	public String getPropertyStatus_G() {
		return propertyStatus_G;
	}
	public void setPropertyStatus_G(String propertyStatus_G) {
		this.propertyStatus_G = propertyStatus_G;
	}
	public String getResidenceStatus_G() {
		return residenceStatus_G;
	}
	public void setResidenceStatus_G(String residenceStatus_G) {
		this.residenceStatus_G = residenceStatus_G;
	}
	
	public String getTpc_G() {
		return tpc_G;
	}
	public void setTpc_G(String tpc_G) {
		this.tpc_G = tpc_G;
	}
	
	public Integer getResidingSince_G() {
		return residingSince_G;
	}
	public void setResidingSince_G(Integer residingSince_G) {
		this.residingSince_G = residingSince_G;
	}
	public Integer getResidingSinceFI_G() {
		return residingSinceFI_G;
	}
	public void setResidingSinceFI_G(Integer residingSinceFI_G) {
		this.residingSinceFI_G = residingSinceFI_G;
	}
	public Integer getWorkingSince_G() {
		return workingSince_G;
	}
	public void setWorkingSince_G(Integer workingSince_G) {
		this.workingSince_G = workingSince_G;
	}
	public Integer getWorkingSinceFI_G() {
		return workingSinceFI_G;
	}
	public void setWorkingSinceFI_G(Integer workingSinceFI_G) {
		this.workingSinceFI_G = workingSinceFI_G;
	}
	public String getProfile_G() {
		return profile_G;
	}
	public void setProfile_G(String profile_G) {
		this.profile_G = profile_G;
	}
	public Integer getBureauScore_G() {
		return bureauScore_G;
	}
	public void setBureauScore_G(Integer bureauScore_G) {
		this.bureauScore_G = bureauScore_G;
	}
	public String getBureauType_G() {
		return bureauType_G;
	}
	public void setBureauType_G(String bureauType_G) {
		this.bureauType_G = bureauType_G;
	}
	public Integer getNoOfBouncing_G() {
		return noOfBouncing_G;
	}
	public void setNoOfBouncing_G(Integer noOfBouncing_G) {
		this.noOfBouncing_G = noOfBouncing_G;
	}
	public String getMaxClosureDateGT3_G() {
		return maxClosureDateGT3_G;
	}
	public void setMaxClosureDateGT3_G(String maxClosureDateGT3_G) {
		this.maxClosureDateGT3_G = maxClosureDateGT3_G;
	}
	public String getMaxClosureDateLT3_G() {
		return maxClosureDateLT3_G;
	}
	public void setMaxClosureDateLT3_G(String maxClosureDateLT3_G) {
		this.maxClosureDateLT3_G = maxClosureDateLT3_G;
	}
	public String getTvrStatus_G() {
		return tvrStatus_G;
	}
	public void setTvrStatus_G(String tvrStatus_G) {
		this.tvrStatus_G = tvrStatus_G;
	}
	public String getNaNegativeArea_G() {
		return naNegativeArea_G;
	}
	public void setNaNegativeArea_G(String naNegativeArea_G) {
		this.naNegativeArea_G = naNegativeArea_G;
	}
	public String getHRPProfile_G() {
		return HRPProfile_G;
	}
	public void setHRPProfile_G(String hRPProfile_G) {
		HRPProfile_G = hRPProfile_G;
	}
	public String getProneArea_G() {
		return proneArea_G;
	}
	public void setProneArea_G(String proneArea_G) {
		this.proneArea_G = proneArea_G;
	}
	public Integer getNa_G() {
		return na_G;
	}
	public void setNa_G(Integer na_G) {
		this.na_G = na_G;
	}
	public Integer getNp_G() {
		return np_G;
	}
	public void setNp_G(Integer np_G) {
		this.np_G = np_G;
	}
	public Integer getPa_G() {
		return pa_G;
	}
	public void setPa_G(Integer pa_G) {
		this.pa_G = pa_G;
	}
	public Integer getFraudMatchFlag_G() {
		return fraudMatchFlag_G;
	}
	public void setFraudMatchFlag_G(Integer fraudMatchFlag_G) {
		this.fraudMatchFlag_G = fraudMatchFlag_G;
	}
	public Integer getFm_G() {
		return fm_G;
	}
	public void setFm_G(Integer fm_G) {
		this.fm_G = fm_G;
	}
	public Double getOverdueCCAccQualMaxAmt_G() {
		return overdueCCAccQualMaxAmt_G;
	}
	public void setOverdueCCAccQualMaxAmt_G(Double overdueCCAccQualMaxAmt_G) {
		this.overdueCCAccQualMaxAmt_G = overdueCCAccQualMaxAmt_G;
	}
	
	public String getWoODSettledStatus_G() {
		return woODSettledStatus_G;
	}
	public void setWoODSettledStatus_G(String woODSettledStatus_G) {
		this.woODSettledStatus_G = woODSettledStatus_G;
	}
	
	public Double getOverdueNonCCAccQualMaxAmt_G() {
		return overdueNonCCAccQualMaxAmt_G;
	}
	public void setOverdueNonCCAccQualMaxAmt_G(Double overdueNonCCAccQualMaxAmt_G) {
		this.overdueNonCCAccQualMaxAmt_G = overdueNonCCAccQualMaxAmt_G;
	}
	public Double getWrittenOffNonCCAccQualMaxDPD_G() {
		return WrittenOffNonCCAccQualMaxDPD_G;
	}
	public void setWrittenOffNonCCAccQualMaxDPD_G(Double writtenOffNonCCAccQualMaxDPD_G) {
		WrittenOffNonCCAccQualMaxDPD_G = writtenOffNonCCAccQualMaxDPD_G;
	}
	public Double getWrittenOffCCAccQualMaxAmt_G() {
		return writtenOffCCAccQualMaxAmt_G;
	}
	public void setWrittenOffCCAccQualMaxAmt_G(Double writtenOffCCAccQualMaxAmt_G) {
		this.writtenOffCCAccQualMaxAmt_G = writtenOffCCAccQualMaxAmt_G;
	}
	public Double getWrittenOffNonCCAccQualMaxAmt_G() {
		return writtenOffNonCCAccQualMaxAmt_G;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_G(Double writtenOffNonCCAccQualMaxAmt_G) {
		this.writtenOffNonCCAccQualMaxAmt_G = writtenOffNonCCAccQualMaxAmt_G;
	}
	public Double getOverdueNonCCAccQualMaxDPD_G() {
		return overdueNonCCAccQualMaxDPD_G;
	}
	public void setOverdueNonCCAccQualMaxDPD_G(Double overdueNonCCAccQualMaxDPD_G) {
		this.overdueNonCCAccQualMaxDPD_G = overdueNonCCAccQualMaxDPD_G;
	}
	public Integer getAge_G() {
		return age_G;
	}
	public void setAge_G(Integer age_G) {
		this.age_G = age_G;
	}
	public String getFiPres_G() {
		return fiPres_G;
	}
	public void setFiPres_G(String fiPres_G) {
		this.fiPres_G = fiPres_G;
	}
	public String getPincodeMatchedRes_G() {
		return pincodeMatchedRes_G;
	}
	public void setPincodeMatchedRes_G(String pincodeMatchedRes_G) {
		this.pincodeMatchedRes_G = pincodeMatchedRes_G;
	}
	public String getPincodeMatchedOff_G() {
		return pincodeMatchedOff_G;
	}
	public void setPincodeMatchedOff_G(String pincodeMatchedOff_G) {
		this.pincodeMatchedOff_G = pincodeMatchedOff_G;
	}
	public String getBSBand_G() {
		return BSBand_G;
	}
	public void setBSBand_G(String bSBand_G) {
		BSBand_G = bSBand_G;
	}
	
	public CreditBreRequestDTO getBreRequestId() {
		return breRequestId;
	}
	public void setBreRequestId(CreditBreRequestDTO breRequestId) {
		this.breRequestId = breRequestId;
	}
	public String getFi_Type_G() {
		return fi_Type_G;
	}
	public void setFi_Type_G(String fi_Type_G) {
		this.fi_Type_G = fi_Type_G;
	}
	public String getFi_Status_G() {
		return fi_Status_G;
	}
	public void setFi_Status_G(String fi_Status_G) {
		this.fi_Status_G = fi_Status_G;
	}
	@Override
	public String toString() {
		return "CbreRequest_GDTO [id=" + id + ", leadId=" + leadId + ", uid_G=" + uid_G + ", breRequestId="
				+ breRequestId + ", dedupeStatusAF_G=" + dedupeStatusAF_G + ", dedupeStatusCF_G=" + dedupeStatusCF_G
				+ ", dedupeStatus_G=" + dedupeStatus_G + ", dedupeTenure_G=" + dedupeTenure_G + ", dobIncorp_G="
				+ dobIncorp_G + ", fiNegReaResi_G=" + fiNegReaResi_G + ", fiNegReaPerm_G=" + fiNegReaPerm_G
				+ ", fiNegReaOffice_G=" + fiNegReaOffice_G + ", primaryEmpType_G=" + primaryEmpType_G
				+ ", propertyStatus_G=" + propertyStatus_G + ", residenceStatus_G=" + residenceStatus_G
				+ ", residingSince_G=" + residingSince_G + ", residingSinceFI_G=" + residingSinceFI_G + ", tpc_G="
				+ tpc_G + ", workingSince_G=" + workingSince_G + ", workingSinceFI_G=" + workingSinceFI_G
				+ ", bureauScore_G=" + bureauScore_G + ", bureauType_G=" + bureauType_G + ", noOfBouncing_G="
				+ noOfBouncing_G + ", maxClosureDateGT3_G=" + maxClosureDateGT3_G + ", maxClosureDateLT3_G="
				+ maxClosureDateLT3_G + ", tvrStatus_G=" + tvrStatus_G + ", naNegativeArea_G=" + naNegativeArea_G
				+ ", HRPProfile_G=" + HRPProfile_G + ", proneArea_G=" + proneArea_G + ", na_G=" + na_G + ", np_G="
				+ np_G + ", pa_G=" + pa_G + ", fraudMatchFlag_G=" + fraudMatchFlag_G + ", fm_G=" + fm_G
				+ ", overdueCCAccQualMaxAmt_G=" + overdueCCAccQualMaxAmt_G + ", overdueNonCCAccQualMaxAmt_G="
				+ overdueNonCCAccQualMaxAmt_G + ", WrittenOffNonCCAccQualMaxDPD_G=" + WrittenOffNonCCAccQualMaxDPD_G
				+ ", writtenOffCCAccQualMaxAmt_G=" + writtenOffCCAccQualMaxAmt_G + ", writtenOffNonCCAccQualMaxAmt_G="
				+ writtenOffNonCCAccQualMaxAmt_G + ", woODSettledStatus_G=" + woODSettledStatus_G
				+ ", overdueNonCCAccQualMaxDPD_G=" + overdueNonCCAccQualMaxDPD_G + ", age_G=" + age_G + ", fiPres_G="
				+ fiPres_G + ", pincodeMatchedRes_G=" + pincodeMatchedRes_G + ", pincodeMatchedOff_G="
				+ pincodeMatchedOff_G + ", BSBand_G=" + BSBand_G + ", fi_Type_G=" + fi_Type_G + ", fi_Status_G="
				+ fi_Status_G + ", profile_G=" + profile_G + "]";
	}
	public String getLandHoldingType_G() {
		return landHoldingType_G;
	}
	public void setLandHoldingType_G(String landHoldingType_G) {
		this.landHoldingType_G = landHoldingType_G;
	}
	
	
	
}
