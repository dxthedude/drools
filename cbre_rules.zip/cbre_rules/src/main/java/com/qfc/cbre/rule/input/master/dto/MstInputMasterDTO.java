package com.qfc.cbre.rule.input.master.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.qfc.cbre.common.dto.BaseDTO;

@Entity
@Table(name="mst_input_master")
public class MstInputMasterDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name="ruleid")
	private Long ruleId;
	@Column(name="rule_name")
	private String rule_name;
	@Column(name = "lead_id")
	private Boolean leadId;
	@Column(name = "uid_a", length=50)
	private Boolean uid_A;
	@Column(name = "uid_c", length=50)
	private Boolean uid_C;
	@Column(name = "uid_g", length=50)
	private Boolean uid_G;
	
	@Column(name = "present_c", length=1)
	private Boolean present_C;
	@Column(name = "present_g", length=1)
	private Boolean present_G;
	@Column(name = "app_rel_with_c", length=100)
	private Boolean relWithApp_C;
	private Boolean coAppRelation;	//??
	
	@Column(name = "emi")
	private Boolean EMI;
	@Column(name = "future_emi")
	private Boolean futureEMI;
	@Column(name = "no_of_future_emi")
	private Boolean noOfFutureEMI;
	@Column(name = "advance_emi_amt")
	private Boolean advanceEMIAmt;
	@Column(name = "ltv")
	private Boolean LTV;
	@Column(name = "no_of_vehicles")
	private Boolean noOfVehicles;
	private Boolean totalNumberOfVehicle; // diff between noOfVeh and totalNoOfVeh
	@Column(name = "tenure")
	private Boolean tenure;
	@Column(name = "product")
	private Boolean product;
	@Column(name = "product_category")
	private Boolean productCategory;
	@Column(name = "amount_financed")
	private Boolean amountFinanced;
	@Column(name = "applied_finance_amt")
	private Boolean appliedFinanceAmt;
	@Column(name = "margin_money")
	private Boolean marginMoney;
	
	@Column(name = "customer_type")
	private Boolean customerType;
	@Column(name = "cust_cat_final")
	private Boolean custCatFinal;
	@Column(name = "repayment_mode")
	private Boolean repaymentMode;
	@Column(name = "repayment_from", length=1)
	private Boolean repaymentFrom;
	
	@Column(name = "subscriber_id")
	private Boolean subscriberId;	
	@Column(name = "layout_id")         //??/
	private Boolean layoutId; 			//??
	/*@Column(name = "rule_id")
	private Boolean ruleId;				//??
*/	@Column(name = "abb")
	private Boolean ABB;				//??
	@Column(name = "account_vintage")
	private Boolean accountVintage;
	
	@Column(name = "type_of_refinance")
	private Boolean typeOfRefinance;
	@Column(name = "registration_no")
	private Boolean registrationNo;
	
	@Column(name = "login_date")
	private Boolean loginDate;
	@Column(name = "disbursement_date_old_lan")
	private Boolean disbursementDateOldLAN;
	@Column(name = "blue_book_price")
	private Boolean blueBookPrice;
	
	@Column(name = "scheme_type")
	private Boolean schemeType;
	@Column(name = "segment")
	private Boolean segment;
	@Column(name = "subCode")
	private Boolean subCode;
	@Column(name = "asset_type")
	private Boolean assetType;
	@Column(name = "offer_type")
	private Boolean offerType; //Normal
	
	@Column(name = "scheme_grp")
	private Boolean schemeGrp;
	@Column(name = "scheme_code")
	private Boolean schemeCode;
	
	@Column(name = "branch")
	private Boolean branch;
	@Column(name = "supplier_category")
	private Boolean supplierCategory;
	@Column(name = "supplier_state")
	private Boolean supplierState;
	@Column(name = "total_exposure")
	private Boolean totalExposure;
	
	@Column(name = "make")
	private String make;
	@Column(name = "model")
	private String model;
	@Column(name = "applied_net_ltv")
	private Double appliedNetLtv;
	@Column(name = "eligible_ltv")
	private Double eligibleLtv;
	@Column(name = "fcu_status")
	private String fcuStatus;
	
	@Column(name = "cust_sub_cat")
	private String custSubCat;
	
	//Guranator
	/*@Column(name = "uid_g")
	private Boolean uid_G;*/
	@Column(name = "dedupe_status_af_g")
	private Boolean dedupeStatusAF_G;
	@Column(name = "dedupe_status_cf_g")
	private Boolean dedupeStatusCF_G;
	@Column(name = "dedupe_status_g")
	private Boolean dedupeStatus_G;
	@Column(name = "dedupe_tenure_g")
	private Boolean dedupeTenure_G;
	@Column(name = "dob_incorp_g")
	private Boolean dobIncorp_G;
	@Column(name = "fi_neg_rea_resi_g")
	private Boolean fiNegReaResi_G;
	@Column(name = "fi_neg_rea_perm_g")
	private Boolean fiNegReaPerm_G;
	@Column(name = "fi_neg_rea_office_g")
	private Boolean fiNegReaOffice_G;
	@Column(name = "primary_emp_type_g")
	private Boolean primaryEmpType_G;
	@Column(name = "property_status_g")
	private Boolean propertyStatus_G;
	@Column(name = "residence_status_g")
	private Boolean residenceStatus_G;
	@Column(name = "residing_since_g")
	private Boolean residingSince_G;
	@Column(name = "residing_since_fi_g")
	private Boolean residingSinceFI_G;
	@Column(name = "tpc_g")
	private Boolean tpc_G;
	@Column(name = "working_since_g")
	private Boolean workingSince_G;
	@Column(name = "working_since_fi_g")
	private Boolean workingSinceFI_G;
	@Column(name = "bureau_score_g")
	private Boolean bureauScore_G;
	@Column(name = "bureau_type_g")
	private Boolean bureauType_G;
	@Column(name = "no_of_bouncing_g")
	private Boolean noOfBouncing_G;
	@Column(name = "max_closure_date_gt3_g")
	private Boolean maxClosureDateGT3_G;
	@Column(name = "max_closure_date_lt3_g")
	private Boolean maxClosureDateLT3_G;
	@Column(name = "tvr_status_g")
	private Boolean tvrStatus_G;
	@Column(name = "na_negative_area_g")
	private Boolean naNegativeArea_G;
	@Column(name = "hrp_profile_g")
	private Boolean HRPProfile_G;
	@Column(name = "prone_area_g")
	private Boolean proneArea_G;
	@Column(name = "na_g")
	private Boolean na_G;
	@Column(name = "np_g")
	private Boolean np_G;
	@Column(name = "pa_g")
	private Boolean pa_G;
	@Column(name = "fraud_match_flag_g")
	private Boolean fraudMatchFlag_G;
	@Column(name = "fm_g")
	private Boolean fm_G;
	@Column(name = "overdue_cc_acc_qual_max_amt_g")
	private Boolean overdueCCAccQualMaxAmt_G;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_g")
	private Boolean overdueNonCCAccQualMaxAmt_G;
	@Column(name = "Writtenoff_non_cc_acc_qual_max_dpd_g")
	private Boolean WrittenOffNonCCAccQualMaxDPD_G;
	@Column(name = "writtenoff_cc_acc_qual_max_amt_g")
	private Boolean writtenOffCCAccQualMaxAmt_G;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_g")
	private Boolean writtenOffNonCCAccQualMaxAmt_G;
	@Column(name = "wo_od_settled_status_g")
	private Boolean woODSettledStatus_G;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_g")
	private Boolean overdueNonCCAccQualMaxDPD_G;
	@Column(name = "age_g")
	private Boolean age_G;	//TODO: Bajaj to confirm the age in months, yr or Boolean
	@Column(name = "fi_pres_g")
	private Boolean fiPres_G;
	@Column(name = "pincode_matched_res_g")
	private Boolean pincodeMatchedRes_G;
	@Column(name = "pincode_matched_off_g")
	private Boolean pincodeMatchedOff_G;
	@Column(name = "bs_band_g")
	private Boolean BSBand_G;
	
	@Column(name = "fi_type_g")
	private String Fi_Type_G;
	@Column(name = "fi_status_g")
	private String Fi_Status_G;
	
	//CO-Applicant
	/*@Column(name = "uid_c")
	private Boolean uid_C;*/
	@Column(name = "landline_no_c")
	private Boolean landlineNo_C;
	@Column(name = "buss_landline_no_c")
	private Boolean businessLandlineNo_C;
	@Column(name = "constitution_c")
	private Boolean constitutionC;
	@Column(name = "dedupe_status_af_c")
	private Boolean dedupeStatusAF_C;
	@Column(name = "dedupe_status_cf_c")
	private Boolean dedupeStatusCF_C;
	@Column(name = "dedupe_status_c")
	private Boolean dedupeStatus_C;
	@Column(name = "dedupe_tenure_c")
	private Boolean dedupeTenure_C;
	@Column(name = "dedupe_count_af_c")
	private Boolean dedupeCountAF_C;
	@Column(name = "dob_incorp_c")
	private Boolean dobIncorp_C;
	@Column(name = "fi_neg_rea_resi_c")
	private Boolean fiNegReaResi_C;
	@Column(name = "fi_neg_rea_perm_c")
	private Boolean fiNegReaPerm_C;
	@Column(name = "fi_neg_rea_office_c")
	private Boolean fiNegReaOffice_C;
	@Column(name = "income_proof_c")
	private Boolean incomeProof_C;
	@Column(name = "mobile_connection_c")
	private Boolean mobileConnection_C; // Prepaid /postpaid
	@Column(name = "present_city_c")
	private Boolean presentCity_C;
	@Column(name = "primary_emp_type_c")
	private Boolean primaryEmpType_C;
	@Column(name = "property_status_c")
	private Boolean propertyStatus_C;
	@Column(name = "residence_status_c")
	private Boolean residenceStatus_C;
	@Column(name = "residing_since_c")
	private Boolean residingSince_C;
	@Column(name = "residing_since_fi_c")
	private Boolean residingSinceFI_C;
	@Column(name = "total_income_c")
	private Boolean totalIncome_C;
	@Column(name = "tpc_c")
	private Boolean tpc_C;
	@Column(name = "working_since_c")
	private Boolean workingSince_C;
	@Column(name = "working_since_fi_c")
	private Boolean workingSinceFI_C;
	@Column(name = "bureau_score_c")
	private Boolean bureauScore_C;
	@Column(name = "bureau_type_c")
	private Boolean bureauType_C;
	@Column(name = "crops_per_year_c")
	private Boolean cropsPerYear_C;
	@Column(name = "land_holding_own_c")
	private Boolean landHoldingOwn_C;
	@Column(name = "land_holding_lea_c")
	private Boolean landHoldingLea_C;
	@Column(name = "no_of_bouncing_c")
	private Boolean noOfBouncing_C;
	@Column(name = "max_closure_date_gt3_c")
	private Boolean maxClosureDateGT3_C;
	@Column(name = "max_closure_date_lt3_c")
	private Boolean maxClosureDateLT3_C;
	@Column(name = "present_addr_as_perm_addr_c")
	private Boolean presentAddrAsPermAddr_C;
	@Column(name = "fi_residence_c")
	private Boolean fiResidence_C;
	@Column(name = "primary_employment_c")
	private Boolean primaryEmployment_C;
	@Column(name = "tvr_status_c")
	private Boolean tvrStatus_C;
	@Column(name = "na_negative_area_c")
	private Boolean naNegativeArea_C;
	@Column(name = "hrp_profile_c")
	private Boolean hrpProfile_C;
	@Column(name = "prone_area_c")
	private Boolean proneArea_C;
	@Column(name = "na_present_c")
	private Boolean naPresent_C;
	@Column(name = "np_present_C")
	private Boolean npPresent_C;
	@Column(name = "pa_present_c")
	private Boolean pa_present_c;
	@Column(name = "fraud_match_flag_c")
	private Boolean fraudMatchFlag_C;
	@Column(name = "fm_c")
	private Boolean fm_C;
	@Column(name = "overdue_cc_acc_qual_max_amt_c")
	private Boolean overdueCCAccQualMaxAmt_C;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_c")
	private Boolean overdueNonCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_non_cc_acc_qual_max_dpd_c")
	private Boolean writtenOffNonCCAccQualMaxDPD_C;
	@Column(name = "writtenoff_cc_acc_qual_max_amt_c")
	private Boolean writtenOffCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_c")
	private Boolean writtenOffNonCCAccQualMaxAmt_C;
	@Column(name = "writtenoff_od_settled_status_c")
	private Boolean writtenOffODSettledStatus_C;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_c")
	private Boolean overdueNonCCAccQualMaxDPD_C;
	@Column(name = "age_c")
	private Boolean age_C;	//TODO: Bajaj to confirm the age in months, yr or Date
	@Column(name = "fi_off_c")
	private Boolean fiOff_C; // Difference between fiOff_C & FI_Office_C
	@Column(name = "fi_perm_c")
	private Boolean fiPerm_C;
	@Column(name = "fi_pres_c")
	private Boolean fiPres_C;
	@Column(name = "fi_Office_c")
	private Boolean fiOffice_C;
	@Column(name = "pincode_matched_res_c")
	private Boolean pincodeMatchedRes_C;
	@Column(name = "pincode_matched_off_c")
	private Boolean pincodeMatchedOff_C;
	@Column(name = "pincode_matched_per_c")
	private Boolean pinCodeMatchedPer_C;
	@Column(name = "bs_band_c")
	private Boolean BSBand_C;
	@Column(name = "wo_od_settled_status_c")
	private String WO_OD_Settled_Status_C;
	
	@Column(name = "fi_type_c")
	private String Fi_Type_C;
	@Column(name = "fi_status_c")
	private String Fi_Status_C;
	
	//Applicant
	
	/*@Column(name = "uid_a")
	private Boolean uid_A;*/
	@Column(name = "gender_a")
	private Boolean gender_A;
	@Column(name = "landline_no_a")
	private Boolean landlineNo_A;
	@Column(name = "buss_landline_no")
	private Boolean bussLandlineNo;	
	@Column(name = "present_state_a")
	private Boolean presentState_A;	// NO C & G
	
	@Column(name = "constitution_a")
	private Boolean constitution_A;
	@Column(name = "dedupe_status_af_a")
	private Boolean dedupeStatusAF_A;
	@Column(name = "dedupe_status_cf_a")
	private Boolean dedupeStatusCF_A;
	@Column(name = "dedupe_status_a")
	private Boolean dedupeStatus_A;
	@Column(name = "dedupe_tenure_a")
	private Boolean dedupeTenure_A;
	@Column(name = "dedupe_count_af_a")
	private Boolean dedupeCountAF_A;
	@Column(name = "dob_incorp_a")
	private Boolean dobIncorp_A;
	@Column(name = "fi_neg_rea_resi_a")
	private Boolean fiNegReaResi_A;
	@Column(name = "fi_neg_rea_perm_a")
	private Boolean fiNegReaPerm_A;
	@Column(name = "fi_neg_rea_office_a")
	private Boolean fiNegReaOffice_A;
	@Column(name = "income_proof_a")
	private Boolean incomeProof_A;
	@Column(name = "mobile_connection_a")
	private Boolean mobileConnection_A;
	@Column(name = "present_city_a")
	private Boolean presentCity_A;
	@Column(name = "primary_employment_a")
	private Boolean primaryEmployment_A;//Diff between primaryEmployment_A & primaryEmpType_A
	@Column(name = "primary_emp_type_a")
	private Boolean primaryEmpType_A;
	@Column(name = "property_status_a")
	private Boolean propertyStatus_A;
	@Column(name = "residence_status_a")
	private Boolean residenceStatus_A;
	@Column(name = "residing_since_a")
	private Boolean residingSince_A;		//TODO: Bajaj to confirm the datatype
	@Column(name = "residing_since_fi_a")
	private Boolean residingSinceFI_A;
	@Column(name = "total_income_a")
	private Boolean totalIncome_A;
	@Column(name = "tpc_a")
	private Boolean TPC_A;
	@Column(name = "working_since_a")
	private Boolean workingSince_A;
	@Column(name = "working_since_fi_a")
	private Boolean workingSinceFI_A;
	@Column(name = "bureau_score_a")
	private Boolean bureauScoreA;
	@Column(name = "bureau_type_a")
	private Boolean bureauTypeA;
	@Column(name = "crops_per_year_a")
	private Boolean cropsPerYear_A;
	@Column(name = "land_holding_own_a")
	private Boolean landHoldingOwn_A;
	@Column(name = "land_holding_lea_a")
	private Boolean landHoldingLea_A;
	@Column(name = "no_of_bouncing_a")
	private Boolean noOfBouncing_A;
	@Column(name = "max_closure_date_gt3_a")
	private Boolean maxClosureDateGT3_A;
	@Column(name = "max_closure_date_lt3_a")
	private Boolean maxClosureDateLT3_A;
	@Column(name = "present_add_as_perm_addr_a")
	private Boolean presentAddAsPermAddr_A;
	
//	@Column(name = "tvr_status")
	private Boolean TVR_Status; 	// Diff between this and TVR_AppStatus
	
	@Column(name = "tvr_status_a")
	private Boolean tvrStatus_A;
	@Column(name = "tvr_business_status")
	private Boolean tvrBusinessStatus;
	@Column(name = "tvr_perm_add_status")
	private Boolean tvrPermAddStatus;
	@Column(name = "tvr_ref_status_1")
	private Boolean tvrRefStatus_1;
	@Column(name = "tvr_ref_status_2")
	private Boolean tvrRefStatus_2;
	
	@Column(name = "na_negative_area_a")
	private Boolean naNegativeArea_A;
	@Column(name = "hrp_profile_a")
	private Boolean hrpProfile_A;
	@Column(name = "prone_area_a")
	private Boolean proneArea_A;
	@Column(name = "fraud_match_flag_a")
	private Boolean fraudMatchFlag_A;
	@Column(name = "overdue_cc_acc_qual_max_amt_a")
	private Boolean overdueCCAccQualMaxAmt_A;
	@Column(name = "overdue_non_cc_acc_qual_max_amt_a")
	private Boolean overdueNonCCAccQualMaxAmt_A;
	@Column(name = "writtenoff_cc_acc_qual_max_dpd_a")
	private Boolean writtenOffCCAccQualMaxDPD_A; // NO C & G
	@Column(name = "writtenoff_cc_acc_qual_max_amt_a")
	private Boolean writtenOffCCAccQualMaxAmt_A;
	@Column(name = "writtenoff_non_cc_acc_qual_max_amt_a")
	private Boolean writtenOffNonCCAccQualMaxAmt_A;
	@Column(name = "wo_od_settled_status_a")
	private Boolean woODSettledStatus_A;
	@Column(name = "overdue_non_cc_acc_qual_max_dpd_a")
	private Boolean overdueNonCCAccQualMaxDPD_A;
	@Column(name = "age_a")
	private Boolean age_A;	//TODO: Bajaj to confirm the age in months, yr or Date
	@Column(name = "fi_off_a")
	private Boolean fiOff_A;
	@Column(name = "fi_perm_a")
	private Boolean fiPerm_A;
	@Column(name = "fi_pres_a")
	private Boolean fiPres_A;
	@Column(name = "fi_office_a")
	private Boolean fiOffice_A;
	@Column(name = "pincode_matched_res_a")
	private Boolean pincodeMatchedRes_A;
	@Column(name = "pincode_matched_off_a")
	private Boolean pincodeMatchedOff_A;
	@Column(name = "pincode_matched_per_a")
	private Boolean pincodeMatchedPer_A;
	@Column(name = "bs_band_a")
	private Boolean BSBand_A;
	
	
	@Column(name = "fi_type_a")
	private String Fi_Type_A;
	@Column(name = "fi_status_a")
	private String Fi_Status_A;
	
	
	@Column(name = "app_present")
	private Boolean appPresent = Boolean.FALSE;
	@Column(name = "coapp_present")
	private Boolean coappPresent = Boolean.FALSE;
	@Column(name = "guar_present")
	private Boolean guarPresent = Boolean.FALSE;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRuleId() {
		return ruleId;
	}
	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}
	public String getRule_name() {
		return rule_name;
	}
	public void setRule_name(String rule_name) {
		this.rule_name = rule_name;
	}
	public Boolean getLeadId() {
		return leadId;
	}
	public void setLeadId(Boolean leadId) {
		this.leadId = leadId;
	}
	public Boolean getUid_A() {
		return uid_A;
	}
	public void setUid_A(Boolean uid_A) {
		this.uid_A = uid_A;
	}
	public Boolean getUid_C() {
		return uid_C;
	}
	public void setUid_C(Boolean uid_C) {
		this.uid_C = uid_C;
	}
	public Boolean getUid_G() {
		return uid_G;
	}
	public void setUid_G(Boolean uid_G) {
		this.uid_G = uid_G;
	}
	public Boolean getPresent_C() {
		return present_C;
	}
	public void setPresent_C(Boolean present_C) {
		this.present_C = present_C;
	}
	public Boolean getPresent_G() {
		return present_G;
	}
	public void setPresent_G(Boolean present_G) {
		this.present_G = present_G;
	}
	public Boolean getRelWithApp_C() {
		return relWithApp_C;
	}
	public void setRelWithApp_C(Boolean relWithApp_C) {
		this.relWithApp_C = relWithApp_C;
	}
	public Boolean getCoAppRelation() {
		return coAppRelation;
	}
	public void setCoAppRelation(Boolean coAppRelation) {
		this.coAppRelation = coAppRelation;
	}
	public Boolean getEMI() {
		return EMI;
	}
	public void setEMI(Boolean eMI) {
		EMI = eMI;
	}
	public Boolean getFutureEMI() {
		return futureEMI;
	}
	public void setFutureEMI(Boolean futureEMI) {
		this.futureEMI = futureEMI;
	}
	public Boolean getNoOfFutureEMI() {
		return noOfFutureEMI;
	}
	public void setNoOfFutureEMI(Boolean noOfFutureEMI) {
		this.noOfFutureEMI = noOfFutureEMI;
	}
	public Boolean getAdvanceEMIAmt() {
		return advanceEMIAmt;
	}
	public void setAdvanceEMIAmt(Boolean advanceEMIAmt) {
		this.advanceEMIAmt = advanceEMIAmt;
	}
	public Boolean getLTV() {
		return LTV;
	}
	public void setLTV(Boolean lTV) {
		LTV = lTV;
	}
	public Boolean getNoOfVehicles() {
		return noOfVehicles;
	}
	public void setNoOfVehicles(Boolean noOfVehicles) {
		this.noOfVehicles = noOfVehicles;
	}
	public Boolean getTotalNumberOfVehicle() {
		return totalNumberOfVehicle;
	}
	public void setTotalNumberOfVehicle(Boolean totalNumberOfVehicle) {
		this.totalNumberOfVehicle = totalNumberOfVehicle;
	}
	public Boolean getTenure() {
		return tenure;
	}
	public void setTenure(Boolean tenure) {
		this.tenure = tenure;
	}
	public Boolean getProduct() {
		return product;
	}
	public void setProduct(Boolean product) {
		this.product = product;
	}
	public Boolean getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(Boolean productCategory) {
		this.productCategory = productCategory;
	}
	public Boolean getAmountFinanced() {
		return amountFinanced;
	}
	public void setAmountFinanced(Boolean amountFinanced) {
		this.amountFinanced = amountFinanced;
	}
	public Boolean getAppliedFinanceAmt() {
		return appliedFinanceAmt;
	}
	public void setAppliedFinanceAmt(Boolean appliedFinanceAmt) {
		this.appliedFinanceAmt = appliedFinanceAmt;
	}
	public Boolean getMarginMoney() {
		return marginMoney;
	}
	public void setMarginMoney(Boolean marginMoney) {
		this.marginMoney = marginMoney;
	}
	public Boolean getCustomerType() {
		return customerType;
	}
	public void setCustomerType(Boolean customerType) {
		this.customerType = customerType;
	}
	public Boolean getCustCatFinal() {
		return custCatFinal;
	}
	public void setCustCatFinal(Boolean custCatFinal) {
		this.custCatFinal = custCatFinal;
	}
	public Boolean getRepaymentMode() {
		return repaymentMode;
	}
	public void setRepaymentMode(Boolean repaymentMode) {
		this.repaymentMode = repaymentMode;
	}
	public Boolean getRepaymentFrom() {
		return repaymentFrom;
	}
	public void setRepaymentFrom(Boolean repaymentFrom) {
		this.repaymentFrom = repaymentFrom;
	}
	public Boolean getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(Boolean subscriberId) {
		this.subscriberId = subscriberId;
	}
	public Boolean getLayoutId() {
		return layoutId;
	}
	public void setLayoutId(Boolean layoutId) {
		this.layoutId = layoutId;
	}
	public Boolean getABB() {
		return ABB;
	}
	public void setABB(Boolean aBB) {
		ABB = aBB;
	}
	public Boolean getAccountVintage() {
		return accountVintage;
	}
	public void setAccountVintage(Boolean accountVintage) {
		this.accountVintage = accountVintage;
	}
	public Boolean getTypeOfRefinance() {
		return typeOfRefinance;
	}
	public void setTypeOfRefinance(Boolean typeOfRefinance) {
		this.typeOfRefinance = typeOfRefinance;
	}
	public Boolean getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(Boolean registrationNo) {
		this.registrationNo = registrationNo;
	}
	
	
	public Boolean getBlueBookPrice() {
		return blueBookPrice;
	}
	public void setBlueBookPrice(Boolean blueBookPrice) {
		this.blueBookPrice = blueBookPrice;
	}
	public Boolean getSchemeType() {
		return schemeType;
	}
	public void setSchemeType(Boolean schemeType) {
		this.schemeType = schemeType;
	}
	public Boolean getSegment() {
		return segment;
	}
	public void setSegment(Boolean segment) {
		this.segment = segment;
	}
	public Boolean getSubCode() {
		return subCode;
	}
	public void setSubCode(Boolean subCode) {
		this.subCode = subCode;
	}
	public Boolean getAssetType() {
		return assetType;
	}
	public void setAssetType(Boolean assetType) {
		this.assetType = assetType;
	}
	public Boolean getOfferType() {
		return offerType;
	}
	public void setOfferType(Boolean offerType) {
		this.offerType = offerType;
	}
	public Boolean getSchemeGrp() {
		return schemeGrp;
	}
	public void setSchemeGrp(Boolean schemeGrp) {
		this.schemeGrp = schemeGrp;
	}
	public Boolean getSchemeCode() {
		return schemeCode;
	}
	public void setSchemeCode(Boolean schemeCode) {
		this.schemeCode = schemeCode;
	}
	public Boolean getBranch() {
		return branch;
	}
	public void setBranch(Boolean branch) {
		this.branch = branch;
	}
	public Boolean getSupplierCategory() {
		return supplierCategory;
	}
	public void setSupplierCategory(Boolean supplierCategory) {
		this.supplierCategory = supplierCategory;
	}
	public Boolean getSupplierState() {
		return supplierState;
	}
	public void setSupplierState(Boolean supplierState) {
		this.supplierState = supplierState;
	}
	public Boolean getTotalExposure() {
		return totalExposure;
	}
	public void setTotalExposure(Boolean totalExposure) {
		this.totalExposure = totalExposure;
	}
	public Boolean getDedupeStatusAF_G() {
		return dedupeStatusAF_G;
	}
	public void setDedupeStatusAF_G(Boolean dedupeStatusAF_G) {
		this.dedupeStatusAF_G = dedupeStatusAF_G;
	}
	public Boolean getDedupeStatusCF_G() {
		return dedupeStatusCF_G;
	}
	public void setDedupeStatusCF_G(Boolean dedupeStatusCF_G) {
		this.dedupeStatusCF_G = dedupeStatusCF_G;
	}
	public Boolean getDedupeStatus_G() {
		return dedupeStatus_G;
	}
	public void setDedupeStatus_G(Boolean dedupeStatus_G) {
		this.dedupeStatus_G = dedupeStatus_G;
	}
	public Boolean getDedupeTenure_G() {
		return dedupeTenure_G;
	}
	public void setDedupeTenure_G(Boolean dedupeTenure_G) {
		this.dedupeTenure_G = dedupeTenure_G;
	}
	public Boolean getDobIncorp_G() {
		return dobIncorp_G;
	}
	public void setDobIncorp_G(Boolean dobIncorp_G) {
		this.dobIncorp_G = dobIncorp_G;
	}
	public Boolean getFiNegReaResi_G() {
		return fiNegReaResi_G;
	}
	public void setFiNegReaResi_G(Boolean fiNegReaResi_G) {
		this.fiNegReaResi_G = fiNegReaResi_G;
	}
	public Boolean getFiNegReaPerm_G() {
		return fiNegReaPerm_G;
	}
	public void setFiNegReaPerm_G(Boolean fiNegReaPerm_G) {
		this.fiNegReaPerm_G = fiNegReaPerm_G;
	}
	public Boolean getFiNegReaOffice_G() {
		return fiNegReaOffice_G;
	}
	public void setFiNegReaOffice_G(Boolean fiNegReaOffice_G) {
		this.fiNegReaOffice_G = fiNegReaOffice_G;
	}
	public Boolean getPrimaryEmpType_G() {
		return primaryEmpType_G;
	}
	public void setPrimaryEmpType_G(Boolean primaryEmpType_G) {
		this.primaryEmpType_G = primaryEmpType_G;
	}
	public Boolean getPropertyStatus_G() {
		return propertyStatus_G;
	}
	public void setPropertyStatus_G(Boolean propertyStatus_G) {
		this.propertyStatus_G = propertyStatus_G;
	}
	public Boolean getResidenceStatus_G() {
		return residenceStatus_G;
	}
	public void setResidenceStatus_G(Boolean residenceStatus_G) {
		this.residenceStatus_G = residenceStatus_G;
	}
	public Boolean getResidingSince_G() {
		return residingSince_G;
	}
	public void setResidingSince_G(Boolean residingSince_G) {
		this.residingSince_G = residingSince_G;
	}
	public Boolean getResidingSinceFI_G() {
		return residingSinceFI_G;
	}
	public void setResidingSinceFI_G(Boolean residingSinceFI_G) {
		this.residingSinceFI_G = residingSinceFI_G;
	}
	public Boolean getTpc_G() {
		return tpc_G;
	}
	public void setTpc_G(Boolean tpc_G) {
		this.tpc_G = tpc_G;
	}
	public Boolean getWorkingSince_G() {
		return workingSince_G;
	}
	public void setWorkingSince_G(Boolean workingSince_G) {
		this.workingSince_G = workingSince_G;
	}
	public Boolean getWorkingSinceFI_G() {
		return workingSinceFI_G;
	}
	public void setWorkingSinceFI_G(Boolean workingSinceFI_G) {
		this.workingSinceFI_G = workingSinceFI_G;
	}
	public Boolean getBureauScore_G() {
		return bureauScore_G;
	}
	public void setBureauScore_G(Boolean bureauScore_G) {
		this.bureauScore_G = bureauScore_G;
	}
	public Boolean getBureauType_G() {
		return bureauType_G;
	}
	public void setBureauType_G(Boolean bureauType_G) {
		this.bureauType_G = bureauType_G;
	}
	public Boolean getNoOfBouncing_G() {
		return noOfBouncing_G;
	}
	public void setNoOfBouncing_G(Boolean noOfBouncing_G) {
		this.noOfBouncing_G = noOfBouncing_G;
	}
	
	public Boolean getTvrStatus_G() {
		return tvrStatus_G;
	}
	public void setTvrStatus_G(Boolean tvrStatus_G) {
		this.tvrStatus_G = tvrStatus_G;
	}
	public Boolean getNaNegativeArea_G() {
		return naNegativeArea_G;
	}
	public void setNaNegativeArea_G(Boolean naNegativeArea_G) {
		this.naNegativeArea_G = naNegativeArea_G;
	}
	public Boolean getHRPProfile_G() {
		return HRPProfile_G;
	}
	public void setHRPProfile_G(Boolean hRPProfile_G) {
		HRPProfile_G = hRPProfile_G;
	}
	public Boolean getProneArea_G() {
		return proneArea_G;
	}
	public void setProneArea_G(Boolean proneArea_G) {
		this.proneArea_G = proneArea_G;
	}
	public Boolean getNa_G() {
		return na_G;
	}
	public void setNa_G(Boolean na_G) {
		this.na_G = na_G;
	}
	public Boolean getNp_G() {
		return np_G;
	}
	public void setNp_G(Boolean np_G) {
		this.np_G = np_G;
	}
	public Boolean getPa_G() {
		return pa_G;
	}
	public void setPa_G(Boolean pa_G) {
		this.pa_G = pa_G;
	}
	public Boolean getFraudMatchFlag_G() {
		return fraudMatchFlag_G;
	}
	public void setFraudMatchFlag_G(Boolean fraudMatchFlag_G) {
		this.fraudMatchFlag_G = fraudMatchFlag_G;
	}
	public Boolean getFm_G() {
		return fm_G;
	}
	public void setFm_G(Boolean fm_G) {
		this.fm_G = fm_G;
	}
	public Boolean getOverdueCCAccQualMaxAmt_G() {
		return overdueCCAccQualMaxAmt_G;
	}
	public void setOverdueCCAccQualMaxAmt_G(Boolean overdueCCAccQualMaxAmt_G) {
		this.overdueCCAccQualMaxAmt_G = overdueCCAccQualMaxAmt_G;
	}
	public Boolean getOverdueNonCCAccQualMaxAmt_G() {
		return overdueNonCCAccQualMaxAmt_G;
	}
	public void setOverdueNonCCAccQualMaxAmt_G(Boolean overdueNonCCAccQualMaxAmt_G) {
		this.overdueNonCCAccQualMaxAmt_G = overdueNonCCAccQualMaxAmt_G;
	}
	public Boolean getWrittenOffNonCCAccQualMaxDPD_G() {
		return WrittenOffNonCCAccQualMaxDPD_G;
	}
	public void setWrittenOffNonCCAccQualMaxDPD_G(Boolean writtenOffNonCCAccQualMaxDPD_G) {
		WrittenOffNonCCAccQualMaxDPD_G = writtenOffNonCCAccQualMaxDPD_G;
	}
	public Boolean getWrittenOffCCAccQualMaxAmt_G() {
		return writtenOffCCAccQualMaxAmt_G;
	}
	public void setWrittenOffCCAccQualMaxAmt_G(Boolean writtenOffCCAccQualMaxAmt_G) {
		this.writtenOffCCAccQualMaxAmt_G = writtenOffCCAccQualMaxAmt_G;
	}
	public Boolean getWrittenOffNonCCAccQualMaxAmt_G() {
		return writtenOffNonCCAccQualMaxAmt_G;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_G(Boolean writtenOffNonCCAccQualMaxAmt_G) {
		this.writtenOffNonCCAccQualMaxAmt_G = writtenOffNonCCAccQualMaxAmt_G;
	}
	public Boolean getWoODSettledStatus_G() {
		return woODSettledStatus_G;
	}
	public void setWoODSettledStatus_G(Boolean woODSettledStatus_G) {
		this.woODSettledStatus_G = woODSettledStatus_G;
	}
	public Boolean getOverdueNonCCAccQualMaxDPD_G() {
		return overdueNonCCAccQualMaxDPD_G;
	}
	public void setOverdueNonCCAccQualMaxDPD_G(Boolean overdueNonCCAccQualMaxDPD_G) {
		this.overdueNonCCAccQualMaxDPD_G = overdueNonCCAccQualMaxDPD_G;
	}
	public Boolean getAge_G() {
		return age_G;
	}
	public void setAge_G(Boolean age_G) {
		this.age_G = age_G;
	}
	public Boolean getFiPres_G() {
		return fiPres_G;
	}
	public void setFiPres_G(Boolean fiPres_G) {
		this.fiPres_G = fiPres_G;
	}
	public Boolean getPincodeMatchedRes_G() {
		return pincodeMatchedRes_G;
	}
	public void setPincodeMatchedRes_G(Boolean pincodeMatchedRes_G) {
		this.pincodeMatchedRes_G = pincodeMatchedRes_G;
	}
	public Boolean getPincodeMatchedOff_G() {
		return pincodeMatchedOff_G;
	}
	public void setPincodeMatchedOff_G(Boolean pincodeMatchedOff_G) {
		this.pincodeMatchedOff_G = pincodeMatchedOff_G;
	}
	public Boolean getBSBand_G() {
		return BSBand_G;
	}
	public void setBSBand_G(Boolean bSBand_G) {
		BSBand_G = bSBand_G;
	}
	public Boolean getLandlineNo_C() {
		return landlineNo_C;
	}
	public void setLandlineNo_C(Boolean landlineNo_C) {
		this.landlineNo_C = landlineNo_C;
	}
	public Boolean getBusinessLandlineNo_C() {
		return businessLandlineNo_C;
	}
	public void setBusinessLandlineNo_C(Boolean businessLandlineNo_C) {
		this.businessLandlineNo_C = businessLandlineNo_C;
	}
	public Boolean getConstitutionC() {
		return constitutionC;
	}
	public void setConstitutionC(Boolean constitutionC) {
		this.constitutionC = constitutionC;
	}
	public Boolean getDedupeStatusAF_C() {
		return dedupeStatusAF_C;
	}
	public void setDedupeStatusAF_C(Boolean dedupeStatusAF_C) {
		this.dedupeStatusAF_C = dedupeStatusAF_C;
	}
	public Boolean getDedupeStatusCF_C() {
		return dedupeStatusCF_C;
	}
	public void setDedupeStatusCF_C(Boolean dedupeStatusCF_C) {
		this.dedupeStatusCF_C = dedupeStatusCF_C;
	}
	public Boolean getDedupeStatus_C() {
		return dedupeStatus_C;
	}
	public void setDedupeStatus_C(Boolean dedupeStatus_C) {
		this.dedupeStatus_C = dedupeStatus_C;
	}
	public Boolean getDedupeTenure_C() {
		return dedupeTenure_C;
	}
	public void setDedupeTenure_C(Boolean dedupeTenure_C) {
		this.dedupeTenure_C = dedupeTenure_C;
	}
	public Boolean getDedupeCountAF_C() {
		return dedupeCountAF_C;
	}
	public void setDedupeCountAF_C(Boolean dedupeCountAF_C) {
		this.dedupeCountAF_C = dedupeCountAF_C;
	}
	public Boolean getDobIncorp_C() {
		return dobIncorp_C;
	}
	public void setDobIncorp_C(Boolean dobIncorp_C) {
		this.dobIncorp_C = dobIncorp_C;
	}
	public Boolean getFiNegReaResi_C() {
		return fiNegReaResi_C;
	}
	public void setFiNegReaResi_C(Boolean fiNegReaResi_C) {
		this.fiNegReaResi_C = fiNegReaResi_C;
	}
	public Boolean getFiNegReaPerm_C() {
		return fiNegReaPerm_C;
	}
	public void setFiNegReaPerm_C(Boolean fiNegReaPerm_C) {
		this.fiNegReaPerm_C = fiNegReaPerm_C;
	}
	public Boolean getFiNegReaOffice_C() {
		return fiNegReaOffice_C;
	}
	public void setFiNegReaOffice_C(Boolean fiNegReaOffice_C) {
		this.fiNegReaOffice_C = fiNegReaOffice_C;
	}
	public Boolean getIncomeProof_C() {
		return incomeProof_C;
	}
	public void setIncomeProof_C(Boolean incomeProof_C) {
		this.incomeProof_C = incomeProof_C;
	}
	public Boolean getMobileConnection_C() {
		return mobileConnection_C;
	}
	public void setMobileConnection_C(Boolean mobileConnection_C) {
		this.mobileConnection_C = mobileConnection_C;
	}
	public Boolean getPresentCity_C() {
		return presentCity_C;
	}
	public void setPresentCity_C(Boolean presentCity_C) {
		this.presentCity_C = presentCity_C;
	}
	public Boolean getPrimaryEmpType_C() {
		return primaryEmpType_C;
	}
	public void setPrimaryEmpType_C(Boolean primaryEmpType_C) {
		this.primaryEmpType_C = primaryEmpType_C;
	}
	public Boolean getPropertyStatus_C() {
		return propertyStatus_C;
	}
	public void setPropertyStatus_C(Boolean propertyStatus_C) {
		this.propertyStatus_C = propertyStatus_C;
	}
	public Boolean getResidenceStatus_C() {
		return residenceStatus_C;
	}
	public void setResidenceStatus_C(Boolean residenceStatus_C) {
		this.residenceStatus_C = residenceStatus_C;
	}
	public Boolean getResidingSince_C() {
		return residingSince_C;
	}
	public void setResidingSince_C(Boolean residingSince_C) {
		this.residingSince_C = residingSince_C;
	}
	public Boolean getResidingSinceFI_C() {
		return residingSinceFI_C;
	}
	public void setResidingSinceFI_C(Boolean residingSinceFI_C) {
		this.residingSinceFI_C = residingSinceFI_C;
	}
	public Boolean getTotalIncome_C() {
		return totalIncome_C;
	}
	public void setTotalIncome_C(Boolean totalIncome_C) {
		this.totalIncome_C = totalIncome_C;
	}
	public Boolean getTpc_C() {
		return tpc_C;
	}
	public void setTpc_C(Boolean tpc_C) {
		this.tpc_C = tpc_C;
	}
	public Boolean getWorkingSince_C() {
		return workingSince_C;
	}
	public void setWorkingSince_C(Boolean workingSince_C) {
		this.workingSince_C = workingSince_C;
	}
	public Boolean getWorkingSinceFI_C() {
		return workingSinceFI_C;
	}
	public void setWorkingSinceFI_C(Boolean workingSinceFI_C) {
		this.workingSinceFI_C = workingSinceFI_C;
	}
	public Boolean getBureauScore_C() {
		return bureauScore_C;
	}
	public void setBureauScore_C(Boolean bureauScore_C) {
		this.bureauScore_C = bureauScore_C;
	}
	public Boolean getBureauType_C() {
		return bureauType_C;
	}
	public void setBureauType_C(Boolean bureauType_C) {
		this.bureauType_C = bureauType_C;
	}
	public Boolean getCropsPerYear_C() {
		return cropsPerYear_C;
	}
	public void setCropsPerYear_C(Boolean cropsPerYear_C) {
		this.cropsPerYear_C = cropsPerYear_C;
	}
	public Boolean getLandHoldingOwn_C() {
		return landHoldingOwn_C;
	}
	public void setLandHoldingOwn_C(Boolean landHoldingOwn_C) {
		this.landHoldingOwn_C = landHoldingOwn_C;
	}
	public Boolean getLandHoldingLea_C() {
		return landHoldingLea_C;
	}
	public void setLandHoldingLea_C(Boolean landHoldingLea_C) {
		this.landHoldingLea_C = landHoldingLea_C;
	}
	public Boolean getNoOfBouncing_C() {
		return noOfBouncing_C;
	}
	public void setNoOfBouncing_C(Boolean noOfBouncing_C) {
		this.noOfBouncing_C = noOfBouncing_C;
	}
	
	public Boolean getPresentAddrAsPermAddr_C() {
		return presentAddrAsPermAddr_C;
	}
	public void setPresentAddrAsPermAddr_C(Boolean presentAddrAsPermAddr_C) {
		this.presentAddrAsPermAddr_C = presentAddrAsPermAddr_C;
	}
	public Boolean getFiResidence_C() {
		return fiResidence_C;
	}
	public void setFiResidence_C(Boolean fiResidence_C) {
		this.fiResidence_C = fiResidence_C;
	}
	public Boolean getPrimaryEmployment_C() {
		return primaryEmployment_C;
	}
	public void setPrimaryEmployment_C(Boolean primaryEmployment_C) {
		this.primaryEmployment_C = primaryEmployment_C;
	}
	public Boolean getTvrStatus_C() {
		return tvrStatus_C;
	}
	public void setTvrStatus_C(Boolean tvrStatus_C) {
		this.tvrStatus_C = tvrStatus_C;
	}
	public Boolean getNaNegativeArea_C() {
		return naNegativeArea_C;
	}
	public void setNaNegativeArea_C(Boolean naNegativeArea_C) {
		this.naNegativeArea_C = naNegativeArea_C;
	}
	public Boolean getHrpProfile_C() {
		return hrpProfile_C;
	}
	public void setHrpProfile_C(Boolean hrpProfile_C) {
		this.hrpProfile_C = hrpProfile_C;
	}
	public Boolean getProneArea_C() {
		return proneArea_C;
	}
	public void setProneArea_C(Boolean proneArea_C) {
		this.proneArea_C = proneArea_C;
	}
	public Boolean getNaPresent_C() {
		return naPresent_C;
	}
	public void setNaPresent_C(Boolean naPresent_C) {
		this.naPresent_C = naPresent_C;
	}
	public Boolean getNpPresent_C() {
		return npPresent_C;
	}
	public void setNpPresent_C(Boolean npPresent_C) {
		this.npPresent_C = npPresent_C;
	}
	public Boolean getPa_present_c() {
		return pa_present_c;
	}
	public void setPa_present_c(Boolean pa_present_c) {
		this.pa_present_c = pa_present_c;
	}
	public Boolean getFraudMatchFlag_C() {
		return fraudMatchFlag_C;
	}
	public void setFraudMatchFlag_C(Boolean fraudMatchFlag_C) {
		this.fraudMatchFlag_C = fraudMatchFlag_C;
	}
	public Boolean getFm_C() {
		return fm_C;
	}
	public void setFm_C(Boolean fm_C) {
		this.fm_C = fm_C;
	}
	public Boolean getOverdueCCAccQualMaxAmt_C() {
		return overdueCCAccQualMaxAmt_C;
	}
	public void setOverdueCCAccQualMaxAmt_C(Boolean overdueCCAccQualMaxAmt_C) {
		this.overdueCCAccQualMaxAmt_C = overdueCCAccQualMaxAmt_C;
	}
	public Boolean getOverdueNonCCAccQualMaxAmt_C() {
		return overdueNonCCAccQualMaxAmt_C;
	}
	public void setOverdueNonCCAccQualMaxAmt_C(Boolean overdueNonCCAccQualMaxAmt_C) {
		this.overdueNonCCAccQualMaxAmt_C = overdueNonCCAccQualMaxAmt_C;
	}
	public Boolean getWrittenOffNonCCAccQualMaxDPD_C() {
		return writtenOffNonCCAccQualMaxDPD_C;
	}
	public void setWrittenOffNonCCAccQualMaxDPD_C(Boolean writtenOffNonCCAccQualMaxDPD_C) {
		this.writtenOffNonCCAccQualMaxDPD_C = writtenOffNonCCAccQualMaxDPD_C;
	}
	public Boolean getWrittenOffCCAccQualMaxAmt_C() {
		return writtenOffCCAccQualMaxAmt_C;
	}
	public void setWrittenOffCCAccQualMaxAmt_C(Boolean writtenOffCCAccQualMaxAmt_C) {
		this.writtenOffCCAccQualMaxAmt_C = writtenOffCCAccQualMaxAmt_C;
	}
	public Boolean getWrittenOffNonCCAccQualMaxAmt_C() {
		return writtenOffNonCCAccQualMaxAmt_C;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_C(Boolean writtenOffNonCCAccQualMaxAmt_C) {
		this.writtenOffNonCCAccQualMaxAmt_C = writtenOffNonCCAccQualMaxAmt_C;
	}
	public Boolean getWrittenOffODSettledStatus_C() {
		return writtenOffODSettledStatus_C;
	}
	public void setWrittenOffODSettledStatus_C(Boolean writtenOffODSettledStatus_C) {
		this.writtenOffODSettledStatus_C = writtenOffODSettledStatus_C;
	}
	public Boolean getOverdueNonCCAccQualMaxDPD_C() {
		return overdueNonCCAccQualMaxDPD_C;
	}
	public void setOverdueNonCCAccQualMaxDPD_C(Boolean overdueNonCCAccQualMaxDPD_C) {
		this.overdueNonCCAccQualMaxDPD_C = overdueNonCCAccQualMaxDPD_C;
	}
	public Boolean getAge_C() {
		return age_C;
	}
	public void setAge_C(Boolean age_C) {
		this.age_C = age_C;
	}
	public Boolean getFiOff_C() {
		return fiOff_C;
	}
	public void setFiOff_C(Boolean fiOff_C) {
		this.fiOff_C = fiOff_C;
	}
	public Boolean getFiPerm_C() {
		return fiPerm_C;
	}
	public void setFiPerm_C(Boolean fiPerm_C) {
		this.fiPerm_C = fiPerm_C;
	}
	public Boolean getFiPres_C() {
		return fiPres_C;
	}
	public void setFiPres_C(Boolean fiPres_C) {
		this.fiPres_C = fiPres_C;
	}
	public Boolean getFiOffice_C() {
		return fiOffice_C;
	}
	public void setFiOffice_C(Boolean fiOffice_C) {
		this.fiOffice_C = fiOffice_C;
	}
	public Boolean getPincodeMatchedRes_C() {
		return pincodeMatchedRes_C;
	}
	public void setPincodeMatchedRes_C(Boolean pincodeMatchedRes_C) {
		this.pincodeMatchedRes_C = pincodeMatchedRes_C;
	}
	public Boolean getPincodeMatchedOff_C() {
		return pincodeMatchedOff_C;
	}
	public void setPincodeMatchedOff_C(Boolean pincodeMatchedOff_C) {
		this.pincodeMatchedOff_C = pincodeMatchedOff_C;
	}
	public Boolean getPinCodeMatchedPer_C() {
		return pinCodeMatchedPer_C;
	}
	public void setPinCodeMatchedPer_C(Boolean pinCodeMatchedPer_C) {
		this.pinCodeMatchedPer_C = pinCodeMatchedPer_C;
	}
	public Boolean getBSBand_C() {
		return BSBand_C;
	}
	public void setBSBand_C(Boolean bSBand_C) {
		BSBand_C = bSBand_C;
	}
	public Boolean getGender_A() {
		return gender_A;
	}
	public void setGender_A(Boolean gender_A) {
		this.gender_A = gender_A;
	}
	public Boolean getLandlineNo_A() {
		return landlineNo_A;
	}
	public void setLandlineNo_A(Boolean landlineNo_A) {
		this.landlineNo_A = landlineNo_A;
	}
	public Boolean getBussLandlineNo() {
		return bussLandlineNo;
	}
	public void setBussLandlineNo(Boolean bussLandlineNo) {
		this.bussLandlineNo = bussLandlineNo;
	}
	public Boolean getPresentState_A() {
		return presentState_A;
	}
	public void setPresentState_A(Boolean presentState_A) {
		this.presentState_A = presentState_A;
	}
	public Boolean getConstitution_A() {
		return constitution_A;
	}
	public void setConstitution_A(Boolean constitution_A) {
		this.constitution_A = constitution_A;
	}
	public Boolean getDedupeStatusAF_A() {
		return dedupeStatusAF_A;
	}
	public void setDedupeStatusAF_A(Boolean dedupeStatusAF_A) {
		this.dedupeStatusAF_A = dedupeStatusAF_A;
	}
	public Boolean getDedupeStatusCF_A() {
		return dedupeStatusCF_A;
	}
	public void setDedupeStatusCF_A(Boolean dedupeStatusCF_A) {
		this.dedupeStatusCF_A = dedupeStatusCF_A;
	}
	public Boolean getDedupeStatus_A() {
		return dedupeStatus_A;
	}
	public void setDedupeStatus_A(Boolean dedupeStatus_A) {
		this.dedupeStatus_A = dedupeStatus_A;
	}
	public Boolean getDedupeTenure_A() {
		return dedupeTenure_A;
	}
	public void setDedupeTenure_A(Boolean dedupeTenure_A) {
		this.dedupeTenure_A = dedupeTenure_A;
	}
	public Boolean getDedupeCountAF_A() {
		return dedupeCountAF_A;
	}
	public void setDedupeCountAF_A(Boolean dedupeCountAF_A) {
		this.dedupeCountAF_A = dedupeCountAF_A;
	}
	public Boolean getDobIncorp_A() {
		return dobIncorp_A;
	}
	public void setDobIncorp_A(Boolean dobIncorp_A) {
		this.dobIncorp_A = dobIncorp_A;
	}
	public Boolean getFiNegReaResi_A() {
		return fiNegReaResi_A;
	}
	public void setFiNegReaResi_A(Boolean fiNegReaResi_A) {
		this.fiNegReaResi_A = fiNegReaResi_A;
	}
	public Boolean getFiNegReaPerm_A() {
		return fiNegReaPerm_A;
	}
	public void setFiNegReaPerm_A(Boolean fiNegReaPerm_A) {
		this.fiNegReaPerm_A = fiNegReaPerm_A;
	}
	public Boolean getFiNegReaOffice_A() {
		return fiNegReaOffice_A;
	}
	public void setFiNegReaOffice_A(Boolean fiNegReaOffice_A) {
		this.fiNegReaOffice_A = fiNegReaOffice_A;
	}
	public Boolean getIncomeProof_A() {
		return incomeProof_A;
	}
	public void setIncomeProof_A(Boolean incomeProof_A) {
		this.incomeProof_A = incomeProof_A;
	}
	public Boolean getMobileConnection_A() {
		return mobileConnection_A;
	}
	public void setMobileConnection_A(Boolean mobileConnection_A) {
		this.mobileConnection_A = mobileConnection_A;
	}
	public Boolean getPresentCity_A() {
		return presentCity_A;
	}
	public void setPresentCity_A(Boolean presentCity_A) {
		this.presentCity_A = presentCity_A;
	}
	public Boolean getPrimaryEmployment_A() {
		return primaryEmployment_A;
	}
	public void setPrimaryEmployment_A(Boolean primaryEmployment_A) {
		this.primaryEmployment_A = primaryEmployment_A;
	}
	public Boolean getPrimaryEmpType_A() {
		return primaryEmpType_A;
	}
	public void setPrimaryEmpType_A(Boolean primaryEmpType_A) {
		this.primaryEmpType_A = primaryEmpType_A;
	}
	public Boolean getPropertyStatus_A() {
		return propertyStatus_A;
	}
	public void setPropertyStatus_A(Boolean propertyStatus_A) {
		this.propertyStatus_A = propertyStatus_A;
	}
	public Boolean getResidenceStatus_A() {
		return residenceStatus_A;
	}
	public void setResidenceStatus_A(Boolean residenceStatus_A) {
		this.residenceStatus_A = residenceStatus_A;
	}
	public Boolean getResidingSince_A() {
		return residingSince_A;
	}
	public void setResidingSince_A(Boolean residingSince_A) {
		this.residingSince_A = residingSince_A;
	}
	public Boolean getResidingSinceFI_A() {
		return residingSinceFI_A;
	}
	public void setResidingSinceFI_A(Boolean residingSinceFI_A) {
		this.residingSinceFI_A = residingSinceFI_A;
	}
	public Boolean getTotalIncome_A() {
		return totalIncome_A;
	}
	public void setTotalIncome_A(Boolean totalIncome_A) {
		this.totalIncome_A = totalIncome_A;
	}
	public Boolean getTPC_A() {
		return TPC_A;
	}
	public void setTPC_A(Boolean tPC_A) {
		TPC_A = tPC_A;
	}
	public Boolean getWorkingSince_A() {
		return workingSince_A;
	}
	public void setWorkingSince_A(Boolean workingSince_A) {
		this.workingSince_A = workingSince_A;
	}
	public Boolean getWorkingSinceFI_A() {
		return workingSinceFI_A;
	}
	public void setWorkingSinceFI_A(Boolean workingSinceFI_A) {
		this.workingSinceFI_A = workingSinceFI_A;
	}
	public Boolean getBureauScoreA() {
		return bureauScoreA;
	}
	public void setBureauScoreA(Boolean bureauScoreA) {
		this.bureauScoreA = bureauScoreA;
	}
	public Boolean getBureauTypeA() {
		return bureauTypeA;
	}
	public void setBureauTypeA(Boolean bureauTypeA) {
		this.bureauTypeA = bureauTypeA;
	}
	public Boolean getCropsPerYear_A() {
		return cropsPerYear_A;
	}
	public void setCropsPerYear_A(Boolean cropsPerYear_A) {
		this.cropsPerYear_A = cropsPerYear_A;
	}
	public Boolean getLandHoldingOwn_A() {
		return landHoldingOwn_A;
	}
	public void setLandHoldingOwn_A(Boolean landHoldingOwn_A) {
		this.landHoldingOwn_A = landHoldingOwn_A;
	}
	public Boolean getLandHoldingLea_A() {
		return landHoldingLea_A;
	}
	public void setLandHoldingLea_A(Boolean landHoldingLea_A) {
		this.landHoldingLea_A = landHoldingLea_A;
	}
	public Boolean getNoOfBouncing_A() {
		return noOfBouncing_A;
	}
	public void setNoOfBouncing_A(Boolean noOfBouncing_A) {
		this.noOfBouncing_A = noOfBouncing_A;
	}
	
	public Boolean getLoginDate() {
		return loginDate;
	}
	public void setLoginDate(Boolean loginDate) {
		this.loginDate = loginDate;
	}
	public Boolean getDisbursementDateOldLAN() {
		return disbursementDateOldLAN;
	}
	public void setDisbursementDateOldLAN(Boolean disbursementDateOldLAN) {
		this.disbursementDateOldLAN = disbursementDateOldLAN;
	}
	public Boolean getMaxClosureDateGT3_G() {
		return maxClosureDateGT3_G;
	}
	public void setMaxClosureDateGT3_G(Boolean maxClosureDateGT3_G) {
		this.maxClosureDateGT3_G = maxClosureDateGT3_G;
	}
	public Boolean getMaxClosureDateLT3_G() {
		return maxClosureDateLT3_G;
	}
	public void setMaxClosureDateLT3_G(Boolean maxClosureDateLT3_G) {
		this.maxClosureDateLT3_G = maxClosureDateLT3_G;
	}
	public Boolean getMaxClosureDateGT3_C() {
		return maxClosureDateGT3_C;
	}
	public void setMaxClosureDateGT3_C(Boolean maxClosureDateGT3_C) {
		this.maxClosureDateGT3_C = maxClosureDateGT3_C;
	}
	public Boolean getMaxClosureDateLT3_C() {
		return maxClosureDateLT3_C;
	}
	public void setMaxClosureDateLT3_C(Boolean maxClosureDateLT3_C) {
		this.maxClosureDateLT3_C = maxClosureDateLT3_C;
	}
	public Boolean getMaxClosureDateGT3_A() {
		return maxClosureDateGT3_A;
	}
	public void setMaxClosureDateGT3_A(Boolean maxClosureDateGT3_A) {
		this.maxClosureDateGT3_A = maxClosureDateGT3_A;
	}
	public Boolean getMaxClosureDateLT3_A() {
		return maxClosureDateLT3_A;
	}
	public void setMaxClosureDateLT3_A(Boolean maxClosureDateLT3_A) {
		this.maxClosureDateLT3_A = maxClosureDateLT3_A;
	}
	public Boolean getPresentAddAsPermAddr_A() {
		return presentAddAsPermAddr_A;
	}
	public void setPresentAddAsPermAddr_A(Boolean presentAddAsPermAddr_A) {
		this.presentAddAsPermAddr_A = presentAddAsPermAddr_A;
	}
	public Boolean getTVR_Status() {
		return TVR_Status;
	}
	public void setTVR_Status(Boolean tVR_Status) {
		TVR_Status = tVR_Status;
	}
	public Boolean getTvrStatus_A() {
		return tvrStatus_A;
	}
	public void setTvrStatus_A(Boolean tvrStatus_A) {
		this.tvrStatus_A = tvrStatus_A;
	}
	public Boolean getTvrBusinessStatus() {
		return tvrBusinessStatus;
	}
	public void setTvrBusinessStatus(Boolean tvrBusinessStatus) {
		this.tvrBusinessStatus = tvrBusinessStatus;
	}
	public Boolean getTvrPermAddStatus() {
		return tvrPermAddStatus;
	}
	public void setTvrPermAddStatus(Boolean tvrPermAddStatus) {
		this.tvrPermAddStatus = tvrPermAddStatus;
	}
	public Boolean getTvrRefStatus_1() {
		return tvrRefStatus_1;
	}
	public void setTvrRefStatus_1(Boolean tvrRefStatus_1) {
		this.tvrRefStatus_1 = tvrRefStatus_1;
	}
	public Boolean getTvrRefStatus_2() {
		return tvrRefStatus_2;
	}
	public void setTvrRefStatus_2(Boolean tvrRefStatus_2) {
		this.tvrRefStatus_2 = tvrRefStatus_2;
	}
	public Boolean getNaNegativeArea_A() {
		return naNegativeArea_A;
	}
	public void setNaNegativeArea_A(Boolean naNegativeArea_A) {
		this.naNegativeArea_A = naNegativeArea_A;
	}
	public Boolean getHrpProfile_A() {
		return hrpProfile_A;
	}
	public void setHrpProfile_A(Boolean hrpProfile_A) {
		this.hrpProfile_A = hrpProfile_A;
	}
	public Boolean getProneArea_A() {
		return proneArea_A;
	}
	public void setProneArea_A(Boolean proneArea_A) {
		this.proneArea_A = proneArea_A;
	}
	public Boolean getFraudMatchFlag_A() {
		return fraudMatchFlag_A;
	}
	public void setFraudMatchFlag_A(Boolean fraudMatchFlag_A) {
		this.fraudMatchFlag_A = fraudMatchFlag_A;
	}
	public Boolean getOverdueCCAccQualMaxAmt_A() {
		return overdueCCAccQualMaxAmt_A;
	}
	public void setOverdueCCAccQualMaxAmt_A(Boolean overdueCCAccQualMaxAmt_A) {
		this.overdueCCAccQualMaxAmt_A = overdueCCAccQualMaxAmt_A;
	}
	public Boolean getOverdueNonCCAccQualMaxAmt_A() {
		return overdueNonCCAccQualMaxAmt_A;
	}
	public void setOverdueNonCCAccQualMaxAmt_A(Boolean overdueNonCCAccQualMaxAmt_A) {
		this.overdueNonCCAccQualMaxAmt_A = overdueNonCCAccQualMaxAmt_A;
	}
	public Boolean getWrittenOffCCAccQualMaxDPD_A() {
		return writtenOffCCAccQualMaxDPD_A;
	}
	public void setWrittenOffCCAccQualMaxDPD_A(Boolean writtenOffCCAccQualMaxDPD_A) {
		this.writtenOffCCAccQualMaxDPD_A = writtenOffCCAccQualMaxDPD_A;
	}
	public Boolean getWrittenOffCCAccQualMaxAmt_A() {
		return writtenOffCCAccQualMaxAmt_A;
	}
	public void setWrittenOffCCAccQualMaxAmt_A(Boolean writtenOffCCAccQualMaxAmt_A) {
		this.writtenOffCCAccQualMaxAmt_A = writtenOffCCAccQualMaxAmt_A;
	}
	public Boolean getWrittenOffNonCCAccQualMaxAmt_A() {
		return writtenOffNonCCAccQualMaxAmt_A;
	}
	public void setWrittenOffNonCCAccQualMaxAmt_A(Boolean writtenOffNonCCAccQualMaxAmt_A) {
		this.writtenOffNonCCAccQualMaxAmt_A = writtenOffNonCCAccQualMaxAmt_A;
	}
	public Boolean getWoODSettledStatus_A() {
		return woODSettledStatus_A;
	}
	public void setWoODSettledStatus_A(Boolean woODSettledStatus_A) {
		this.woODSettledStatus_A = woODSettledStatus_A;
	}
	public Boolean getOverdueNonCCAccQualMaxDPD_A() {
		return overdueNonCCAccQualMaxDPD_A;
	}
	public void setOverdueNonCCAccQualMaxDPD_A(Boolean overdueNonCCAccQualMaxDPD_A) {
		this.overdueNonCCAccQualMaxDPD_A = overdueNonCCAccQualMaxDPD_A;
	}
	public Boolean getAge_A() {
		return age_A;
	}
	public void setAge_A(Boolean age_A) {
		this.age_A = age_A;
	}
	public Boolean getFiOff_A() {
		return fiOff_A;
	}
	public void setFiOff_A(Boolean fiOff_A) {
		this.fiOff_A = fiOff_A;
	}
	public Boolean getFiPerm_A() {
		return fiPerm_A;
	}
	public void setFiPerm_A(Boolean fiPerm_A) {
		this.fiPerm_A = fiPerm_A;
	}
	public Boolean getFiPres_A() {
		return fiPres_A;
	}
	public void setFiPres_A(Boolean fiPres_A) {
		this.fiPres_A = fiPres_A;
	}
	public Boolean getFiOffice_A() {
		return fiOffice_A;
	}
	public void setFiOffice_A(Boolean fiOffice_A) {
		this.fiOffice_A = fiOffice_A;
	}
	public Boolean getPincodeMatchedRes_A() {
		return pincodeMatchedRes_A;
	}
	public void setPincodeMatchedRes_A(Boolean pincodeMatchedRes_A) {
		this.pincodeMatchedRes_A = pincodeMatchedRes_A;
	}
	public Boolean getPincodeMatchedOff_A() {
		return pincodeMatchedOff_A;
	}
	public void setPincodeMatchedOff_A(Boolean pincodeMatchedOff_A) {
		this.pincodeMatchedOff_A = pincodeMatchedOff_A;
	}
	public Boolean getPincodeMatchedPer_A() {
		return pincodeMatchedPer_A;
	}
	public void setPincodeMatchedPer_A(Boolean pincodeMatchedPer_A) {
		this.pincodeMatchedPer_A = pincodeMatchedPer_A;
	}
	public Boolean getBSBand_A() {
		return BSBand_A;
	}
	public void setBSBand_A(Boolean bSBand_A) {
		BSBand_A = bSBand_A;
	}
	public Boolean getAppPresent() {
		return appPresent;
	}
	public void setAppPresent(Boolean appPresent) {
		this.appPresent = appPresent;
	}
	public Boolean getCoappPresent() {
		return coappPresent;
	}
	public void setCoappPresent(Boolean coappPresent) {
		this.coappPresent = coappPresent;
	}
	public Boolean getGuarPresent() {
		return guarPresent;
	}
	public void setGuarPresent(Boolean guarPresent) {
		this.guarPresent = guarPresent;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Double getAppliedNetLtv() {
		return appliedNetLtv;
	}
	public void setAppliedNetLtv(Double appliedNetLtv) {
		this.appliedNetLtv = appliedNetLtv;
	}
	public Double getEligibleLtv() {
		return eligibleLtv;
	}
	public void setEligibleLtv(Double eligibleLtv) {
		this.eligibleLtv = eligibleLtv;
	}
	public String getFcuStatus() {
		return fcuStatus;
	}
	public void setFcuStatus(String fcuStatus) {
		this.fcuStatus = fcuStatus;
	}
	public String getFi_Type_G() {
		return Fi_Type_G;
	}
	public void setFi_Type_G(String fi_Type_G) {
		Fi_Type_G = fi_Type_G;
	}
	public String getFi_Status_G() {
		return Fi_Status_G;
	}
	public void setFi_Status_G(String fi_Status_G) {
		Fi_Status_G = fi_Status_G;
	}
	public String getFi_Type_C() {
		return Fi_Type_C;
	}
	public void setFi_Type_C(String fi_Type_C) {
		Fi_Type_C = fi_Type_C;
	}
	public String getFi_Status_C() {
		return Fi_Status_C;
	}
	public void setFi_Status_C(String fi_Status_C) {
		Fi_Status_C = fi_Status_C;
	}
	public String getFi_Type_A() {
		return Fi_Type_A;
	}
	public void setFi_Type_A(String fi_Type_A) {
		Fi_Type_A = fi_Type_A;
	}
	public String getFi_Status_A() {
		return Fi_Status_A;
	}
	public void setFi_Status_A(String fi_Status_A) {
		Fi_Status_A = fi_Status_A;
	}
	public String getWO_OD_Settled_Status_C() {
		return WO_OD_Settled_Status_C;
	}
	public void setWO_OD_Settled_Status_C(String wO_OD_Settled_Status_C) {
		WO_OD_Settled_Status_C = wO_OD_Settled_Status_C;
	}
	public String getCustSubCat() {
		return custSubCat;
	}
	public void setCustSubCat(String custSubCat) {
		this.custSubCat = custSubCat;
	}
	
	
}
