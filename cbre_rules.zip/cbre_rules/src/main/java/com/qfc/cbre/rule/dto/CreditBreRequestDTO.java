package com.qfc.cbre.rule.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "cbre_request")
public class CreditBreRequestDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne(mappedBy="breRequestId",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private CbreRequest_ADTO cbreRequest_A;
	@OneToOne(mappedBy="breRequestId",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private CbreRequest_CDTO cbreRequest_C;
	@OneToOne(mappedBy="breRequestId",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private CbreRequest_GDTO cbreRequest_G;
	
	@Column(name = "lead_id")
	private Long leadId;
	@Column(name = "uid_a", length=50)
	private String uid_A;
	@Column(name = "uid_c", length=50)
	private String uid_C;
	@Column(name = "uid_g", length=50)
	private String uid_G;
	
	@Column(name = "present_c", length=10)
	private String present_C;
	@Column(name = "present_g", length=10)
	private String present_G;
	@Column(name = "app_rel_with_c", length=100)
	private String relWithApp_C;
	private String coAppRelation;	//??
	
	@Column(name = "emi")
	private Double EMI;
	@Column(name = "future_emi")
	private Double futureEMI;
	@Column(name = "no_of_future_emi")
	private Integer noOfFutureEMI;
	@Column(name = "advance_emi_amt")
	private Integer advanceEMIAmt;
	@Column(name = "ltv")
	private Double LTV;
	@Column(name = "no_of_vehicles")
	private Integer noOfVehicles;
	private Integer totalNumberOfVehicle; // diff between noOfVeh and totalNoOfVeh
	@Column(name = "tenure")
	private Integer tenure;
	@Column(name = "product")
	private String product;
	@Column(name = "product_category")
	private String productCategory;
	@Column(name = "amount_financed")
	private Double amountFinanced;
	@Column(name = "applied_finance_amt")
	private Double appliedFinanceAmt;
	@Column(name = "margin_money")
	private Double marginMoney;
	
	@Column(name = "customer_type")
	private Integer customerType;
	@Column(name = "cust_cat_final")
	private String custCatFinal;
	@Column(name = "repayment_mode")
	private String repaymentMode;
	@Column(name = "repayment_from", length=20)
	private String repaymentFrom;
	
	@Column(name = "subscriber_id")
	private Integer subscriberId;	
	@Column(name = "layout_id")         //??/
	private Integer layoutId; 			//??
	@Column(name = "rule_id")
	private Integer ruleId;				//??
	@Column(name = "abb")
	private Integer ABB;				//??
	@Column(name = "account_vintage")
	private String accountVintage;
	
	@Column(name = "type_of_refinance")
	private String typeOfRefinance;
	@Column(name = "registration_no")
	private String registrationNo;
	
	@Column(name = "login_date")
	private Date loginDate;
	@Column(name = "disbursement_date_old_lan")
	private Date disbursementDateOldLAN;
	@Column(name = "blue_book_price")
	private Double blueBookPrice;
	
	@Column(name = "scheme_type")
	private String schemeType;
	@Column(name = "segment")
	private String segment;
	@Column(name = "subCode")
	private String subCode;
	@Column(name = "asset_type")
	private String assetType;
	@Column(name = "offer_type")
	private String offerType; //Normal
	
	@Column(name = "scheme_grp")
	private String schemeGrp;
	@Column(name = "scheme_code")
	private String schemeCode;
	
	@Column(name = "branch")
	private String branch;
	@Column(name = "supplier_category")
	private String supplierCategory; // String or Integer ??
	@Column(name = "supplier_state")
	private String supplierState;
	@Column(name = "total_exposure")
	private Integer totalExposure;
	@Column(name = "created_date")
	private Date createdDate;
	@Column(name = "make")
	private String make;
	@Column(name = "model")
	private String model;
	@Column(name = "applied_net_ltv")
	private Double appliedNetLtv;
	@Column(name = "eligible_ltv")
	private Double eligibleLtv;
	@Column(name = "cust_sub_cat")
	private String custSubCat;
	
	@JsonIgnore
	@Column(name = "bre_status")
	private String breStatus;
	@JsonIgnore
	@Column(name = "co_app_change")
	private boolean coAppChange; // default false
	@JsonIgnore
	@Column(name = "grntr_change")
	private boolean grntrChange; // default false
	
	
	public boolean isCoAppChange() {
		return coAppChange;
	}
	public void setCoAppChange(boolean coAppChange) {
		this.coAppChange = coAppChange;
	}
	public boolean isGrntrChange() {
		return grntrChange;
	}
	public void setGrntrChange(boolean grntrChange) {
		this.grntrChange = grntrChange;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public CbreRequest_ADTO getCbreRequest_A() {
		return cbreRequest_A;
	}
	public void setCbreRequest_A(CbreRequest_ADTO cbreRequest_A) {
		this.cbreRequest_A = cbreRequest_A;
	}
	public CbreRequest_CDTO getCbreRequest_C() {
		return cbreRequest_C;
	}
	public void setCbreRequest_C(CbreRequest_CDTO cbreRequest_C) {
		this.cbreRequest_C = cbreRequest_C;
	}
	public CbreRequest_GDTO getCbreRequest_G() {
		return cbreRequest_G;
	}
	public void setCbreRequest_G(CbreRequest_GDTO cbreRequest_G) {
		this.cbreRequest_G = cbreRequest_G;
	}
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getUid_A() {
		return uid_A;
	}
	public void setUid_A(String uid_A) {
		this.uid_A = uid_A;
	}
	public String getUid_C() {
		return uid_C;
	}
	public void setUid_C(String uid_C) {
		this.uid_C = uid_C;
	}
	public String getUid_G() {
		return uid_G;
	}
	public void setUid_G(String uid_G) {
		this.uid_G = uid_G;
	}
	public String getPresent_C() {
		return present_C;
	}
	public void setPresent_C(String present_C) {
		this.present_C = present_C;
	}
	public String getPresent_G() {
		return present_G;
	}
	public void setPresent_G(String present_G) {
		this.present_G = present_G;
	}
	public String getRelWithApp_C() {
		return relWithApp_C;
	}
	public void setRelWithApp_C(String relWithApp_C) {
		this.relWithApp_C = relWithApp_C;
	}
	public String getCoAppRelation() {
		return coAppRelation;
	}
	public void setCoAppRelation(String coAppRelation) {
		this.coAppRelation = coAppRelation;
	}
	public Double getEMI() {
		return EMI;
	}
	public void setEMI(Double eMI) {
		EMI = eMI;
	}
	public Double getFutureEMI() {
		return futureEMI;
	}
	public void setFutureEMI(Double futureEMI) {
		this.futureEMI = futureEMI;
	}
	public Integer getNoOfFutureEMI() {
		return noOfFutureEMI;
	}
	public void setNoOfFutureEMI(Integer noOfFutureEMI) {
		this.noOfFutureEMI = noOfFutureEMI;
	}
	public Integer getAdvanceEMIAmt() {
		return advanceEMIAmt;
	}
	public void setAdvanceEMIAmt(Integer advanceEMIAmt) {
		this.advanceEMIAmt = advanceEMIAmt;
	}
	public Double getLTV() {
		return LTV;
	}
	public void setLTV(Double lTV) {
		LTV = lTV;
	}
	public Integer getNoOfVehicles() {
		return noOfVehicles;
	}
	public void setNoOfVehicles(Integer noOfVehicles) {
		this.noOfVehicles = noOfVehicles;
	}
	public Integer getTotalNumberOfVehicle() {
		return totalNumberOfVehicle;
	}
	public void setTotalNumberOfVehicle(Integer totalNumberOfVehicle) {
		this.totalNumberOfVehicle = totalNumberOfVehicle;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	
	public Double getAmountFinanced() {
		return amountFinanced;
	}
	public void setAmountFinanced(Double amountFinanced) {
		this.amountFinanced = amountFinanced;
	}
	public Double getAppliedFinanceAmt() {
		return appliedFinanceAmt;
	}
	public void setAppliedFinanceAmt(Double appliedFinanceAmt) {
		this.appliedFinanceAmt = appliedFinanceAmt;
	}
	public Double getMarginMoney() {
		return marginMoney;
	}
	public void setMarginMoney(Double marginMoney) {
		this.marginMoney = marginMoney;
	}
	public Integer getCustomerType() {
		return customerType;
	}
	public void setCustomerType(Integer customerType) {
		this.customerType = customerType;
	}
	public String getCustCatFinal() {
		return custCatFinal;
	}
	public void setCustCatFinal(String custCatFinal) {
		this.custCatFinal = custCatFinal;
	}
	public String getRepaymentMode() {
		return repaymentMode;
	}
	public void setRepaymentMode(String repaymentMode) {
		this.repaymentMode = repaymentMode;
	}
	public String getRepaymentFrom() {
		return repaymentFrom;
	}
	public void setRepaymentFrom(String repaymentFrom) {
		this.repaymentFrom = repaymentFrom;
	}
	public Integer getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}
	public Integer getLayoutId() {
		return layoutId;
	}
	public void setLayoutId(Integer layoutId) {
		this.layoutId = layoutId;
	}
	public Integer getRuleId() {
		return ruleId;
	}
	public void setRuleId(Integer ruleId) {
		this.ruleId = ruleId;
	}
	public Integer getABB() {
		return ABB;
	}
	public void setABB(Integer aBB) {
		ABB = aBB;
	}
	public String getAccountVintage() {
		return accountVintage;
	}
	public void setAccountVintage(String accountVintage) {
		this.accountVintage = accountVintage;
	}
	public String getTypeOfRefinance() {
		return typeOfRefinance;
	}
	public void setTypeOfRefinance(String typeOfRefinance) {
		this.typeOfRefinance = typeOfRefinance;
	}
	public String getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	public Date getLoginDate() {
		return loginDate;
	}
	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}
	public Date getDisbursementDateOldLAN() {
		return disbursementDateOldLAN;
	}
	public void setDisbursementDateOldLAN(Date disbursementDateOldLAN) {
		this.disbursementDateOldLAN = disbursementDateOldLAN;
	}
	public Double getBlueBookPrice() {
		return blueBookPrice;
	}
	public void setBlueBookPrice(Double blueBookPrice) {
		this.blueBookPrice = blueBookPrice;
	}  
	public String getSchemeType() {
		return schemeType;
	}
	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getSubCode() {
		return subCode;
	}
	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getSchemeGrp() {
		return schemeGrp;
	}
	public void setSchemeGrp(String schemeGrp) {
		this.schemeGrp = schemeGrp;
	}
	public String getSchemeCode() {
		return schemeCode;
	}
	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getSupplierCategory() {
		return supplierCategory;
	}
	public void setSupplierCategory(String supplierCategory) {
		this.supplierCategory = supplierCategory;
	}
	public String getSupplierState() {
		return supplierState;
	}
	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}
	public Integer getTotalExposure() {
		return totalExposure;
	}
	public void setTotalExposure(Integer totalExposure) {
		this.totalExposure = totalExposure;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getBreStatus() {
		return breStatus;
	}
	public void setBreStatus(String breStatus) {
		this.breStatus = breStatus;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Double getAppliedNetLtv() {
		return appliedNetLtv;
	}
	public void setAppliedNetLtv(Double appliedNetLtv) {
		this.appliedNetLtv = appliedNetLtv;
	}
	public Double getEligibleLtv() {
		return eligibleLtv;
	}
	public void setEligibleLtv(Double eligibleLtv) {
		this.eligibleLtv = eligibleLtv;
	}
	public String getCustSubCat() {
		return custSubCat;
	}
	public void setCustSubCat(String custSubCat) {
		this.custSubCat = custSubCat;
	}
	
	
	@Override
	public String toString() {
		return "CreditBreRequestDTO [id=" + id + ", cbreRequest_A=" + cbreRequest_A + ", cbreRequest_C=" + cbreRequest_C
				+ ", cbreRequest_G=" + cbreRequest_G + ", leadId=" + leadId + ", uid_A=" + uid_A + ", uid_C=" + uid_C
				+ ", uid_G=" + uid_G + ", present_C=" + present_C + ", present_G=" + present_G + ", relWithApp_C="
				+ relWithApp_C + ", coAppRelation=" + coAppRelation + ", EMI=" + EMI + ", futureEMI=" + futureEMI
				+ ", noOfFutureEMI=" + noOfFutureEMI + ", advanceEMIAmt=" + advanceEMIAmt + ", LTV=" + LTV
				+ ", noOfVehicles=" + noOfVehicles + ", totalNumberOfVehicle=" + totalNumberOfVehicle + ", tenure="
				+ tenure + ", product=" + product + ", productCategory=" + productCategory + ", amountFinanced="
				+ amountFinanced + ", appliedFinanceAmt=" + appliedFinanceAmt + ", marginMoney=" + marginMoney
				+ ", customerType=" + customerType + ", custCatFinal=" + custCatFinal + ", repaymentMode="
				+ repaymentMode + ", repaymentFrom=" + repaymentFrom + ", subscriberId=" + subscriberId + ", layoutId="
				+ layoutId + ", ruleId=" + ruleId + ", ABB=" + ABB + ", accountVintage=" + accountVintage
				+ ", typeOfRefinance=" + typeOfRefinance + ", registrationNo=" + registrationNo + ", loginDate="
				+ loginDate + ", disbursementDateOldLAN=" + disbursementDateOldLAN + ", blueBookPrice=" + blueBookPrice
				+ ", schemeType=" + schemeType + ", segment=" + segment + ", subCode=" + subCode + ", assetType="
				+ assetType + ", offerType=" + offerType + ", schemeGrp=" + schemeGrp + ", schemeCode=" + schemeCode
				+ ", branch=" + branch + ", supplierCategory=" + supplierCategory + ", supplierState=" + supplierState
				+ ", totalExposure=" + totalExposure + ", createdDate=" + createdDate + ", make=" + make + ", model="
				+ model + ", appliedNetLtv=" + appliedNetLtv + ", eligibleLtv=" + eligibleLtv + ", custSubCat="
				+ custSubCat + ", breStatus=" + breStatus + "]";
	}
	
}
