package com.qfc.cbre.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.qfc.cbre.common.util.CbreConstants;
import com.qfc.cbre.rule.dto.CreditBreRequestDTO;
import com.qfc.cbre.rule.input.master.dto.MstInputMasterDTO;
import com.qfc.cbre.rule.input.vo.MstInputMasterVo;
import com.qfc.cbre.rule.transactions.dto.CreditBreResponseDTO;
import com.qfc.cbre.rule.transactions.dto.RuleTransactionDetailsDTO;
import com.qfc.cbre.rule.vo.RuleTransactionDetails;
import com.qfc.cbre.service.dao.QfcBaseDAO;
import com.qfc.cbre.rule.vo.CreditBreRequest;
import com.qfc.cbre.rule.vo.CreditBreResponse;

@Repository(value="creditBreDao")
public class CreditBreDaoImpl extends QfcBaseDAO implements CreditBreDao{

	@Override
	public Long saveCreditBreRequest(CreditBreRequest req) {
		
		CreditBreRequestDTO dto = CbreConstants.MAPPER.map(req, CreditBreRequestDTO.class);
		return (Long)super.getSessionFactory().getCurrentSession().save(dto);
		
	}

	@Override
	public Long saveRuleDetails(RuleTransactionDetailsDTO ruledetails) {
		return (Long)super.getSessionFactory().getCurrentSession().save(ruledetails);
	}

	@Override
	public Map<String, MstInputMasterDTO> gelAllRuleMaster(int active) {
		Map<String, MstInputMasterDTO> rules = new HashMap<>();
		StringBuffer sb = new StringBuffer();
		String hql = " from MstInputMasterDTO ";
		List<MstInputMasterDTO> dtolist = super.getSessionFactory().getCurrentSession().createQuery(hql.toString()).getResultList();
		
		dtolist.stream().forEach((object) -> {
			rules.put(object.getRule_name()!=null ? object.getRule_name() : "" , object);
		});
		
		return rules;
	}

	@Override
	public void saveRuleInputDetails(MstInputMasterVo input) {
		super.getSessionFactory().getCurrentSession().save(input);
	}
	
	
	@Override
	public List<CreditBreResponse> getCreditBreHighestResponse(Long leadid) {
		String hql = " from CreditBreResponseDTO where leadId = :leadid ";
		Query qry = super.getSessionFactory().getCurrentSession().createQuery(hql);
		qry.setParameter("leadid", leadid);
		List<CreditBreResponseDTO> dtos = qry.getResultList();
		List<CreditBreResponse> vos = new ArrayList<>();
		if(dtos != null) {
			for(CreditBreResponseDTO dto : dtos) {
				vos.add(CbreConstants.MAPPER.map(dto, CreditBreResponse.class));
			}
			return vos;
		}else {
			CreditBreResponse vo = new CreditBreResponse();
			vos.add(vo);
			return vos;
		}
		
	}

	@Override
	public List<RuleTransactionDetails> getRuleTransactionList(Long leadid) {
		String hql = " from RuleTransactionDetailsDTO where leadid = :leadid ";
		Query qry = super.getSessionFactory().getCurrentSession().createQuery(hql);
		qry.setParameter("leadid", leadid);
		List<RuleTransactionDetailsDTO> dtos = qry.getResultList();
		List<RuleTransactionDetails> vos = new ArrayList<>();
		if(dtos != null) {
			for(RuleTransactionDetailsDTO dto : dtos) {
				vos.add(CbreConstants.MAPPER.map(dto, RuleTransactionDetails.class));
			}
			return vos;
		}else {
			RuleTransactionDetails vo = new RuleTransactionDetails();
			vos.add(vo);
			return vos;
		}
	}
	
}
