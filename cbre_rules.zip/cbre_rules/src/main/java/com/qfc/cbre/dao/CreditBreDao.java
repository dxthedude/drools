package com.qfc.cbre.dao;



import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.qfc.cbre.rule.input.master.dto.MstInputMasterDTO;
import com.qfc.cbre.rule.input.vo.MstInputMasterVo;
import com.qfc.cbre.rule.transactions.dto.RuleTransactionDetailsDTO;
import com.qfc.cbre.rule.vo.RuleTransactionDetails;
import com.qfc.cbre.rule.vo.CreditBreRequest;
import com.qfc.cbre.rule.vo.CreditBreResponse;

public interface CreditBreDao {

	@Transactional
	Long saveCreditBreRequest(CreditBreRequest req);

	@Transactional
	Long saveRuleDetails(RuleTransactionDetailsDTO ruledetails);

	@Transactional
	Map<String, MstInputMasterDTO> gelAllRuleMaster(int i);

	@Transactional
	void saveRuleInputDetails(MstInputMasterVo input);

	@Transactional
	List<CreditBreResponse> getCreditBreHighestResponse(Long leadid);

	@Transactional
	List<RuleTransactionDetails> getRuleTransactionList(Long leadid);
	
	
}
