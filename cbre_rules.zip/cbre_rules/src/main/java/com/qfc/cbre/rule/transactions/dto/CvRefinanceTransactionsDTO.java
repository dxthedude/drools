package com.qfc.cbre.rule.transactions.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.qfc.cbre.common.dto.BaseDTO;

@Entity
@Table(name="cv_refinance_transactions")
public class CvRefinanceTransactionsDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "lead_id")
	private Long leadid;
	
	@Column(name = "bre_req_id")
	private Long breRequestId;
	
	@ManyToOne
	@JoinColumn(name="rule_transaction_id",nullable=false)
	private RuleTransactionDetailsDTO ruleTransactionId;
	
	@Column(name = "level")
	private String level;
	
	@Column(name = "rule_name")
	private String ruleName;

	@Column(name = "deviation_msg")
	private String deviationMsg;
	
	@Column(name = "input_string")
	private String inputString;
	
	@Column(name = "run_for",length=4)
	private String runFor;
	
	@Column(name = "main_deviation_group")
	private String mainDeviationGroup;
	
	@Column(name = "sub_deviation_group")
	private String subDeviationGroup;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLeadid() {
		return leadid;
	}

	public void setLeadid(Long leadid) {
		this.leadid = leadid;
	}

	public Long getBreRequestId() {
		return breRequestId;
	}

	public void setBreRequestId(Long breRequestId) {
		this.breRequestId = breRequestId;
	}

	public RuleTransactionDetailsDTO getRuleTransactionId() {
		return ruleTransactionId;
	}

	public void setRuleTransactionId(RuleTransactionDetailsDTO ruleTransactionId) {
		this.ruleTransactionId = ruleTransactionId;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getDeviationMsg() {
		return deviationMsg;
	}

	public void setDeviationMsg(String deviationMsg) {
		this.deviationMsg = deviationMsg;
	}

	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public String getRunFor() {
		return runFor;
	}

	public void setRunFor(String runFor) {
		this.runFor = runFor;
	}

	public String getMainDeviationGroup() {
		return mainDeviationGroup;
	}

	public void setMainDeviationGroup(String mainDeviationGroup) {
		this.mainDeviationGroup = mainDeviationGroup;
	}

	public String getSubDeviationGroup() {
		return subDeviationGroup;
	}

	public void setSubDeviationGroup(String subDeviationGroup) {
		this.subDeviationGroup = subDeviationGroup;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
}
