package com.qfc.cbre.rule.transactions.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.qfc.cbre.common.dto.BaseDTO;

@Entity
@Table(name="creditbre_response")
public class CreditBreResponseDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name = "lead_id")
	private Long leadId;
	@Column(name = "response_code")
	private String responseCode;
	@Column(name = "response_msg")
	private String responseMsg;
	@Column(name = "exec_seq")
	private Integer execSeq = 0;
	@Column(name = "deviation_group")
	private String deviationGroup;
	@Column(name = "sub_deviation_group")
	private String subDeviationGroup;
	@Column(name = "deviation_msg")
	private String deviationMsg;
	@Column(name = "sub_rule")
	private String subRule;
	@Column(name = "main_rule")
	private String mainRule;
	@Column(name = "level")
	private String level=null;
	@Column(name = "executionFor")
	private String executionFor;
	@Column(name = "executed_on")
	private Date executedOn = new Date();
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="rule_transaction_id",nullable=false)
	private RuleTransactionDetailsDTO ruleTransactionId;
	@JsonIgnore
	@Column(name = "accepted")
	private boolean accepted;
	@JsonIgnore
	@Column(name = "rejected")
	private boolean rejected;
	
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	public Integer getExecSeq() {
		return execSeq;
	}
	public void setExecSeq(Integer execSeq) {
		this.execSeq = execSeq;
	}
	public String getDeviationGroup() {
		return deviationGroup;
	}
	public void setDeviationGroup(String deviationGroup) {
		this.deviationGroup = deviationGroup;
	}
	public String getDeviationMsg() {
		return deviationMsg;
	}
	public void setDeviationMsg(String deviationMsg) {
		this.deviationMsg = deviationMsg;
	}

	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getExecutionFor() {
		return executionFor;
	}
	public void setExecutionFor(String executionFor) {
		this.executionFor = executionFor;
	}
	public Date getExecutedOn() {
		return executedOn;
	}
	public void setExecutedOn(Date executedOn) {
		this.executedOn = executedOn;
	}
	
	public String getMainRule() {
		return mainRule;
	}
	public void setMainRule(String mainRule) {
		this.mainRule = mainRule;
	}
	public String getSubRule() {
		return subRule;
	}
	public void setSubRule(String subRule) {
		this.subRule = subRule;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public RuleTransactionDetailsDTO getRuleTransactionId() {
		return ruleTransactionId;
	}
	public void setRuleTransactionId(RuleTransactionDetailsDTO ruleTransactionId) {
		this.ruleTransactionId = ruleTransactionId;
	}
	public boolean isAccepted() {
		return accepted;
	}
	public void setAccepted(boolean accepted) {
		this.accepted = accepted;
	}
	public boolean isRejected() {
		return rejected;
	}
	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}
	
}
