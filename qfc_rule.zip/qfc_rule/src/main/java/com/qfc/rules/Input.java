package com.qfc.rules;

import java.util.ArrayList;
import java.util.List;

public class Input {
	
	private String name;
	private int age;
	private String qualification;
	private int income;
	private List<String> executedRules = new ArrayList<>();
	private String category;
	private String output;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	public List<String> getExecutedRules() {
		return executedRules;
	}
	public void setExecutedRules(List<String> executedRules) {
		this.executedRules = executedRules;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}

	
}
