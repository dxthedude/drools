package com.qfc.rules;

import java.util.Scanner;

import org.kie.api.io.Resource;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.qfc.bre.rules.config.DroolsBeanFactory;
import com.qfc.cbre.rule.helper.CreditBreRuleHelper;

public class QuestionRule {
	
	private static KieSession kSession;
	private static KieSession kSession2;
	static {
		Resource resource = ResourceFactory.newClassPathResource("/dtables/question-rule.xlsx", CreditBreRuleHelper.class);
		kSession = new DroolsBeanFactory().getKieSession(resource);
		System.out.println(kSession);
		
		Resource resource2 = ResourceFactory.newClassPathResource("/dtables/action-rule.xls", CreditBreRuleHelper.class);
		kSession2 = new DroolsBeanFactory().getKieSession(resource2);
		System.out.println(kSession2);
	}
	
	public static void main(String[] args) {
		//ApplicationContext appContext = new ClassPathXmlApplicationContext("cbre_spring_utility.xml");
		
		Scanner s = new Scanner (System.in);
		askQuestions(s);
		
	}

	private static void takeAction(Input input) {
		System.out.println("Firing Rule 2");
		kSession2.insert(input);
		kSession2.fireAllRules();
	}

	private static void askQuestions(Scanner s) {
		
		boolean valid = false;
		System.out.println("Enter your Name:\n");
	    String name;
	    name = s.next();
	    System.out.println("**************************\n\n");

	    System.out.println("Hi "+name+" Please Enter your Age:\n");
	    int age;
	    age = s.nextInt();
	    
	    if(age>18) {
	    	System.out.println("Congrats...!! You are an Adult\n");
	    }else {
	    	System.out.println("Oops...!! You are not an Adult\n");
	    }
	    String qualification = null;
	    while(!valid) {
    		System.out.println(name+"..!!  Please Enter your Highest Qualification:\n");
	    	System.out.println("(ex: Grad , PostGrad , Inter or Primary)\n");
	    	
	    	qualification = s.next();
	    	if(qualification.equalsIgnoreCase("Grad") || qualification.equalsIgnoreCase("PostGrad")
	    			|| qualification.equalsIgnoreCase("Inter") || qualification.equalsIgnoreCase("Primary")) {
	    		System.out.println("Nice...!!\n");
	    		valid = true;
	    	}else {
	    		System.out.println("Wrong Input.!!!!! Please select one of the above options\n");
	    		valid = false;
	    	}
    	}
    
    	System.out.println("Can you Please Tell me your current income : \n");
	    int income;
	    income = s.nextInt();	
	    
	    Input input = new Input();
	    input.setName(name);
	    input.setAge(age);
	    input.setQualification(qualification.toLowerCase());
	    input.setIncome(income);
	    
	    firingRule(input);

	    printInput(name, age, qualification, income);
	    System.out.println("\n Executed Rules :: \n");
	    int count =1;
	    for(String rule: input.getExecutedRules()) {
	    	System.out.println(count+" "+rule);
	    	count++;
	    }
	    System.out.println("Result Category ::: "+input.getCategory());
	    
	    takeAction(input);
	    
	    System.out.println("\n\n");
	    System.out.println("Thank you for Testing...\n!! END !!");
	   
	    System.out.println("");
	    String close;
	    close = s.next();
	    
	}

	private static void printInput(String name, int age, String qualification, int income) {
		System.out.println("*************************");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.print("*");System.out.print("*");
	    System.out.println("Input details :\n");
	    System.out.println("Name : "+name);
	    System.out.println("Age : "+age);
	    System.out.println("Qualification : "+qualification);
	    System.out.println("Income : "+income);
	    System.out.println("**********************************************");
	}

	private static void firingRule(Input input) {
		System.out.print("Executing Rules");
		System.out.print(".");System.out.print(".");System.out.print(".");
		System.out.print(".");System.out.print(".");System.out.print(".");
		System.out.print(".");System.out.print(".");System.out.print(".");
		System.out.print(".");System.out.print(".");System.out.print(".");
		kSession.insert(input);
		kSession.fireAllRules();
	}

}
